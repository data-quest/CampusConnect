-- phpMyAdmin SQL Dump
-- version 3.3.2deb1ubuntu1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 13. Dezember 2012 um 16:02
-- Server Version: 5.1.66
-- PHP-Version: 5.3.2-1ubuntu4.18

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `studip_campusconnect`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `abschluss`
--

DROP TABLE IF EXISTS `abschluss`;
CREATE TABLE `abschluss` (
  `abschluss_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `beschreibung` text COLLATE latin1_general_ci,
  `mkdate` int(20) DEFAULT NULL,
  `chdate` int(20) DEFAULT NULL,
  PRIMARY KEY (`abschluss_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `abschluss`
--

INSERT INTO `abschluss` (`abschluss_id`, `name`, `beschreibung`, `mkdate`, `chdate`) VALUES
('228234544820cdf75db55b42d1ea3ecc', 'Bachelor', '', 1311416359, 1311416359),
('c7f569e815a35cf24a515a0e67928072', 'Master', '', 1311416385, 1311416385);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admission_group`
--

DROP TABLE IF EXISTS `admission_group`;
CREATE TABLE `admission_group` (
  `group_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `chdate` int(10) unsigned NOT NULL,
  `mkdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `admission_group`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admission_seminar_studiengang`
--

DROP TABLE IF EXISTS `admission_seminar_studiengang`;
CREATE TABLE `admission_seminar_studiengang` (
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `studiengang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `quota` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`seminar_id`,`studiengang_id`),
  KEY `studiengang_id` (`studiengang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `admission_seminar_studiengang`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `admission_seminar_user`
--

DROP TABLE IF EXISTS `admission_seminar_user`;
CREATE TABLE `admission_seminar_user` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `studiengang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `status` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `position` int(5) DEFAULT NULL,
  `comment` tinytext COLLATE latin1_general_ci,
  `visible` enum('yes','no','unknown') COLLATE latin1_general_ci NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`user_id`,`seminar_id`,`studiengang_id`),
  KEY `seminar_id` (`seminar_id`,`studiengang_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `admission_seminar_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `archiv`
--

DROP TABLE IF EXISTS `archiv`;
CREATE TABLE `archiv` (
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `untertitel` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `beschreibung` text COLLATE latin1_general_ci NOT NULL,
  `start_time` int(20) NOT NULL DEFAULT '0',
  `semester` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `heimat_inst_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `institute` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dozenten` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `fakultaet` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dump` mediumtext COLLATE latin1_general_ci NOT NULL,
  `archiv_file_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `forumdump` longtext COLLATE latin1_general_ci NOT NULL,
  `wikidump` longtext COLLATE latin1_general_ci,
  `studienbereiche` text COLLATE latin1_general_ci NOT NULL,
  `VeranstaltungsNummer` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`seminar_id`),
  KEY `heimat_inst_id` (`heimat_inst_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `archiv`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `archiv_user`
--

DROP TABLE IF EXISTS `archiv_user`;
CREATE TABLE `archiv_user` (
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `status` enum('user','autor','tutor','dozent') COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  PRIMARY KEY (`seminar_id`,`user_id`),
  KEY `user_id` (`user_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `archiv_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `auth_extern`
--

DROP TABLE IF EXISTS `auth_extern`;
CREATE TABLE `auth_extern` (
  `studip_user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `external_user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `external_user_name` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `external_user_password` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `external_user_category` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `external_user_system_type` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `external_user_type` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`studip_user_id`,`external_user_system_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `auth_extern`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `auth_user_md5`
--

DROP TABLE IF EXISTS `auth_user_md5`;
CREATE TABLE `auth_user_md5` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `username` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `password` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `perms` enum('user','autor','tutor','dozent','admin','root') COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `Vorname` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `Nachname` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `Email` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `validation_key` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `auth_plugin` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lock_comment` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `locked_by` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `visible` enum('global','always','yes','unknown','no','never') COLLATE latin1_general_ci NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `k_username` (`username`),
  KEY `perms` (`perms`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `auth_user_md5`
--

INSERT INTO `auth_user_md5` (`user_id`, `username`, `password`, `perms`, `Vorname`, `Nachname`, `Email`, `validation_key`, `auth_plugin`, `locked`, `lock_comment`, `locked_by`, `visible`) VALUES
('76ed43ef286fb55cf9e41beadb484a9f', 'root@studip', '184843a86078e1af6f72686a51555212', 'root', 'Root', 'Studip', 'root@localhost', '', NULL, 0, NULL, NULL, 'unknown'),
('205f3efb7997a0fc9755da2b535038da', 'test_dozent', 'ae2b1fca515949e5d54fb22b8ed95575', 'dozent', 'Testaccount', 'Dozent', 'dozent@studip.de', '', NULL, 0, NULL, NULL, 'unknown'),
('6235c46eb9e962866ebdceece739ace5', 'test_admin', 'ae2b1fca515949e5d54fb22b8ed95575', 'admin', 'Testaccount', 'Admin', 'admin@studip.de', '', NULL, 0, NULL, NULL, 'unknown'),
('7e81ec247c151c02ffd479511e24cc03', 'test_tutor', 'ae2b1fca515949e5d54fb22b8ed95575', 'tutor', 'Testaccount', 'Tutor', 'tutor@studip.de', '', NULL, 0, NULL, NULL, 'unknown'),
('e7a0a84b161f3e8c09b4a0a2e8a58147', 'test_autor', 'ae2b1fca515949e5d54fb22b8ed95575', 'autor', 'Testaccount', 'Autor', 'autor@studip.de', '', 'standard', 0, NULL, NULL, 'unknown'),
('f859df66bb9a3f8ecd46a9895d4e47d2', 'CampusConnectDummyDozent', '', 'dozent', 'CampusConnect', 'DummyDozent', 'CampusConnectDummyDozent@localhost', '', NULL, 1, NULL, NULL, 'never'),
('cca72d353f2f35f1e3fc10b88d6aa390', 'rasmus', '523d3bf17e1a8d1feead0644bc2cd0bd', 'dozent', 'Rasmus', 'Fuhse', 'krassmus@gmail.com', '', 'standard', 0, NULL, NULL, 'always'),
('ac1981c0e8d159d8121508c488fad1cb', 'noackorama', '37361e9081eace9d3b160e0f659d7525', 'dozent', 'André', 'Noack', 'noack@data-quest.de', '', 'standard', 0, NULL, NULL, 'unknown');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `auto_insert_sem`
--

DROP TABLE IF EXISTS `auto_insert_sem`;
CREATE TABLE `auto_insert_sem` (
  `seminar_id` char(32) COLLATE latin1_general_ci NOT NULL,
  `status` enum('autor','tutor','dozent') COLLATE latin1_general_ci NOT NULL DEFAULT 'autor',
  PRIMARY KEY (`seminar_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `auto_insert_sem`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `auto_insert_user`
--

DROP TABLE IF EXISTS `auto_insert_user`;
CREATE TABLE `auto_insert_user` (
  `seminar_id` char(32) COLLATE latin1_general_ci NOT NULL,
  `user_id` char(32) COLLATE latin1_general_ci NOT NULL,
  `mkdate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`seminar_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `auto_insert_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `aux_lock_rules`
--

DROP TABLE IF EXISTS `aux_lock_rules`;
CREATE TABLE `aux_lock_rules` (
  `lock_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `attributes` text COLLATE latin1_general_ci NOT NULL,
  `sorting` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`lock_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `aux_lock_rules`
--

INSERT INTO `aux_lock_rules` (`lock_id`, `name`, `description`, `attributes`, `sorting`) VALUES
('d34f75dbb9936ba300086e096b718242', 'Standard', '', 'a:5:{s:10:"vasemester";s:1:"1";s:4:"vanr";s:1:"1";s:7:"vatitle";s:1:"0";s:8:"vadozent";s:1:"0";s:32:"ce73a10d07b3bb13c0132d363549efda";s:1:"1";}', 'a:5:{s:10:"vasemester";s:1:"0";s:4:"vanr";s:1:"0";s:7:"vatitle";s:1:"0";s:8:"vadozent";s:1:"0";s:32:"ce73a10d07b3bb13c0132d363549efda";s:1:"0";}');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `banner_ads`
--

DROP TABLE IF EXISTS `banner_ads`;
CREATE TABLE `banner_ads` (
  `ad_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `banner_path` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `alttext` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `target_type` enum('url','seminar','inst','user','none') COLLATE latin1_general_ci NOT NULL DEFAULT 'url',
  `target` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `startdate` int(20) NOT NULL DEFAULT '0',
  `enddate` int(20) NOT NULL DEFAULT '0',
  `priority` int(4) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ad_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `banner_ads`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `calendar_events`
--

DROP TABLE IF EXISTS `calendar_events`;
CREATE TABLE `calendar_events` (
  `event_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `autor_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `editor_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `uid` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `start` int(10) unsigned NOT NULL DEFAULT '0',
  `end` int(10) unsigned NOT NULL DEFAULT '0',
  `summary` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci,
  `class` enum('PUBLIC','PRIVATE','CONFIDENTIAL') COLLATE latin1_general_ci NOT NULL DEFAULT 'PRIVATE',
  `categories` tinytext COLLATE latin1_general_ci,
  `category_intern` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `location` tinytext COLLATE latin1_general_ci,
  `ts` int(10) unsigned NOT NULL DEFAULT '0',
  `linterval` smallint(5) unsigned DEFAULT NULL,
  `sinterval` smallint(5) unsigned DEFAULT NULL,
  `wdays` varchar(7) COLLATE latin1_general_ci DEFAULT NULL,
  `month` tinyint(3) unsigned DEFAULT NULL,
  `day` tinyint(3) unsigned DEFAULT NULL,
  `rtype` enum('SINGLE','DAILY','WEEKLY','MONTHLY','YEARLY') COLLATE latin1_general_ci NOT NULL DEFAULT 'SINGLE',
  `duration` smallint(5) unsigned NOT NULL DEFAULT '0',
  `count` smallint(5) DEFAULT '0',
  `expire` int(10) unsigned NOT NULL DEFAULT '0',
  `exceptions` text COLLATE latin1_general_ci,
  `mkdate` int(10) unsigned NOT NULL DEFAULT '0',
  `chdate` int(10) unsigned NOT NULL DEFAULT '0',
  `importdate` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `uid_range` (`uid`,`range_id`),
  KEY `autor_id` (`autor_id`),
  KEY `range_id` (`range_id`,`class`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `calendar_events`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `campus_connect_config`
--

DROP TABLE IF EXISTS `campus_connect_config`;
CREATE TABLE `campus_connect_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `data` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=31 ;

--
-- Daten für Tabelle `campus_connect_config`
--

INSERT INTO `campus_connect_config` (`id`, `type`, `active`, `data`) VALUES
(1, 'server', 0, 'a:10:{s:4:"name";s:22:"ecscc.uni-stuttgart.de";s:6:"server";s:43:"https://ecscc.uni-stuttgart.de/ra/ecs-test/";s:9:"auth_user";s:0:"";s:9:"auth_pass";s:0:"";s:9:"auth_type";s:1:"2";s:12:"ca_cert_path";s:66:"/home/fuhse/campusconnect/cert/FreeIT.de_Wurzel_Zertifikat.crt.pem";s:16:"client_cert_path";s:62:"/home/fuhse/campusconnect/cert/ECS_data-quest_StudIP_1.crt.pem";s:8:"key_path";s:53:"/home/fuhse/campusconnect/cert/ECS_data-quest.key.pem";s:12:"key_password";s:11:"avxlqik1974";s:8:"ecs_auth";s:1:"1";}');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `campus_connect_course_group`
--

DROP TABLE IF EXISTS `campus_connect_course_group`;
CREATE TABLE `campus_connect_course_group` (
  `cg_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `Seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `parallelgroup_id` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`cg_id`,`Seminar_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `campus_connect_course_group`
--

INSERT INTO `campus_connect_course_group` (`cg_id`, `Seminar_id`, `parallelgroup_id`) VALUES
('7', '7d784fb5cb9a5b187bfda24fd0f613dd', NULL),
('7', '713f4c09e20c17deb5efe4a0dba2cee7', '11'),
('7', '9598160de9b44d5d229eab2a0126cacc', '12');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `campus_connect_entities`
--

DROP TABLE IF EXISTS `campus_connect_entities`;
CREATE TABLE `campus_connect_entities` (
  `item_id` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `type` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `foreign_id` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `participant_id` int(11) NOT NULL,
  `data` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`item_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `campus_connect_entities`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `campus_connect_trees`
--

DROP TABLE IF EXISTS `campus_connect_trees`;
CREATE TABLE `campus_connect_trees` (
  `tree_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `root_id` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `participant_id` int(11) NOT NULL,
  `title` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `mapping` enum('pending','all','manual') COLLATE latin1_general_ci NOT NULL DEFAULT 'pending',
  `sem_tree_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `data` text COLLATE latin1_general_ci NOT NULL,
  `chdate` bigint(20) NOT NULL,
  `mkdate` bigint(20) NOT NULL,
  PRIMARY KEY (`tree_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `campus_connect_trees`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `campus_connect_tree_items`
--

DROP TABLE IF EXISTS `campus_connect_tree_items`;
CREATE TABLE `campus_connect_tree_items` (
  `item_id` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `participant_id` int(11) NOT NULL,
  `title` varchar(128) COLLATE latin1_general_ci NOT NULL,
  `parent_id` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `root_id` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `sem_tree_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `mapped_sem_tree_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `data` text COLLATE latin1_general_ci NOT NULL,
  `chdate` bigint(20) NOT NULL,
  `mkdate` bigint(20) NOT NULL,
  PRIMARY KEY (`item_id`,`participant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `campus_connect_tree_items`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `campus_connect_trigger_stack`
--

DROP TABLE IF EXISTS `campus_connect_trigger_stack`;
CREATE TABLE `campus_connect_trigger_stack` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `object_type` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `mkdate` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=28 ;

--
-- Daten für Tabelle `campus_connect_trigger_stack`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `chat_data`
--

DROP TABLE IF EXISTS `chat_data`;
CREATE TABLE `chat_data` (
  `id` int(11) NOT NULL DEFAULT '0',
  `data` mediumblob NOT NULL,
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `chat_data`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `comment_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `object_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `content` text COLLATE latin1_general_ci NOT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `object_id` (`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `comments`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `config_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `value` text COLLATE latin1_general_ci NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT '0',
  `type` enum('boolean','integer','string') COLLATE latin1_general_ci NOT NULL DEFAULT 'boolean',
  `range` enum('global','user') COLLATE latin1_general_ci NOT NULL DEFAULT 'global',
  `section` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `description` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `comment` text COLLATE latin1_general_ci NOT NULL,
  `message_template` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`config_id`),
  KEY `parent_id` (`parent_id`),
  KEY `field` (`field`,`range`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `config`
--

INSERT INTO `config` (`config_id`, `parent_id`, `field`, `value`, `is_default`, `type`, `range`, `section`, `position`, `mkdate`, `chdate`, `description`, `comment`, `message_template`) VALUES
('7291d64d9cc4ea43ee9e8260f05a4111', '', 'MAIL_NOTIFICATION_ENABLE', '0', 1, 'boolean', 'global', '', 0, 1122996278, 1122996278, 'Informationen über neue Inhalte per email verschicken', '', ''),
('9f6d7e248f58d1b211314dfb26c77d63', '', 'RESOURCES_ALLOW_DELETE_REQUESTS', '1', 1, 'boolean', 'global', 'resources', 0, 1136826903, 1136826903, 'Erlaubt das Löschen von Raumanfragen für globale Ressourcenadmins', '', ''),
('25bdaf939c88ee79bf3da54165d61a48', '', 'MAINTENANCE_MODE_ENABLE', '0', 1, 'boolean', 'global', '', 0, 1130840930, 1130840930, 'Schaltet das System in den Wartungsmodus, so dass nur noch Administratoren Zugriff haben', '', ''),
('88c038ca4fb36764ff6486d72379e1ae', '', 'ZIP_UPLOAD_MAX_FILES', '100', 1, 'integer', 'global', 'files', 0, 1130840930, 1130840930, 'Die maximale Anzahl an Dateien, die bei einem Zipupload automatisch entpackt werden', '', ''),
('c1f9ef95f501893c73e2654296c425f2', '', 'ZIP_UPLOAD_ENABLE', '1', 1, 'boolean', 'global', 'files', 0, 1130840930, 1130840930, 'Ermöglicht es, ein Zip Archiv hochzuladen, welches automatisch entpackt wird', '', ''),
('d733eb0f9ef6db9fb3b461dd4df22376', '', 'ZIP_UPLOAD_MAX_DIRS', '10', 1, 'integer', 'global', 'files', 0, 1130840962, 1130840962, 'Die maximale Anzahl an Verzeichnissen, die bei einem Zipupload automatisch entpackt werden', '', ''),
('1c07aa46c6fe6fea26d9b0cfd8fbcd19', '', 'SENDFILE_LINK_MODE', 'normal', 1, 'string', 'global', 'files', 0, 1141212096, 1141212096, 'Format der Downloadlinks: normal=sendfile.php?parameter=x, old=sendfile.php?/parameter=x, rewrite=download/parameter/file.txt', '', ''),
('9d4956b4eac20f03b60b17d7ac30b40a', '', 'SEMESTER_TIME_SWITCH', '0', 1, 'integer', 'global', '', 0, 1140013696, 1140013696, 'Anzahl der Wochen vor Semesterende zu dem das vorgewählte Semester umspringt', '', ''),
('06cdb765fb8f0853e3ebe08f51c3596e', '', 'RESOURCES_ENABLE', '1', 1, 'boolean', 'global', '', 0, 0, 0, 'Enable the Stud.IP resource management module', '', ''),
('3d415eca6003321f09e59407e4a7994d', '', 'RESOURCES_LOCKING_ACTIVE', '', 1, 'boolean', 'global', 'resources', 0, 0, 1100709567, 'Schaltet in der Ressourcenverwaltung das Blockieren der Bearbeitung für einen Zeitraum aus (nur Admins dürfen in dieser Zeit auf die Belegung zugreifen)', '', ''),
('b7a2817d142443245df2f5ac587fe218', '', 'RESOURCES_ALLOW_ROOM_REQUESTS', '1', 1, 'boolean', 'global', 'resources', 0, 0, 1100709567, 'Schaltet in der Ressourcenverwaltung das System zum Stellen und Bearbeiten von Raumanfragen ein oder aus', '', ''),
('d821ffbff29ce636c6763ffe3fd8b427', '', 'RESOURCES_ALLOW_CREATE_ROOMS', '2', 1, 'integer', 'global', 'resources', 0, 0, 1100709567, 'Welche Rechstufe darf  Räume anlegen? 1 = Nutzer ab Status tutor, 2 = Nutzer ab Status admin, 3 = nur Ressourcenadministratoren', '', ''),
('5a6e2342b90530ed50ad8497054420c0', '', 'RESOURCES_ALLOW_ROOM_PROPERTY_REQUESTS', '1', 1, 'boolean', 'global', 'resources', 0, 0, 1074780851, 'Schaltet in der Ressourcenverwaltung die Möglichkeit, im Rahmen einer Anfrage Raumeigenschaften zu wünschen, ein oder aus', '', ''),
('e4123cf9158cd0b936144f0f4cf8dfa3', '', 'RESOURCES_INHERITANCE_PERMS_ROOMS', '1', 1, 'integer', 'global', 'resources', 0, 0, 1100709567, 'Art der Rechtevererbung in der Ressourcenverwaltung für Räume: 1 = lokale Rechte der Einrichtung und Veranstaltung werden übertragen, 2 = nur Autorenrechte werden vergeben, 3 = es werden keine Rechte vergeben', '', ''),
('45856b1e3407ce565d87ec9b8fd32d7d', '', 'RESOURCES_INHERITANCE_PERMS', '1', 1, 'integer', 'global', 'resources', 0, 0, 1100709567, 'Art der Rechtevererbung in der Ressourcenverwaltung für Ressourcen (nicht Räume): 1 = lokale Rechte der Einrichtung und Veranstaltung werden übertragen, 2 = nur Autorenrechte werden vergeben, 3 = es werden keine Rechte vergeben', '', ''),
('c353c73d8f37e3c301ae34898c837af4', '', 'RESOURCES_ENABLE_ORGA_CLASSIFY', '1', 1, 'boolean', 'global', 'resources', 0, 0, 1100709567, 'Schaltet in der Ressourcenverwaltung das Einordnen von Ressourcen in Orga-Struktur (ohne Rechtevergabe) ein oder aus', '', ''),
('0821671742242add144595b1112399fb', '', 'RESOURCES_ALLOW_SINGLE_ASSIGN_PERCENTAGE', '50', 1, 'integer', 'global', 'resources', 0, 0, 1100709567, 'Wert (in Prozent), ab dem ein Raum mit Einzelbelegungen (statt Serienbelegungen) gefüllt wird, wenn dieser Anteil an möglichen Belegungen bereits durch andere Belegungen zu Überschneidungen führt', '', ''),
('94d1643209a8f404dfe71228aad5345d', '', 'RESOURCES_ALLOW_SINGLE_DATE_GROUPING', '5', 1, 'integer', 'global', 'resources', 0, 0, 1100709567, 'Anzahl an Einzeltermine, ab der diese als Gruppe zusammengefasst bearbeitet werden', '', ''),
('d29daf70897da5f89d44013260f26abd', '', 'AJAX_AUTOCOMPLETE_DISABLED', '0', 1, 'boolean', 'global', '', 0, 1293118060, 1293118060, 'Sollen alle QuickSearches deaktiviertes Autocomplete haben? Wenn es zu Performanceproblemen kommt, kann es sich lohnen, diese Variable auf true zu stellen.', '', ''),
('f2f8a47ea69ed9ccba5573e85a15662c', '', 'ACCESSKEY_ENABLE', '', 1, 'boolean', 'user', '', 0, 0, 0, 'Schaltet die Nutzung von Shortcuts für einen User ein oder aus, Systemdefault', '', ''),
('0b00c75bc76abe0dd132570403b38e5c', '', 'NEWS_RSS_EXPORT_ENABLE', '1', 1, 'boolean', 'global', '', 0, 0, 0, 'Schaltet die Möglichkeit des rss-Export von privaten News global ein oder aus', '', ''),
('42d237f9dfd852318cdc66319043536d', '', 'FOAF_SHOW_IDENTITY', '', 1, 'boolean', 'user', 'privacy', 0, 0, 0, 'Schaltet für einen User ein oder aus, ob dieser in FOAS-Ketten angezeigt wird, Systemdefault', '', ''),
('6ae7aecf299930cbb8a5e89bbab4da55', '', 'FOAF_ENABLE', '1', 1, 'boolean', 'global', '', 0, 0, 0, 'FOAF Feature benutzen?', '', ''),
('a52e3b62ac0bee819b782d8979960b7b', '', 'RESOURCES_ENABLE_GROUPING', '1', 1, 'boolean', 'global', 'resources', 0, 0, 1121861801, 'Schaltet in der Ressourcenverwaltung die Funktion zur Verwaltung von Raumgruppen ein oder aus', '', ''),
('76cac679fa57fdbb3f9d6cee20bf8c6f', '', 'RESOURCES_ENABLE_SEM_SCHEDULE', '1', 1, 'boolean', 'global', 'resources', 0, 0, 0, 'Schaltet in der Ressourcenverwaltung ein, ob ein Semesterbelegungsplan erstellt werden kann', '', ''),
('3af783748f92cdf99b066d4227f8dffc', '', 'RESOURCES_SEARCH_ONLY_REQUESTABLE_PROPERTY', '1', 1, 'boolean', 'global', 'resources', 0, 0, 0, 'Schaltet in der Suche der Ressourcenverwaltun das Durchsuchen von nicht wünschbaren Eigenschaften ein oder aus', '', ''),
('fe498bb91a4cbfdfd5078915e979153c', '', 'RESOURCES_ENABLE_VIRTUAL_ROOM_GROUPS', '1', 1, 'boolean', 'global', 'resources', 0, 0, 0, 'Schaltet in der Ressourcenverwaltung automatische gebildete Raumgruppen neben per Konfigurationsdatei definierten Gruppen ein oder aus', '', ''),
('68b127dde744085637d221e11d4e8cf2', '', 'RESOURCES_ALLOW_CREATE_TOP_LEVEL', '', 1, 'boolean', 'global', 'resources', 0, 0, 0, 'Schaltet für die Ressourcenverwaltung ein, ob neue Hierachieebenen von anderen Nutzern als Admins angelegt werden können oder nicht', '', ''),
('b16359d5514b13794689eab669124c69', '', 'ALLOW_DOZENT_VISIBILITY', '', 1, 'boolean', 'global', 'permissions', 0, 0, 0, 'Schaltet ein oder aus, ob ein Dozent eigene Veranstaltungen selbst verstecken darf oder nicht', '', ''),
('e8cd96580149cde65ad69b6cf18d5c39', '', 'ALLOW_DOZENT_ARCHIV', '', 1, 'boolean', 'global', 'permissions', 0, 0, 1109946684, 'Schaltet ein oder aus, ob ein Dozent eigene Veranstaltungen selbst archivieren darf oder nicht', '', ''),
('24ecbeb431826c61fd8b53b3aa41bfa6', '', 'SHOWSEM_ENABLE', '1', 1, 'boolean', 'user', '', 0, 1122461027, 1122461027, 'Einstellung für Nutzer, ob Semesterangaben in der Übersicht "Meine Veranstaltung" nach dem Titel der Veranstaltung gemacht werden; Systemdefault', '', ''),
('91e6e53b3748a53c42440453e8045be3', '', 'RESOURCES_ALLOW_SEMASSI_SKIP_REQUEST', '1', 1, 'boolean', 'global', 'resources', 0, 1122565305, 1122565305, 'Schaltet das Pflicht, eine Raumanfrage beim Anlegen einer Veranstaltung machen zu müssen, ein oder aus', '', ''),
('f32367b1542a1d513ecee8a26e26d239', '', 'RESOURCES_SCHEDULE_EXPLAIN_USER_NAME', '1', 1, 'boolean', 'global', 'resources', 0, 1123516671, 1123516671, 'Schaltet in der Ressourcenverwaltung die Anzeige der Namen des Belegers in der Ausgabe von Belegungsplänen ein oder aus', '', ''),
('4c52bfa598daa03944a401b66c53d828', '', 'NEWS_DISABLE_GARBAGE_COLLECT', '0', 1, 'boolean', 'global', '', 0, 1123751948, 1123751948, 'Schaltet den Garbage-Collect für News ein oder aus', '', ''),
('9e0579653e585a688665a6ea2e2d7c90', '', 'EVAL_AUSWERTUNG_CONFIG_ENABLE', '1', 1, 'boolean', 'global', 'evaluation', 0, 1141225624, 1141225624, 'Ermöglicht es dem Nutzer, die grafische Darstellung der Evaluationsauswertung zu konfigurieren', '', ''),
('0ad11a4cafa548d3c72a3dc1776568d8', '', 'EVAL_AUSWERTUNG_GRAPH_FORMAT', 'png', 1, 'string', 'global', 'evaluation', 0, 1141225624, 1141225624, 'Das Format, in dem die Diagramme der grafischen Evaluationsauswertung erstellt werden (jpg, png, gif).', '', ''),
('781e0998a1b5c998ebbc02a4f0d907ac', '', 'USER_VISIBILITY_UNKNOWN', '1', 1, 'boolean', 'global', 'privacy', 0, 1153815901, 1153815901, 'Sollen Nutzer mit Sichtbarkeit "unknown" wie sichtbare behandelt werden?', '', ''),
('3ca9d678f11a73917420161180838205', '', 'CHAT_USE_AJAX_CLIENT', '1', 1, 'boolean', 'user', '', 0, 1153815830, 1153815830, 'Einstellung für Nutzer, ob der AJAX chatclient benutzt werden soll; Systemdefault', '', ''),
('54ad03142e6704434976c9a0df8329c8', '', 'ONLINE_NAME_FORMAT', 'full_rev', 1, 'string', 'user', '', 0, 1153814980, 1153814980, 'Default-Wert für wer-ist-online Namensformatierung', '', ''),
('8a147b2d487d7ae91264f03cab5d8c07', '', 'ADMISSION_PRELIM_COMMENT_ENABLE', '0', 1, 'boolean', 'global', '', 0, 1153814966, 1153814966, 'Schaltet ein oder aus, ob ein Nutzer im Modus "Vorläufiger Eintrag" eine Bemerkung hinterlegen kann', '', ''),
('a93eb21bb08719b3a522b7e238bd8b7e', '', 'EXTERNAL_HELP', '1', 1, 'boolean', 'global', '', 0, 1155128579, 1155128579, 'Schaltet das externe Hilfesystem ein', '', ''),
('10367c279370c7f78552d2747c2b169c', '', 'EXTERNAL_HELP_LOCATIONID', 'default', 1, 'string', 'global', '', 0, 1155128579, 1155128579, 'Eine eindeutige ID zur Identifikation der gewünschten Hilfeseiten, leer bedeutet Standardhilfe', '', ''),
('6679a9cf02e56c0fce92e91b8f696005', '', 'EXTERNAL_HELP_URL', 'http://hilfe.studip.de/index.php/%s', 1, 'string', 'global', '', 0, 1155128579, 1155128579, 'URL Template für das externe Hilfesystem', '', ''),
('4cd2cd3cc207ffc0ae92721c291cd906', '', 'RESOURCES_SHOW_ROOM_NOT_BOOKED_HINT', '0', 1, 'boolean', 'global', 'resources', 0, 1168444600, 1168444600, 'Einstellung, ob bei aktivierter Raumverwaltung Raumangaben die nicht gebucht sind gekennzeichnet werden', '', ''),
('3b6a1623b8e0913430d6a27bfda976fd', '', 'ADMISSION_ALLOW_DISABLE_WAITLIST', '1', 1, 'boolean', 'global', '', 0, 1170242650, 1170242650, 'Schaltet ein oder aus, ob die Warteliste in Zugangsbeschränkten Veranstaltungen deaktiviert werden kann', '', ''),
('08f085d9ef2ee7d8b355dcc35282ab8c', '', 'ENABLE_SKYPE_INFO', '1', 1, 'boolean', 'global', 'privacy', 0, 1170242666, 1170242666, 'Ermöglicht die Eingabe / Anzeige eines Skype Namens ', '', ''),
('615e92cdf78c1436c3fc1f60a8cd944e', '', 'SEM_VISIBILITY_PERM', 'root', 1, 'string', 'global', 'permissions', 0, 1170242706, 1170242706, 'Bestimmt den globalen Nutzerstatus, ab dem versteckte Veranstaltungen in der Suche gefunden werden (root,admin,dozent)', '', ''),
('4158d433b57052b20fd66d84b71c7324', '', 'SEM_CREATE_PERM', 'dozent', 1, 'string', 'global', 'permissions', 0, 1170242930, 1170242930, 'Bestimmt den globalen Nutzerstatus, ab dem Veranstaltungen angelegt werden dürfen (root,admin,dozent)', '', ''),
('93da66ca9e2d17df5bc61bd56406add7', '', 'RESOURCES_ROOM_REQUEST_DEFAULT_ACTION', 'NO_ROOM_INFO_ACTION', 1, 'string', 'global', 'resources', 0, 0, 0, 'Designates the pre-selected action for the room request dialog', 'Valid values are: NO_ROOM_INFO_ACTION, ROOM_REQUEST_ACTION, BOOKING_OF_ROOM_ACTION, FREETEXT_ROOM_ACTION', ''),
('0d3f84ed4dd6b7147b504ffb5b6fbc2c', '', 'RESOURCES_ENABLE_EXPERT_SCHEDULE_VIEW', '0', 1, 'boolean', 'global', 'resources', 0, 12, 12, 'Enables the expert view of the course schedules', '', ''),
('bc3004618b17b29dc65e10e89be9a7a0', '', 'RESOURCES_ENABLE_BOOKINGSTATUS_COLORING', '1', 1, 'boolean', 'global', 'resources', 0, 0, 0, 'Enable the colored presentation of the room booking status of a date', '', ''),
('cb92d5bb08f346567dbd394d0d553454', '', 'EMAIL_DOMAIN_RESTRICTION', '', 1, 'string', 'global', '', 0, 1157107088, 1157107088, 'Beschränkt die gültigkeit von Email-Adressen bei freier Registrierung auf die angegebenen Domains. Komma-separierte Liste von Domains ohne vorangestelltes @.', '', ''),
('791c632089d80d63bf910e661e378fca', '', 'MAIL_AS_HTML', '0', 1, 'boolean', 'user', '', 0, 1293118060, 1293118060, 'Benachrichtigungen werden im HTML-Format versandt', '', ''),
('3acf297f781b0c0aefd551ec304b902d', '', 'DOCUMENTS_EMBEDD_FLASH_MOVIES', 'deny', 1, 'string', 'global', 'files', 0, 1157107088, 1157107088, 'Sollen im Dateibereich Flash-Filme direkt in einem Player angezeigt werden? deny=nicht erlaubt, allow=erlaubt, autoload=Film wird beim aufklappen geladen (incrementiert Downloads), autoplay=Film wird sofort abgespielt', '', ''),
('e2d53231d99575a728cb84b0defc3569', '', 'ZIP_DOWNLOAD_MAX_FILES', '100', 1, 'integer', 'global', 'files', 0, 1219328498, 1219328498, 'Die maximale Anzahl an Dateien, die gezippt heruntergeladen werden kann', '', ''),
('be1cd744e51e87d8c0c1cb9a6c171887', '', 'ZIP_DOWNLOAD_MAX_SIZE', '100', 1, 'integer', 'global', 'files', 0, 1219328498, 1219328498, 'Die maximale Größe aller Dateien, die zusammen in einem Zip heruntergeladen werden kann (in Megabytes).', '', ''),
('b8faa6e4bdb8ec8d095f5ea1d04950c0', '', 'RANGE_TREE_ADMIN_PERM', 'admin', 1, 'string', 'global', 'permissions', 0, 1219328498, 1219328498, 'mit welchem Status darf die Einrichtungshierarchie bearbeitet werden (admin oder root)', '', ''),
('e0b4d32bd6da9a430c2644bd5ea3ab3b', '', 'SEM_TREE_ADMIN_PERM', 'admin', 1, 'string', 'global', 'permissions', 0, 1219328498, 1219328498, 'mit welchem Status darf die Veranstaltungshierarchie bearbeitet werden (admin oder root)', '', ''),
('fb5d5b3f1a0b70ded3c5770f30ec2ac1', '', 'SEMESTER_ADMINISTRATION_ENABLE', '1', 1, 'boolean', 'global', '', 0, 1219328498, 1219328498, 'schaltet die Semesterverwaltung ein oder aus', '', ''),
('34f348c06bbd5d9fc7bb36a8d829e12e', '', 'SEM_TREE_ALLOW_BRANCH_ASSIGN', '1', 1, 'boolean', 'global', '', 0, 1222947575, 1222947575, 'Diese Option beeinflusst die Möglichkeit, Veranstaltungen entweder nur an die Blätter oder überall in der Veranstaltungshierarchie einhängen zu dürfen.', '', ''),
('b213cfe252348f6934b3be424d97eebf', '', 'MESSAGE_PRIORITY', '0', 1, 'boolean', 'global', '', 0, 1240427632, 1240427632, 'If enabled, messages of high priority are displayed reddish', '', ''),
('9212fb9cfd117f462c36b276838493f2', '', 'RESTRICTED_USER_MANAGEMENT', '0', 1, 'boolean', 'global', 'permissions', 0, 1240427632, 1240427632, 'Schränkt Zugriff auf die globale Nutzerverwaltung auf root ein', '', ''),
('664fba27a9f0d8be2a68db04ecc919e1', '', 'AUX_RULE_ADMIN_PERM', 'admin', 1, 'string', 'global', 'permissions', 0, 1240427632, 1240427632, 'mit welchem Status dürfen Zusatzangaben definiert werden (admin, root)', '', ''),
('759849f5dbc68a74df6905a8187ee59a', '', 'LOCK_RULE_ADMIN_PERM', 'admin', 1, 'string', 'global', 'permissions', 0, 1240427632, 1240427632, 'mit welchem Status dürfen Sperrebenen angepasst werden (admin, root)', '', ''),
('62ccc1c5408de882f38de933cecaf88f', '', 'ALLOW_SELFASSIGN_INSTITUTE', '1', 1, 'boolean', 'global', 'permissions', 0, 1240427632, 1240427632, 'Wenn eingeschaltet, dürfen Studenten sich selbst Einrichtungen an denen sie studieren zuordnen.', '', ''),
('7fc613594ac8a9f44b6280c6dd3d653e', '', 'ALLOW_ADMIN_USERACCESS', '1', 1, 'boolean', 'global', 'permissions', 0, 1240427632, 1240427632, 'Wenn eingeschaltet, dürfen Administratoren sensible Nutzerdaten wie z.B. Passwörter ändern.', '', ''),
('cd1ba192616b66967b51f8e8f8155fb5', '', 'SEM_TREE_SHOW_EMPTY_AREAS_PERM', 'user', 1, 'string', 'global', 'permissions', 0, 1240427632, 1240427632, 'Bestimmt den globalen Nutzerstatus, ab dem in der Veranstaltungssuche auch Bereiche angezeigt werden, denen keine Veranstaltungen zugewiesen sind.', '', ''),
('06d703c3de37cdae942c66e18f7dcd02', '', 'ASSI_SEMESTER_PRESELECT', '1', 1, 'boolean', 'global', '', 0, 1257956185, 1257956185, 'Wenn ausgeschaltet wird im admin_seminare_assi beimErstellen einer Veranstaltung als Semester bitte auswählen angezeigt und nicht das voreingestellte Semester.', '', ''),
('274e61e0b19ab9edadb4be9764aa17a2', '', 'RESOURCES_HIDE_PAST_SINGLE_DATES', '1', 1, 'boolean', 'global', 'resources', 0, 1257956185, 1257956185, 'Schaltet in der Ressourcenverwaltung ein,ob bereits vergangene Terminen bei der Buchung und Planung brücksichtigt werden sollen', '', ''),
('64031f867c3688ecf1c697bd79eff230', '', 'RESOURCES_ALLOW_ROOM_REQUESTS_ALL_ROOMS', '1', 1, 'boolean', 'global', 'resources', 0, 1257956185, 1257956185, 'Schaltet in der Ressourcenverwaltung ein,ob alle Räume gewünscht werden können, oder nur eigene und ''Global'' gesetzte', '', ''),
('f2ce635d994363fad26e010f5dbae2c4', '', 'STUDYGROUPS_ENABLE', '0', 1, 'boolean', 'global', 'studygroups', 0, 1257956185, 1293118059, 'Schaltet ein oder aus, ob die Studiengruppen global verfügbar sind.', '', ''),
('ebe2dd4ffa77bb1966c5940272d7c8dd', '', 'STUDYGROUP_TERMS', 'Mir ist bekannt, dass ich die Gruppe nicht zu rechtswidrigen Zwecken nutzen darf. Dazu zählen u.a. Urheberrechtsverletzungen, Beleidigungen und andere Persönlichkeitsdelikte.\n\nIch erkläre mich damit einverstanden, dass AdministratorInnen die Inhalte der Gruppe zu Kontrollzwecken einsehen dürfen.', 1, 'string', 'global', 'studygroups', 0, 1257956185, 1257956185, 'Hier werden die Nutzungsbedinungen der Studiengruppen hinterlegt.', '', ''),
('c73737d9119e86faa22810a1c154271e', '', 'STUDYGROUP_SETTINGS', 'forum:1 documents:0 schedule:0 participants:1', 1, 'string', 'global', 'studygroups', 0, 1257956185, 1257956185, 'Hier werden die globalen Einstellungen aller Studiengruppen hinterlegt.', '', ''),
('da0a01b50f472296f940de98c56b5a9f', '', 'STUDYGROUP_DEFAULT_INST', '', 1, 'string', 'global', 'studygroups', 0, 1258042892, 1258042892, 'Die Standardeinrichtung für Studiengruppen kann hier gesetzt werden.', '', ''),
('e776a479dc024fb9b6478be3f60455da', '', 'ENABLE_PROTECTED_DOWNLOAD_RESTRICTION', '0', 1, 'boolean', 'global', 'files', 0, 1257956185, 1257956185, 'Schaltet die Überprüfung (fester Teilnehmerkreis) bei Download von als geschützt markierten Dateien ein', '', ''),
('9e601ed3a973474c0aac3d7a18c5bf02', '', 'DOZENT_ALWAYS_VISIBLE', '1', 1, 'boolean', 'global', 'privacy', 0, 1293118059, 1293118059, 'Legt fest, ob Personen mit Dozentenrechten immer global sichtbar sind und das auch nicht selbst ändern können.', '', ''),
('80ccace5c451cec67d88da1edb4b5eec', '', 'HOMEPAGE_VISIBILITY_DEFAULT', 'VISIBILITY_STUDIP', 1, 'string', 'global', 'privacy', 0, 1293118059, 1293118059, 'Standardsichtbarkeit für Homepageelemente, falls der Benutzer nichts anderes eingestellt hat. Gültige Werte sind: VISIBILITY_ME, VISIBILITY_BUDDIES, VISIBILITY_DOMAIN, VISIBILITY_STUDIP, VISIBILITY_EXTERN', '', ''),
('1115645eb5439f998a8cc6f4a3a9dccf', '', 'FORUM_ANONYMOUS_POSTINGS', '0', 1, 'boolean', 'global', 'privacy', 0, 1293118059, 1293118059, 'Legt fest, ob Forenbeiträge anonym verfasst werden dürfen (Root sieht aber immer den Urheber).', '', ''),
('d1eef8315d340d78d7eca557139937f1', '', 'INST_FAK_ADMIN_PERMS', 'all', 1, 'string', 'global', 'permissions', 0, 1293118059, 1293118059, '"none" Fakultätsadmin darf Einrichtungen weder anlegen noch löschen, "create" Fakultätsadmin darf Einrichtungen anlegen, aber nicht löschen, "all" Fakultätsadmin darf Einrichtungen anlegen und löschen.', '', ''),
('48c97315d9c6473cd7aad2e311daa55e', '', 'CHAT_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob der Chat global verfügbar ist.', '', ''),
('45e7816a1bfb1521e7a1d6311a964b00', '', 'CALENDAR_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob der Kalender global verfügbar ist.', '', ''),
('be154136cfaf6ed1c753a6cc26c2ec66', '', 'EXPORT_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob der Export global verfügbar ist.', '', ''),
('8481ee7faec9805d577de600a0835bc3', '', 'EXTERN_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob die externen Seiten global verfügbar sind.', '', ''),
('ded48fe2ca250e104dc33fb6f0b42c67', '', 'VOTE_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob die Umfragen global verfügbar sind.', '', ''),
('46a02bfefc7b643a1ea40b7e10d4c037', '', 'ELEARNING_INTERFACE_ENABLE', '0', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob die Lernmodule global verfügbar sind.', '', ''),
('13352bc45ff23f577340eb88e343a3ec', '', 'STM_ENABLE', '0', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob die Studienmodule global verfügbar sind.', '', ''),
('ad82e1d6bd97320244362974c460bc7d', '', 'WIKI_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob das Wiki global verfügbar ist.', '', ''),
('250306a36a09d6465ee3fd24c66932f4', '', 'SMILEYADMIN_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob die Administration der Smileys verfügbar ist.', '', ''),
('bdc9e8e9f5174f3ef668a87adef906eb', '', 'LOG_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob das Log global verfügbar ist.', '', ''),
('826a49fd9f9aaea20e85adbad9b095af', '', 'SCM_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob freie Informationsseiten global verfügbar sind.', '', ''),
('edc2bf96acd7bac3bf923a71a12abb13', '', 'BANNER_ADS_ENABLE', '0', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob die Bannerwerbung global verfügbar ist.', '', ''),
('0109868144360b658367d61aa6f16906', '', 'LITERATURE_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1293118059, 1293118059, 'Schaltet ein oder aus, ob die Literaturverwaltung global verfügbar ist.', '', ''),
('0faeba67819f6cc2016f4a5b017c36f6', '', 'MY_COURSES_FORCE_GROUPING', 'sem_number', 1, 'string', 'global', '', 0, 1293118059, 1293118059, 'Legt fest, ob die persönliche Veranstaltungsübersicht systemweit zwangsgruppiert werden soll, wenn keine eigene Gruppierung eingestellt ist. Werte: not_grouped, sem_number, sem_tree_id, sem_status, gruppe, dozent_id.', '', ''),
('e274953d097e32023b477d1ad895dfc8', '', 'DEPUTIES_ENABLE', '0', 1, 'boolean', 'global', 'deputies', 0, 1293118059, 1293118059, 'Legt fest, ob die Funktion Dozierendenvertretung aktiviert ist.', '', ''),
('18b2970268e2143f8ee142cbadf38de5', '', 'DEPUTIES_DEFAULTENTRY_ENABLE', '0', 1, 'boolean', 'global', 'deputies', 0, 1293118059, 1293118059, 'Dürfen DozentInnen Standardvertretungen festlegen? Diese werden automatisch bei Hinzufügen des Dozenten/der Dozentin als Vertretung in Veranstaltungen eingetragen.', '', ''),
('8e596c37d6a921e38de1576eca50d5b6', '', 'DEPUTIES_EDIT_ABOUT_ENABLE', '1', 1, 'boolean', 'global', 'deputies', 0, 1293118059, 1293118059, 'Dürfen DozentInnen ihren Standardvertretungen erlauben, ihr Profil zu bearbeiten?', '', ''),
('dada821b887f0fca1a45e9e339a5aff7', '', 'FILESYSTEM_MULTICOPY_ENABLE', '1', 1, 'boolean', 'global', '', 0, 1293118059, 1293118059, 'Soll es erlaubt sein, das Dozenten Ordner oder Dateien in mehrere Veranstaltungen bzw. Institute verschieben oder kopieren dürfen?', '', ''),
('dc99e1c9623b6971629a304f174cd3b0', '', 'ALLOW_METADATE_SORTING', '0', 1, 'boolean', 'global', 'permissions', 0, 1293118059, 1293118059, 'Soll es erlaubt sein, dass regelmäßige Zeiten einer Veranstaltung frei sortiert werden können?', '', ''),
('c304d6f383297f9506d7acf7ee42c460', '', 'LOAD_EXTERNAL_MEDIA', 'deny', 1, 'string', 'global', '', 0, 1293118060, 1293118060, 'Sollen externe Medien über [img/flash/audio/video] eingebunden werden? deny=nicht erlaubt, allow=erlaubt, proxy=proxy benutzen.', '', ''),
('ece3432a2267af28f4e7729d549ca9ea', '', 'ENTRIES_PER_PAGE', '20', 1, 'integer', 'global', 'global', 0, 1311411856, 1311411856, 'Anzahl von Einträgen pro Seite', '', ''),
('ce272afc2347f03fcbc69568f8a0098a', '', 'PDF_LOGO', '', 1, 'string', 'global', 'global', 0, 1311411856, 1311411856, 'Geben Sie hier den absoluten Pfad auf Ihrem Server (also ohne http) zu einem Logo an, das bei PDF-Exporten im Kopfbereich verwendet wird.', '', ''),
('86bbdf3b3ac03a5ad6be7c3c7cd402d4', '', 'AUTO_INSERT_SEM_PARTICIPANTS_VIEW_PERM', 'tutor', 1, 'string', 'global', 'global', 0, 1311411856, 1311411856, 'Ab welchem Status soll in Veranstaltungen mit automatisch eingetragenen Nutzern der Teilnehmerreiter zu sehen sein?', '', ''),
('f2469d9595be17d9ef4dd8b45b51f794', '', 'SKIPLINKS_ENABLE', '', 1, 'boolean', 'user', 'privacy', 0, 1311411856, 1311411856, 'Wählen Sie diese Option, um Skiplinks beim ersten Drücken der Tab-Taste anzuzeigen (Systemdefault).', '', ''),
('56fdc51c067684a628d3d2535f8f2789', '', 'CHAT_VISIBILITY_DEFAULT', '1', 1, 'boolean', 'global', 'privacy', 0, 1326799691, 1326799691, 'Ist der private Chatraum sichtbar, falls der Nutzer nichts anderes eingestellt hat?', '', ''),
('7f6084adb44da8c24647109544db4d1d', '', 'EMAIL_VISIBILITY_DEFAULT', '1', 1, 'boolean', 'global', 'privacy', 0, 1326799691, 1326799691, 'Ist die eigene Emailadresse sichtbar, falls der Nutzer nichts anderes eingestellt hat?', '', ''),
('5591ed8d2ff2afeb186d5f788cbb7e2f', '', 'ONLINE_VISIBILITY_DEFAULT', '1', 1, 'boolean', 'global', 'privacy', 0, 1326799691, 1326799691, 'Sind Nutzer sichtbar in der Wer ist online-Liste, falls sie nichts anderes eingestellt haben?', '', ''),
('94bca8fa4c2ad851ddaf26df8b7ec1d3', '', 'SEARCH_VISIBILITY_DEFAULT', '1', 1, 'boolean', 'global', 'privacy', 0, 1326799691, 1326799691, 'Sind Nutzer auffindbar in der Personensuche, falls sie nichts anderes eingestellt haben?', '', ''),
('e414e0834adc8c2815787da81ed29a51', '', 'PROPOSED_TEACHER_LABELS', '', 1, 'string', 'global', 'global', 0, 1326799692, 1326799692, 'Write a list of comma separated possible labels for teachers and tutor here.', '', ''),
('88a3a312b783c9d890b77e84a51853fa', '', 'SCHEDULE_ENABLE', '1', 1, 'boolean', 'global', 'modules', 0, 1326799692, 1326799692, 'Schaltet ein oder aus, ob der Stundenplan global verfügbar ist.', '', ''),
('4a38babf107742cf71c8f7d23fea2c9a', '', 'CALENDAR_GROUP_ENABLE', '0', 1, 'boolean', 'global', 'modules', 0, 1326799692, 1326799692, 'Schaltet die Gruppenterminkalender-Funktionen ein.', '', ''),
('d7332ad7fba147d81bd1ccae6211284f', '', 'COURSE_CALENDAR_ENABLE', '0', 1, 'boolean', 'global', 'modules', 0, 1326799692, 1326799692, 'Kalender als Inhaltselement in Veranstaltungen.', '', ''),
('48f849a4927f8ac5231da5352076f16a', '', 'STUDYGROUPS_ENABLE', '1', 0, 'boolean', 'global', '', 0, 1268739461, 1268739461, 'Studiengruppen', 'Studiengruppen', ''),
('5175463a0ef7d17507716907c7491561', '', 'STUDYGROUP_SETTINGS', 'forum:1|documents:1|literature:0|chat:1|wiki:1|scm:0|documents_folder_permissions:0|participants:1|schedule:0', 0, 'string', 'global', '', 0, 1268739461, 1268739461, 'Studiengruppen', '', ''),
('9f1c998d46f55ac38da3a53072a4086b', '', 'STUDYGROUP_DEFAULT_INST', 'ec2e364b28357106c0f8c282733dbe56', 0, 'string', 'global', '', 0, 1268739461, 1268739461, 'Studiengruppen', '', ''),
('bcd4820eebd8e027cef91bc761ab9a75', '', 'STUDYGROUP_TERMS', 'Mir ist bekannt, dass ich die Gruppe nicht zu rechtswidrigen Zwecken nutzen darf. Dazu zählen u.a. Urheberrechtsverletzungen, Beleidigungen und andere Persönlichkeitsdelikte.\r\n\r\nIch erkläre mich damit einverstanden, dass AdministratorInnen die Inhalte der Gruppe zu Kontrollzwecken einsehen dürfen.', 0, 'string', 'global', '', 0, 1268739461, 1268739461, 'Studiengruppen', '', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `contact_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `owner_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `buddy` tinyint(4) NOT NULL DEFAULT '1',
  `calpermission` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`contact_id`),
  KEY `owner_id` (`owner_id`,`buddy`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `contact`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contact_userinfo`
--

DROP TABLE IF EXISTS `contact_userinfo`;
CREATE TABLE `contact_userinfo` (
  `userinfo_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `contact_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `content` text COLLATE latin1_general_ci NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userinfo_id`),
  KEY `contact_id` (`contact_id`),
  KEY `priority` (`priority`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `contact_userinfo`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `datafields`
--

DROP TABLE IF EXISTS `datafields`;
CREATE TABLE `datafields` (
  `datafield_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `object_type` enum('sem','inst','user','userinstrole','usersemdata','roleinstdata') COLLATE latin1_general_ci DEFAULT NULL,
  `object_class` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `edit_perms` enum('user','autor','tutor','dozent','admin','root') COLLATE latin1_general_ci DEFAULT NULL,
  `view_perms` enum('all','user','autor','tutor','dozent','admin','root') COLLATE latin1_general_ci DEFAULT NULL,
  `priority` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mkdate` int(20) unsigned DEFAULT NULL,
  `chdate` int(20) unsigned DEFAULT NULL,
  `type` enum('bool','textline','textarea','selectbox','date','time','email','phone','radio','combo','link') COLLATE latin1_general_ci NOT NULL DEFAULT 'textline',
  `typeparam` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`datafield_id`),
  KEY `object_type` (`object_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `datafields`
--

INSERT INTO `datafields` (`datafield_id`, `name`, `object_type`, `object_class`, `edit_perms`, `view_perms`, `priority`, `mkdate`, `chdate`, `type`, `typeparam`) VALUES
('ce73a10d07b3bb13c0132d363549efda', 'Matrikelnummer', 'user', '7', 'user', 'dozent', 0, NULL, NULL, 'textline', ''),
('ceb48772d038e856d47ae68e648f99ec', 'Export to Stud.IP 2', 'sem', NULL, 'dozent', 'dozent', 0, 1347363702, 1347363702, 'bool', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `datafields_entries`
--

DROP TABLE IF EXISTS `datafields_entries`;
CREATE TABLE `datafields_entries` (
  `datafield_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `content` text COLLATE latin1_general_ci,
  `mkdate` int(20) unsigned DEFAULT NULL,
  `chdate` int(20) unsigned DEFAULT NULL,
  `sec_range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`datafield_id`,`range_id`,`sec_range_id`),
  KEY `range_id` (`range_id`,`datafield_id`),
  KEY `datafield_id_2` (`datafield_id`,`sec_range_id`),
  KEY `datafields_contents` (`datafield_id`,`content`(32))
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `datafields_entries`
--

INSERT INTO `datafields_entries` (`datafield_id`, `range_id`, `content`, `mkdate`, `chdate`, `sec_range_id`) VALUES
('ceb48772d038e856d47ae68e648f99ec', '0d2df6a71f3317549a5f2f252863c62b', '1', 1347366509, 1347366521, ''),
('ce73a10d07b3bb13c0132d363549efda', 'e7a0a84b161f3e8c09b4a0a2e8a58147', '', 1351591672, 1351678947, '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `deputies`
--

DROP TABLE IF EXISTS `deputies`;
CREATE TABLE `deputies` (
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `gruppe` tinyint(4) NOT NULL DEFAULT '0',
  `notification` int(10) NOT NULL DEFAULT '0',
  `edit_about` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`range_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `deputies`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `dokumente`
--

DROP TABLE IF EXISTS `dokumente`;
CREATE TABLE `dokumente` (
  `dokument_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `filename` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `filesize` int(20) NOT NULL DEFAULT '0',
  `autor_host` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `downloads` int(20) NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `protected` tinyint(4) NOT NULL DEFAULT '0',
  `priority` smallint(5) unsigned NOT NULL DEFAULT '0',
  `author_name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`dokument_id`),
  KEY `range_id` (`range_id`),
  KEY `seminar_id` (`seminar_id`),
  KEY `user_id` (`user_id`),
  KEY `chdate` (`chdate`),
  KEY `mkdate` (`mkdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `dokumente`
--

INSERT INTO `dokumente` (`dokument_id`, `range_id`, `user_id`, `seminar_id`, `name`, `description`, `filename`, `mkdate`, `chdate`, `filesize`, `autor_host`, `downloads`, `url`, `protected`, `priority`, `author_name`) VALUES
('c51a12e44c667b370fe2c497fbfc3c21', '823b5c771f17d4103b1828251c29a7cb', '76ed43ef286fb55cf9e41beadb484a9f', '834499e2b8a2cd71637890e5de31cba3', 'Stud.IP-Produktbroschüre im PDF-Format', '', 'studip_broschuere.pdf', 1156516698, 1156516698, 295294, '217.94.188.5', 3, 'http://www.studip.de/download/studip_broschuere.pdf', 0, 0, 'Root Studip');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `eval`
--

DROP TABLE IF EXISTS `eval`;
CREATE TABLE `eval` (
  `eval_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `author_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `text` text COLLATE latin1_general_ci NOT NULL,
  `startdate` int(20) DEFAULT NULL,
  `stopdate` int(20) DEFAULT NULL,
  `timespan` int(20) DEFAULT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `anonymous` tinyint(1) NOT NULL DEFAULT '1',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`eval_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `eval`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `evalanswer`
--

DROP TABLE IF EXISTS `evalanswer`;
CREATE TABLE `evalanswer` (
  `evalanswer_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `text` text COLLATE latin1_general_ci NOT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `rows` tinyint(4) NOT NULL DEFAULT '0',
  `counter` int(11) NOT NULL DEFAULT '0',
  `residual` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`evalanswer_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `evalanswer`
--

INSERT INTO `evalanswer` (`evalanswer_id`, `parent_id`, `position`, `text`, `value`, `rows`, `counter`, `residual`) VALUES
('d67301d4f59aa35d1e3f12a9791b6885', 'ef227e91618878835d52cfad3e6d816b', 0, 'Sehr gut', 1, 0, 0, 0),
('7052b76e616656e4b70f1c504c04ec81', 'ef227e91618878835d52cfad3e6d816b', 1, '', 2, 0, 0, 0),
('64152ace8f2a74d0efb67c54eff64a2b', 'ef227e91618878835d52cfad3e6d816b', 2, '', 3, 0, 0, 0),
('3a3ab5307f39ea039d41fb6f2683475e', 'ef227e91618878835d52cfad3e6d816b', 3, '', 4, 0, 0, 0),
('6115b19f694ccd3d010a0047ff8f970a', 'ef227e91618878835d52cfad3e6d816b', 4, 'Sehr Schlecht', 5, 0, 0, 0),
('be4c3e5fe0b2b735bb3b2712afa8c490', 'ef227e91618878835d52cfad3e6d816b', 5, 'Keine Meinung', 6, 0, 0, 1),
('84be4c31449a9c1807bf2dea0dc869f1', '724244416b5d04a4d8f4eab8a86fdbf8', 0, 'Sehr gut', 1, 0, 0, 0),
('c446970d2addd68e43c2a6cae6117bf7', '724244416b5d04a4d8f4eab8a86fdbf8', 1, 'Gut', 2, 0, 0, 0),
('3d4dcedb714dfdcfbe65cd794b4d404b', '724244416b5d04a4d8f4eab8a86fdbf8', 2, 'Befriedigend', 3, 0, 0, 0),
('fa2bf667ba73ae74794df35171c2ad2e', '724244416b5d04a4d8f4eab8a86fdbf8', 3, 'Ausreichend', 4, 0, 0, 0),
('0be387b9379a05c5578afce64b0c688f', '724244416b5d04a4d8f4eab8a86fdbf8', 4, 'Mangelhaft', 5, 0, 0, 0),
('aec07dd525f2610bdd10bf778aa1893b', '724244416b5d04a4d8f4eab8a86fdbf8', 5, 'Nicht erteilt', 6, 0, 0, 1),
('7080335582e2787a54f315ec8cef631e', '95bbae27965d3404f7fa3af058850bd3', 0, 'trifft völlig zu', 1, 0, 0, 0),
('d68a74dc2c1f0ce226366da918dd161d', '95bbae27965d3404f7fa3af058850bd3', 1, 'trifft ziemlich zu', 2, 0, 0, 0),
('641686e7c61899b303cda106f20064e7', '95bbae27965d3404f7fa3af058850bd3', 2, 'teilsteils', 3, 0, 0, 0),
('7c36d074f2cc38765c982c9dfb769afc', '95bbae27965d3404f7fa3af058850bd3', 3, 'trifft wenig zu', 4, 0, 0, 0),
('5c4827f903168ed4483db5386a9ad5b8', '95bbae27965d3404f7fa3af058850bd3', 4, 'trifft gar nicht zu', 5, 0, 0, 0),
('c10a3f4e97f8badc5230a9900afde0c7', '95bbae27965d3404f7fa3af058850bd3', 5, 'kann ich nicht beurteilen', 6, 0, 0, 1),
('ced33706ca95aff2163c7d0381ef5717', '6fddac14c1f2ac490b93681b3da5fc66', 0, 'Montag', 1, 0, 0, 0),
('087c734855c8a5b34d99c16ad09cd312', '6fddac14c1f2ac490b93681b3da5fc66', 1, 'Dienstag', 2, 0, 0, 0),
('63f5011614f45329cc396b90d94a7096', '6fddac14c1f2ac490b93681b3da5fc66', 2, 'Mittwoch', 3, 0, 0, 0),
('ccd1eaddccca993f6789659b36f40506', '6fddac14c1f2ac490b93681b3da5fc66', 3, 'Donnerstag', 4, 0, 0, 0),
('48842cedeac739468741940982b5fe6d', '6fddac14c1f2ac490b93681b3da5fc66', 4, 'Freitag', 5, 0, 0, 0),
('21b3f7cf2de5cbb098d800f344d399ee', '12e508079c4770fb13c9fce028f40cac', 0, 'Montag', 1, 0, 0, 0),
('f0016e918b5bc5c4cf3cc62bf06fa2e9', '12e508079c4770fb13c9fce028f40cac', 1, 'Dienstag', 2, 0, 0, 0),
('c88242b50ff0bb43df32c1e15bdaca22', '12e508079c4770fb13c9fce028f40cac', 2, 'Mittwoch', 3, 0, 0, 0),
('b39860f6601899dcf87ba71944c57bc7', '12e508079c4770fb13c9fce028f40cac', 3, 'Donnerstag', 4, 0, 0, 0),
('568d6fd620642cb7395c27d145a76734', '12e508079c4770fb13c9fce028f40cac', 4, 'Freitag', 5, 0, 0, 0),
('39b98a5560d5dabaf67227e2895db8da', 'a68bd711902f23bd5c55a29f1ecaa095', 0, '', 1, 5, 0, 0),
('61ae27ab33c402316a3f1eb74e1c46ab', '442e1e464e12498bd238a7767215a5a2', 0, '', 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `evalanswer_user`
--

DROP TABLE IF EXISTS `evalanswer_user`;
CREATE TABLE `evalanswer_user` (
  `evalanswer_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`evalanswer_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `evalanswer_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `evalgroup`
--

DROP TABLE IF EXISTS `evalgroup`;
CREATE TABLE `evalgroup` (
  `evalgroup_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `text` text COLLATE latin1_general_ci NOT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `child_type` enum('EvaluationGroup','EvaluationQuestion') COLLATE latin1_general_ci NOT NULL DEFAULT 'EvaluationGroup',
  `mandatory` tinyint(1) NOT NULL DEFAULT '0',
  `template_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`evalgroup_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `evalgroup`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `evalquestion`
--

DROP TABLE IF EXISTS `evalquestion`;
CREATE TABLE `evalquestion` (
  `evalquestion_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` enum('likertskala','multiplechoice','polskala') COLLATE latin1_general_ci NOT NULL DEFAULT 'multiplechoice',
  `position` int(11) NOT NULL DEFAULT '0',
  `text` text COLLATE latin1_general_ci NOT NULL,
  `multiplechoice` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`evalquestion_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `evalquestion`
--

INSERT INTO `evalquestion` (`evalquestion_id`, `parent_id`, `type`, `position`, `text`, `multiplechoice`) VALUES
('ef227e91618878835d52cfad3e6d816b', '0', 'polskala', 0, 'Wertung 1-5', 0),
('724244416b5d04a4d8f4eab8a86fdbf8', '0', 'likertskala', 0, 'Schulnoten', 0),
('95bbae27965d3404f7fa3af058850bd3', '0', 'likertskala', 0, 'Wertung (trifft zu, ...)', 0),
('6fddac14c1f2ac490b93681b3da5fc66', '0', 'multiplechoice', 0, 'Werktage', 0),
('12e508079c4770fb13c9fce028f40cac', '0', 'multiplechoice', 0, 'Werktage-mehrfach', 1),
('a68bd711902f23bd5c55a29f1ecaa095', '0', 'multiplechoice', 0, 'Freitext-Mehrzeilig', 0),
('442e1e464e12498bd238a7767215a5a2', '0', 'multiplechoice', 0, 'Freitext-Einzeilig', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `eval_group_template`
--

DROP TABLE IF EXISTS `eval_group_template`;
CREATE TABLE `eval_group_template` (
  `evalgroup_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `group_type` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT 'normal',
  PRIMARY KEY (`evalgroup_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `eval_group_template`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `eval_range`
--

DROP TABLE IF EXISTS `eval_range`;
CREATE TABLE `eval_range` (
  `eval_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`eval_id`,`range_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `eval_range`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `eval_templates`
--

DROP TABLE IF EXISTS `eval_templates`;
CREATE TABLE `eval_templates` (
  `template_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `institution_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `show_questions` tinyint(1) NOT NULL DEFAULT '1',
  `show_total_stats` tinyint(1) NOT NULL DEFAULT '1',
  `show_graphics` tinyint(1) NOT NULL DEFAULT '1',
  `show_questionblock_headline` tinyint(1) NOT NULL DEFAULT '1',
  `show_group_headline` tinyint(1) NOT NULL DEFAULT '1',
  `polscale_gfx_type` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'bars',
  `likertscale_gfx_type` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'bars',
  `mchoice_scale_gfx_type` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'bars',
  `kurzbeschreibung` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`template_id`),
  KEY `user_id` (`user_id`,`institution_id`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `eval_templates`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `eval_templates_eval`
--

DROP TABLE IF EXISTS `eval_templates_eval`;
CREATE TABLE `eval_templates_eval` (
  `eval_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `template_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`eval_id`),
  KEY `eval_id` (`eval_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `eval_templates_eval`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `eval_templates_user`
--

DROP TABLE IF EXISTS `eval_templates_user`;
CREATE TABLE `eval_templates_user` (
  `eval_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `template_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  KEY `eval_id` (`eval_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `eval_templates_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `eval_user`
--

DROP TABLE IF EXISTS `eval_user`;
CREATE TABLE `eval_user` (
  `eval_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`eval_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `eval_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `extern_config`
--

DROP TABLE IF EXISTS `extern_config`;
CREATE TABLE `extern_config` (
  `config_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `config_type` int(4) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `is_standard` int(4) NOT NULL DEFAULT '0',
  `config` mediumtext COLLATE latin1_general_ci NOT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`config_id`,`range_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `extern_config`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ex_termine`
--

DROP TABLE IF EXISTS `ex_termine`;
CREATE TABLE `ex_termine` (
  `termin_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `autor_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `content` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci,
  `date` int(20) NOT NULL DEFAULT '0',
  `end_time` int(20) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `date_typ` tinyint(4) NOT NULL DEFAULT '0',
  `topic_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `raum` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `metadate_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `resource_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`termin_id`),
  KEY `range_id` (`range_id`,`date`),
  KEY `metadate_id` (`metadate_id`,`date`),
  KEY `autor_id` (`autor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `ex_termine`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `folder`
--

DROP TABLE IF EXISTS `folder`;
CREATE TABLE `folder` (
  `folder_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci,
  `permission` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `priority` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`folder_id`),
  KEY `user_id` (`user_id`),
  KEY `range_id` (`range_id`),
  KEY `chdate` (`chdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `folder`
--

INSERT INTO `folder` (`folder_id`, `range_id`, `user_id`, `name`, `description`, `permission`, `mkdate`, `chdate`, `priority`) VALUES
('dad53cd0f0d9f36817c3c9c7c124bda3', 'ec2e364b28357106c0f8c282733dbe56', '', 'Allgemeiner Dateiordner', 'Ablage für allgemeine Ordner und Dokumente der Einrichtung', 7, 1156516698, 1156516698, 0),
('b58081c411c76814bc8f78425fb2ab81', '7a4f19a0a2c321ab2b8f7b798881af7c', '', 'Allgemeiner Dateiordner', 'Ablage für allgemeine Ordner und Dokumente der Einrichtung', 7, 1156516698, 1156516698, 0),
('694cdcef09c2b8e70a7313b028e36fb6', '110ce78ffefaf1e5f167cd7019b728bf', '', 'Allgemeiner Dateiordner', 'Ablage für allgemeine Ordner und Dokumente der Einrichtung', 7, 1156516698, 1156516698, 0),
('823b5c771f17d4103b1828251c29a7cb', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', 'Allgemeiner Dateiordner', 'Ablage für allgemeine Ordner und Dokumente der Veranstaltung', 7, 1156516698, 1156516698, 0),
('c996fa8545b9ed2ca0c6772cca784019', 'ab10d788d28787ea00ca39770a2516d9', '76ed43ef286fb55cf9e41beadb484a9f', 'nur lesbarer Ordner', '', 5, 1176474403, 1176474408, 0),
('963084e86963b5cd2d086eafd5f04eb5', 'ab10d788d28787ea00ca39770a2516d9', '76ed43ef286fb55cf9e41beadb484a9f', 'unsichtbarer Ordner', '', 0, 1176474417, 1176474422, 0),
('17b75cc079bdad8e54d2f7ce3ce29f2e', 'ab10d788d28787ea00ca39770a2516d9', '76ed43ef286fb55cf9e41beadb484a9f', 'Hausaufgabenordner', '', 3, 1176474443, 1176474449, 0),
('aa15759a75c167e38425d17539e7a7be', '41ad59c9b6cdafca50e42fe6bc68af4f', '205f3efb7997a0fc9755da2b535038da', 'Dateiordner der Gruppe: Thema 1', 'Ablage für Ordner und Dokumente dieser Gruppe', 15, 1194628738, 1194628738, 0),
('5b1b53b48c487a639ec493afbb270d4c', '151c33059a90b6138d280862f5d4b3c2', '205f3efb7997a0fc9755da2b535038da', 'Dateiordner der Gruppe: Thema 2', 'Ablage für Ordner und Dokumente dieser Gruppe', 15, 1194628768, 1194628768, 0),
('17534632a6a9145f21c9fc99b7557bf9', 'a5061826bf8db7487a774f92ce2a4d23', '205f3efb7997a0fc9755da2b535038da', 'Dateiordner der Gruppe: Thema 3', 'Ablage für Ordner und Dokumente dieser Gruppe', 15, 1194628789, 1194628789, 0),
('223e72c19d19622ec7c947ba058d492a', '0d2df6a71f3317549a5f2f252863c62b', '76ed43ef286fb55cf9e41beadb484a9f', 'Allgemeiner Dateiordner', 'Ablage für allgemeine Ordner und Dokumente der Veranstaltung', 7, 1347366509, 1347366509, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `guestbook`
--

DROP TABLE IF EXISTS `guestbook`;
CREATE TABLE `guestbook` (
  `post_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `content` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`post_id`),
  KEY `user_id` (`user_id`),
  KEY `range_id` (`range_id`,`mkdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `guestbook`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `his_abschl`
--

DROP TABLE IF EXISTS `his_abschl`;
CREATE TABLE `his_abschl` (
  `abint` char(2) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `aikz` char(1) COLLATE latin1_general_ci DEFAULT NULL,
  `ktxt` char(10) COLLATE latin1_general_ci DEFAULT NULL,
  `dtxt` char(25) COLLATE latin1_general_ci DEFAULT NULL,
  `ltxt` char(100) COLLATE latin1_general_ci DEFAULT NULL,
  `astat` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `hrst` char(10) COLLATE latin1_general_ci DEFAULT NULL,
  `part` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `anzstg` smallint(6) DEFAULT NULL,
  `kzfaarray` char(10) COLLATE latin1_general_ci DEFAULT NULL,
  `mag_laa` char(1) COLLATE latin1_general_ci DEFAULT NULL,
  `sortkz1` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `anzstgmin` smallint(6) DEFAULT NULL,
  `sprache` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `refabint` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `efh` char(4) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`abint`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `his_abschl`
--

INSERT INTO `his_abschl` (`abint`, `aikz`, `ktxt`, `dtxt`, `ltxt`, `astat`, `hrst`, `part`, `anzstg`, `kzfaarray`, `mag_laa`, `sortkz1`, `anzstgmin`, `sprache`, `refabint`, `efh`) VALUES
('02', 'A', 'Magister', 'Magister', 'magister artium', '02', 'G', '', 3, '', 'M', '02', 0, 'D', '02', '0301'),
('04', 'A', 'Kirchl.Abs', 'Kirchlicher Abschluss', 'Kirchliches Examen', '04', 'G', '', 1, '', '', '04', 0, 'D', '04', '0301'),
('06', 'A', 'Promotion', 'Promotion', 'Promotion', '06', 'G', '', 1, '', '', '06', 0, 'D', '06', '0301'),
('21', 'A', 'LA Grundsc', 'Lehramt für Grundschulen', 'Erste Staatsprüfung für das Lehramt an Grundschulen', '21', 'G', '', 4, '', 'L', '21', 0, 'D', '21', '0301'),
('24', 'A', 'LA Sekunda', 'Lehramt für Sekundarschul', 'Erste Staatsprüfung für das Lehramt an Sekundarschulen', '24', 'G', '', 4, '', 'L', '24', 0, 'D', '24', '0301'),
('25', 'A', 'LA Gymnasi', 'Lehramt für Gymnasien', 'Erste Staatsprüfung für das Lehramt an Gymnasien', '25', 'G', '', 4, '', 'L', '25', 0, 'D', '25', '0301'),
('26', 'A', 'LA Sonders', 'Lehramt für Sonderschulen', 'Erste Staatsprüfung für das Lehramt an Sonderschulen', '26', 'G', '', 4, '', 'L', '26', 0, 'D', '26', '0301'),
('40', 'A', 'UE Förders', 'Unterrichtserl. Förderstu', 'Unterrichtserlaubnis für die Förderstufe an Sekundarschulen', '21', 'G', '', 1, '', '', '40', 0, 'D', '40', '0301'),
('94', 'A', 'Zeugnis/Ze', 'Zeugnis/Zertifikat', 'Zeugnis/Zertifikat', '94', 'G', '', 1, '', '', '94', 0, 'D', '94', '0301'),
('95', 'A', 'sonst.Absc', 'sonstiger Abschluss', 'sonstiger Abschluss', '95', 'G', '', 1, '', '', '95', 0, 'D', '95', '0301'),
('96', 'A', 'Abschl.im', 'Abschluss im Ausland', 'ohne Abschluss, (die Abschlussprüfung erfolgt im Ausland)', '96', 'G', '', 1, '', '', '96', 0, 'D', '96', '0301'),
('97', 'A', 'ohne Absch', 'Studium ohne Abschluss', 'Es ist kein spezieller Abschluss vorgesehen', '97', '', '', 2, '', '', '97', 0, 'D', '97', '0301'),
('93', 'A', 'legum magi', 'legum magister', 'legum magister', '88', 'G', '', 1, '', '', '93', 0, 'D', '93', '0301'),
('PP', 'A', 'Pool', 'Prüfungspool', 'Prüfungspool', '', '', '', 0, '', '', '', 0, 'D', '', '0301'),
('11', 'A', 'Diplom', 'Diplom', 'Diplom', '11', 'G', '', 1, '', '', '11', 0, 'D', '11', '0301'),
('82', 'A', 'BA', 'Bachelor', 'Bachelor', '82', 'G', '', 2, '', '', '82', 0, 'D', '82', '0301'),
('88', 'A', 'MA', 'Master', 'Master', '88', 'G', '', 2, '', '', '88', 0, 'D', '88', '0301'),
('83', 'A', 'BA 2-Fach', 'Bachelor (2-Fach)', 'Bachelor (2-Fach)', '82', 'G', '', 2, '', '', '83', 0, 'D', '83', ''),
('89', 'A', 'MA 2-Fach', 'Master (2-Fach)', 'Master (2-Fach)', '88', 'G', '', 2, '', '', '89', 0, 'D', '89', ''),
('08', 'A', 'Staatsprüf', 'Staatsprüfung', 'Staatsprüfung', '08', 'G', '', 1, '', '', '08', 0, 'D', '08', '0301');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `his_abstgv`
--

DROP TABLE IF EXISTS `his_abstgv`;
CREATE TABLE `his_abstgv` (
  `ktxt` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `dtxt` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `ltxt` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `fb` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `kzfa` char(1) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `kzfaarray` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `abschl` char(2) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `stg` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pversion` int(11) NOT NULL DEFAULT '0',
  `regelstz` tinyint(2) DEFAULT NULL,
  `login_part` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  `studip_studiengang` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`abschl`,`stg`,`kzfa`,`pversion`),
  KEY `studip_studiengang` (`studip_studiengang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `his_abstgv`
--

INSERT INTO `his_abstgv` (`ktxt`, `dtxt`, `ltxt`, `fb`, `kzfa`, `kzfaarray`, `abschl`, `stg`, `pversion`, `regelstz`, `login_part`, `studip_studiengang`) VALUES
('Sport (HRS', 'Sport (Hpt.+Realsch.)', 'Sport', 'DC', 'H', 'H', '26', '098', 9999, 9, 'Ph', ''),
('Sport', 'Sport', 'Sport', 'DC', 'H', 'H', '24', '098', 9999, 8, 'Ph', ''),
('Sport', 'Sport', 'Sport', 'DC', 'H', 'H', '25', '098', 9999, 9, 'Ph', ''),
('Lernbeh.pä', 'Lernbehindertenpädagogik', 'Lernbehindertenpädagogik', 'EB', 'H', 'H', '26', '099', 9999, 9, 'Pä', ''),
('Maschinenb', 'Maschinenbau/ -wesen', 'Maschinenbau / -wesen', '78', 'H', 'H', '11', '104', 9999, 10, '', ''),
('Mathematik', 'Mathematik', 'Mathematik', 'HD', 'H', 'H', '11', '105', 1997, 9, 'Ma', ''),
('Mathematik', 'Mathematik', 'Mathematik', 'HD', 'H', 'H', '24', '105', 9999, 8, 'Ma', ''),
('Mathematik', 'Mathematik', 'Mathematik', 'HD', 'H', 'H', '25', '105', 9999, 9, 'Ma', ''),
('Mathematik', 'Mathematik (Förderstufe)', 'Mathematik', 'HD', 'H', 'H', '40', '105', 9999, 2, 'Ma', ''),
('Mathematik', 'Mathematik (Hpt.+Realsch)', 'Mathematik', 'HD', 'H', 'H', '26', '105', 9999, 9, 'Ma', ''),
('Medizin', 'Medizin', 'Medizin', 'IA', 'H', 'H', '08', '107', 9999, 13, 'Me', ''),
('Mineralogi', 'Mineralogie', 'Mineralogie', 'HB', 'H', 'H', '11', '111', 9999, 9, 'Ge', ''),
('Musik', 'Musik', 'Musik', 'DD', 'H', 'H', '25', '113', 9999, 10, 'Ph', ''),
('Musik', 'Musik', 'Musik', 'DD', 'H', 'H', '24', '113', 9999, 9, 'Ph', ''),
('Musik (HRS', 'Musik (Hpt.+Realsch.)', 'Musik', 'DD', 'H', 'H', '26', '113', 9999, 9, 'Ph', ''),
('Musikwiss.', 'Musikwissenschaft', 'Musikwissenschaft', 'DD', 'H', 'HHN', '02', '114', 9999, 9, 'Ph', ''),
('Grundsch.l', 'Grundschullehrer', 'Grundschullehrer', 'EC', 'H', 'H', '21', '115', 9999, 7, 'Pä', ''),
('Technomath', 'Technomathematik', 'Technomathematik', 'HD', 'H', 'H', '11', '118', 9999, 9, 'Ma', ''),
('Ingwiss.In', 'Ing.wiss./Vert.Ing.Inform', 'Ingenieurwiss.,Vertiefung Ingenieurinformatik', 'HE', 'H', 'H', '11', '123', 9999, 9, '', ''),
('Pharmazie', 'Pharmazie', 'Pharmazie', 'FC', 'H', 'H', '08', '126', 9999, 8, 'Ph', ''),
('Pharmazie', 'Pharmazie', 'Pharmazie', 'FC', 'H', 'H', '11', '126', 9999, 2, 'Ph', ''),
('Philosophi', 'Philosophie', 'Philosophie', 'CG', 'H', 'H', '25', '127', 9999, 9, 'Ph', ''),
('Philosophi', 'Philosophie', 'Philosophie', 'CG', 'H', 'HHN', '02', '127', 9999, 9, 'Ph', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '24', '128', 9999, 8, 'Ch', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '25', '128', 9999, 9, 'Ch', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '26', '128', 9999, 9, 'Ch', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '11', '128', 2005, 10, 'Ch', ''),
('Polnisch (', 'Fachübersetzen Polnisch', 'Fachübersetzen (Polnisch)', 'DC', 'N', 'N', '02', '130', 9999, 9, 'Ph', ''),
('Psychologi', 'Psychologie', 'Psychologie', 'CF', 'H', 'H', '11', '132', 1995, 9, 'Ph', ''),
('Psychologi', 'Psychologie', 'Psychologie', 'CF', 'N', 'N', '02', '132', 9999, 9, 'Ph', ''),
('Psychologi', 'Psychologie', 'Psychologie', 'CF', 'H', 'H', '25', '132', 9999, 9, 'Ph', ''),
('Medien-u.K', 'Medien-u.Kommunikationsw.', 'Medien- und Kommunikationswissenschaft', 'DC', 'H', 'HHN', '02', '133', 9999, 9, 'Ph', ''),
('Rechtswiss', 'Rechtswissenschaft', 'Rechtswissenschaft', 'BA', 'H', 'H', '08', '135', 2003, 9, 'Ju', ''),
('Rechtswiss', 'Rechtswissenschaft (LLM)', 'Rechtswissenschaft (legum magister)', 'BA', 'H', 'H', '93', '135', 9999, 2, 'Ju', ''),
('Russisch', 'Russisch', 'Russisch', 'DF', 'H', 'H', '26', '139', 9999, 9, 'Ph', ''),
('Russisch', 'Russisch', 'Russisch', 'DF', 'H', 'H', '24', '139', 9999, 8, 'Ph', ''),
('Russisch', 'Russisch', 'Russisch', 'DF', 'H', 'H', '25', '139', 9999, 9, 'Ph', ''),
('Slavistik', 'Slavistik', 'Slavistik', 'DF', 'H', 'HHN', '02', '146', 9999, 9, 'Ph', ''),
('Sozialkund', 'Sozialkunde', 'Sozialkunde', 'CE', 'H', 'H', '24', '147', 9999, 8, 'Ph', ''),
('Sozialkund', 'Sozialkunde', 'Sozialkunde', 'CE', 'H', 'H', '25', '147', 9999, 9, 'Ph', ''),
('Sozialkund', 'Sozialkunde', 'Sozialkunde', 'CE', 'H', 'H', '26', '147', 9999, 9, 'Ph', ''),
('Soziologie', 'Soziologie', 'Soziologie', 'CH', 'H', 'H', '11', '149', 1998, 9, 'Ph', ''),
('Soziologie', 'Soziologie', 'Soziologie', 'CH', 'H', 'HHN', '02', '149', 9999, 9, 'Ph', ''),
('Spanisch', 'Spanisch', 'Spanisch', 'DE', 'H', 'H', '25', '150', 9999, 9, 'Ph', ''),
('Sprachbeh.', 'Sprachbehindertenpädagog.', 'Sprachbehindertenpädagogik', 'EB', 'H', 'H', '26', '151', 9999, 9, 'Pä', ''),
('Sprachwiss', 'Sprachwissenschaft', 'Sprachwissenschaft', 'CD', 'H', 'HHN', '02', '152', 9999, 9, 'Ph', ''),
('Mazedonist', 'Mazedonistik', 'Mazedonistik', '64', 'H', 'H', '02', '153', 9999, 9, 'Ph', ''),
('Ethik', 'Ethik', 'Ethik', 'CG', 'H', 'H', '25', '169', 9999, 9, 'Ph', ''),
('Ethik (HRS', 'Ethik (Hpt.+Realsch)', 'Ethik', 'CG', 'H', 'H', '26', '169', 9999, 9, 'Ph', ''),
('Ethik', 'Ethik', 'Ethik', 'CG', 'H', 'H', '24', '169', 9999, 8, 'Ph', ''),
('Ethik (GS)', 'Ethik (Grundsch)', 'Ethik (Grundschule)', 'CG', 'H', 'H', '21', '169', 9999, 8, 'Ph', ''),
('Verh.gest.', 'Verhaltensgest.pädagogik', 'Verhaltensgestörtenpädagogik', 'EB', 'H', 'H', '26', '170', 9999, 9, 'Pä', ''),
('Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB', 'N', 'N', '02', '175', 2003, 9, 'Wi', ''),
('MuK90', 'Medien-u.Kommunikation90', 'Medien- und Kommunikationswissenschaft', 'DC', 'K', '', '83', '933', 106, 6, 'Ph', ''),
('Werkstoffw', 'Werkstoffwissenschaft', 'Werkstoffwissenschaft', 'HE', 'H', 'H', '11', '177', 9999, 10, '', ''),
('MuK120', 'Medien-u.Kommunikation120', 'Medien- und Kommunikationswissenschaft', 'DC', 'S', '', '83', '233', 106, 6, 'Ph', ''),
('Zahnmedizi', 'Zahnmedizin', 'Zahnmedizin', 'IA', 'H', 'H', '08', '185', 9999, 11, 'Me', ''),
('Rehab.päda', 'Rehabilitationspädagogik', 'Rehabilitationspädagogik', 'EB', 'H', 'HHN', '02', '190', 9999, 9, 'Pä', ''),
('Rehab.päda', 'Rehabilitationspädagogik', 'Rehabilitationspädagogik', 'EB', 'H', 'H', '11', '190', 9999, 0, 'Pä', ''),
('Rehab.päda', 'Rehabilitationspädagogik', 'Rehabilitationspädagogik', 'EB', 'H', 'H', '26', '190', 9999, 9, 'Pä', ''),
('Studienkol', 'Studienkolleg', 'Studienkolleg', 'QA', 'H', 'H', '95', '196', 9999, 2, '', ''),
('Verarb.tec', 'Verarbeitungstechnik', 'Verarbeitungstechnik', '78', 'H', 'H', '11', '202', 9999, 10, '', ''),
('Verfahrens', 'Verfahrenstechnik', 'Verfahrenstechnik', 'HE', 'H', 'H', '11', '226', 9999, 10, '', ''),
('Wirtsch.Ma', 'Wirtschaftsmathematik', 'Wirtschaftsmathematik', 'HD', 'H', 'H', '11', '276', 1995, 9, 'Ma', ''),
('Musikw.60', 'Musikwissenschaft60', 'Musikwissenschaft', 'DD', 'N', '', '83', '514', 106, 6, 'Ph', ''),
('Bioingenie', 'Bio-Ingenieurwesen', 'Bio-Ingenieurwesen', 'HE', 'H', 'H', '11', '282', 9999, 9, '', ''),
('Politikwis', 'Politikwissenschaft', 'Politikwissenschaft', 'CE', 'H', 'HHN', '02', '300', 9999, 9, 'Ph', ''),
('Politikwis', 'Politikwissenschaft', 'Politikwissenschaft', 'CE', 'H', 'H', '11', '300', 9999, 9, 'Ph', ''),
('Geologie/P', 'Geologie/Paläontologie', 'Geologie/Paläontologie', 'HB', 'N', 'N', '02', '302', 9999, 9, 'Ge', ''),
('Int.Fi.Man', 'Inter.Finanzmanagement', 'Internationales Finanzmanagement', 'BB', 'H', 'H', '88', '728', 9999, 4, 'Wi', ''),
('Ernährungs', 'Ernährungswissenschaft', 'Ernährungswissenschaft', 'HA', 'H', 'H', '11', '320', 9999, 9, 'Ag', ''),
('Umwelttech', 'Umwelttechnik', 'Umwelttechnik', 'HE', 'H', 'H', '11', '457', 9999, 10, '', ''),
('Präh.Archä', 'Prähistor.Archäologie', 'Prähistorische Archäologie', 'CC', 'H', 'HHN', '02', '548', 9999, 9, 'Ph', ''),
('Präh.Archä', 'Prähistor.Archäologie', 'Prähistorische Archäologie', 'CC', 'H', 'H', '11', '548', 9999, 9, 'Ph', ''),
('Germ.Sprac', 'Germanist.Sprachwissensch', 'Germanistische Sprachwissenschaft', 'DB', 'H', 'HHN', '02', '603', 9999, 9, 'Ph', ''),
('Germ.Liter', 'Germanist.Literaturwiss.', 'Germanistische Literaturwissenschaft', 'DB', 'H', 'HHN', '02', '604', 9999, 9, 'Ph', ''),
('Sprechwiss', 'Sprechwissenschaft', 'Sprechwissenschaft', 'DF', 'H', 'H', '11', '605', 9999, 9, 'Ph', ''),
('Sprechwiss', 'Sprechwissenschaft', 'Sprechwissenschaft', 'DF', 'H', 'HHN', '02', '605', 9999, 9, 'Ph', ''),
('Wirtsch/Te', 'Wirtschaft/Technik', 'Wirtschaft und Technik', 'HE', 'H', 'H', '24', '606', 9999, 8, '', ''),
('Wirtsch/Te', 'Wirtschaft/Technik', 'Wirtschaft und Technik', 'HE', 'H', 'H', '25', '606', 9999, 9, '', ''),
('Wirtsch/Te', 'Wirtschaft/Technik', 'Wirtschaft und Technik', 'HE', 'H', 'H', '26', '606', 9999, 9, '', ''),
('Semitistik', 'Semitistik', 'Semitistik', 'CD', 'H', 'HHN', '02', '609', 9999, 9, 'Ph', ''),
('Italianist', 'Italianistik', 'Italianistik', 'DE', 'H', 'HHN', '02', '610', 9999, 9, 'Ph', ''),
('Anglistik', 'Anglistik', 'Anglistik', 'DA', 'H', 'H', '11', '612', 9999, 9, 'Ph', ''),
('Angl./Amer', 'Anglistik/Amerikanistik', 'Anglistik/Amerikanistik', 'DA', 'H', 'HHN', '02', '613', 9999, 9, 'Ph', ''),
('Galloroman', 'Galloromanistik', 'Galloromanistik', 'DE', 'H', 'HHN', '02', '614', 9999, 9, 'Ph', ''),
('Hispanisti', 'Hispanistik', 'Hispanistik', 'DE', 'H', 'HHN', '02', '615', 9999, 9, 'Ph', ''),
('Polonistik', 'Polonistik', 'Polonistik', '64', 'H', 'H', '02', '618', 9999, 9, 'Ph', ''),
('Klass.Arch', 'Klassische Archäologie', 'Klassische Archäologie', 'CA', 'H', 'HHN', '02', '619', 9999, 9, 'Ph', ''),
('Mittellat.', 'Mittellatein.Philologie', 'Mittellateinische Philologie', 'CA', 'H', 'HHN', '02', '620', 9999, 9, 'Ph', ''),
('Or.Arch.u.', 'Oriental.Archäol.u.Kunst', 'Orientalische Archäologie und Kunst', 'CA', 'H', 'HHN', '02', '621', 9999, 9, 'Ph', ''),
('Sp/Lit Chr', 'Spr./Lit.d.Christl.Orient', 'Sprachen und Literaturen des Christlichen Orients', 'CD', 'H', 'HHN', '02', '623', 9999, 9, 'Ph', ''),
('Kunstgesch', 'Kunstgeschichte Byz.', 'Kunstgeschichte Byzantinistik', '63', 'H', 'HHN', '02', '624', 9999, 9, 'Ph', ''),
('Osteurop.G', 'Osteuropäische Geschichte', 'Osteuropäische Geschichte', 'CB', 'N', 'N', '02', '629', 9999, 9, 'Ph', ''),
('Mitt.u.Neu', 'Mittl.u.Neue Geschichte', 'Geschichte, Mittlere und Neuere', '62', 'N', 'N', '02', '630', 9999, 9, 'Ph', ''),
('Neueste Ge', 'Neueste Geschichte', 'Neueste Geschichte', '62', 'H', 'H', '02', '631', 9999, 9, 'Ph', ''),
('Sozialgesc', 'Sozialgeschichte', 'Sozialgeschichte', '62', 'H', 'H', '02', '632', 9999, 9, 'Ph', ''),
('Landesgesc', 'Landesgeschichte', 'Landesgeschichte', 'CB', 'N', 'N', '02', '633', 9999, 9, 'Ph', ''),
('Hist.Hilfs', 'Hist. Hilfswissensch.', 'Historische Hilfswissenschaften', 'CB', 'N', 'N', '02', '634', 9999, 9, 'Ph', ''),
('Mediz.Päda', 'Medizinpädagogik', 'Medizinpädagogik', 'IA', 'H', 'H', '11', '636', 9999, 10, 'Me', ''),
('Phonetik', 'Phonetik', 'Phonetik', '65', 'H', 'H', '02', '638', 9999, 9, 'Ph', ''),
('Therapiesp', 'Therapiesport', 'Therapiesport', '65', 'H', 'H', '11', '641', 9999, 0, 'Ph', ''),
('Russistik', 'Russistik', 'Russistik', 'DF', 'H', 'H', '02', '642', 9999, 9, 'Ph', ''),
('Ev.Religio', 'Evangelische Religion', 'Evangelische Religionslehre', 'A', 'H', 'H', '26', '643', 9999, 9, 'Th', ''),
('Ev.Religio', 'Evangelische Religion', 'Evangelische Religionslehre', 'A', 'H', 'H', '24', '643', 9999, 8, 'Th', ''),
('Ev.Religio', 'Evangelische Religion', 'Evangelische Religionslehre', 'A', 'H', 'H', '25', '643', 9999, 9, 'Th', ''),
('Wirt.ing.w', 'Wirtschaftsingenieurwesen', 'Wirtschaftsingenieurwesen', 'BB', 'H', 'H', '11', '179', 2003, 10, 'Wi', ''),
('Latein.Phi', 'Lateinische Philologie', 'Lateinische Philologie', 'CA', 'H', 'HHN', '02', '644', 9999, 9, 'Ph', ''),
('Griech.Phi', 'Griechische Philologie', 'Griechische Philologie', 'CA', 'H', 'HHN', '02', '645', 9999, 9, 'Ph', ''),
('Russisch (', 'Fachübersetzen Russisch', 'Fachübersetzen (Russisch)', '64', 'N', 'N', '02', '646', 9999, 9, 'Ph', ''),
('Englisch (', 'Fachübersetzen Englisch', 'Fachübersetzen (Englisch)', 'DC', 'N', 'N', '02', '647', 9999, 9, 'Ph', ''),
('Französisc', 'Fachübersetzen Französ.', 'Fachübersetzen (Französisch)', '64', 'N', 'N', '02', '648', 9999, 9, 'Ph', ''),
('Deutsch/Fr', 'Deutsch als Fremdsprache', 'Deutsch als Fremdsprache', '64', 'N', 'N', '02', '649', 9999, 9, 'Ph', ''),
('Alte Gesch', 'Alte Geschichte', 'Alte Geschichte', 'CB', 'H', 'HHN', '02', '651', 9999, 9, 'Ph', ''),
('Angl/Amer.', 'Anglistik/Amerikan.(Lit.)', 'Angl./Amerik. - Englische u. Amerikan. Literatur', '64', 'H', 'H', '02', '652', 9999, 9, 'Ph', ''),
('Angl/Amer.', 'Anglistik/Amerikan.(Spr.)', 'Angl./Amerikanistik-Englische Sprachwissenschaft', '64', 'H', 'H', '02', '653', 9999, 9, 'Ph', ''),
('Hauswirtsc', 'Hauswirtschaft', 'Hauswirtschaft', 'EA', 'H', 'H', '24', '654', 9999, 8, 'Pä', ''),
('Hauswirtsc', 'Hauswirtschaft', 'Hauswirtschaft', 'EA', 'H', 'H', '26', '654', 9999, 8, 'Pä', ''),
('Musik-Th.u', 'Theorie u.Prax.der Musik', 'Theorie und Praxis der Musik', '65', 'N', 'N', '02', '655', 9999, 9, 'Ph', ''),
('Polnisch', 'Polnisch', 'Polnisch', '64', 'H', 'H', '25', '656', 9999, 10, 'Ph', ''),
('Sozialkund', 'Sozialkunde/DIF', 'Sozialkunde', '62', 'H', 'H', '25', '657', 9999, 6, 'Ph', ''),
('Schulgarte', 'Schulgarten', 'Schulgarten', 'EC', 'H', 'H', '21', '660', 9999, 7, 'Pä', ''),
('Schulgarte', 'Schulgarten', 'Schulgarten', 'EC', 'H', 'H', '26', '660', 9999, 9, 'Pä', ''),
('Werken', 'Werken', 'Werkunterricht', 'EC', 'H', 'H', '21', '661', 9999, 7, 'Pä', ''),
('Werken', 'Werken', 'Werkunterricht', 'EC', 'H', 'H', '26', '661', 9999, 9, 'Pä', ''),
('Heimat-/Sa', 'Heimatkunde/Sachkunde', 'Heimatkunde/Sachkunde', 'EC', 'H', 'H', '21', '662', 9999, 7, 'Pä', ''),
('Heimat-/Sa', 'Heimatkunde/Sachkunde', 'Heimatkunde/Sachkunde', 'EC', 'H', 'H', '26', '662', 9999, 9, 'Pä', ''),
('Kunsterz.(', 'Kunsterziehung (Grundsch)', 'Kunsterziehung (Grundschule)', 'EC', 'H', 'H', '21', '663', 9999, 7, 'Pä', ''),
('Kunsterz.(', 'Kunsterziehung (Grundsch)', 'Kunsterziehung (Grundsch)', 'EC', 'H', 'H', '26', '663', 9999, 8, 'Pä', ''),
('Sport(Grun', 'Sport (Grundsch)', 'Sport (Grundschule)', 'EC', 'H', 'H', '21', '664', 9999, 7, 'Pä', ''),
('Sport(Grun', 'Sport (Grundsch)', 'Sport (Grundschule)', 'EC', 'H', 'H', '26', '664', 9999, 8, 'Pä', ''),
('Musik(Grun', 'Musik (Grundsch)', 'Musik (Grundsch)', 'EC', 'H', 'H', '26', '665', 9999, 9, 'Pä', ''),
('Musik(Grun', 'Musik (Grundsch)', 'Musik (Grundsch)', 'EC', 'H', 'H', '21', '665', 9999, 7, 'Pä', ''),
('Ethik(Grun', 'Ethik (Grundsch)', 'Ethik (Grundsch)', 'EC', 'H', 'H', '21', '666', 9999, 7, 'Pä', ''),
('Ethik(Grun', 'Ethik (Grundsch)', 'Ethik (Grundsch)', 'EC', 'H', 'H', '26', '666', 9999, 8, 'Pä', ''),
('Ev.Relig.(', 'Evangel.Relig.(Grundsch.)', 'Evangelische Religionslehre (Grundschule)', 'EC', 'H', 'H', '21', '667', 9999, 7, 'Pä', ''),
('Ev.Relig.(', 'Evangel.Relig.(Grundsch)', 'Evangel.Relig.(Grundschule)', 'EC', 'H', 'H', '26', '667', 9999, 9, 'Pä', ''),
('Deutsch (G', 'Deutsch (Grundschule)', 'Deutsch (Grundschule)', 'EC', 'H', 'H', '21', '668', 9999, 7, 'Pä', ''),
('Deutsch (G', 'Deutsch (Grundschule)', 'Deutsch (Grundschule)', 'EC', 'H', 'H', '26', '668', 9999, 9, 'Pä', ''),
('Mathematik', 'Mathematik (Grundschule)', 'Mathematik (Grundschule)', 'EC', 'H', 'H', '21', '669', 9999, 7, 'Pä', ''),
('Mathematik', 'Mathematik (Grundschule)', 'Mathematik (Grundschule)', 'EC', 'H', 'H', '26', '669', 9999, 9, 'Pä', ''),
('Betriebsw.', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', '30', 'H', 'H', '11', '670', 9999, 9, 'Wi', ''),
('Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', '30', 'H', 'H', '11', '671', 9999, 9, 'Wi', ''),
('Wirtsch.In', 'Wirtschaftsinformatik', 'Wirtschaftsinformatik', '30', 'H', 'H', '11', '672', 9999, 9, 'Wi', ''),
('Deutsch (F', 'Deutsch (Förderstufe)', 'Deutsch', '64', 'H', 'H', '21', '673', 9999, 2, 'Ph', ''),
('Mathematik', 'Mathematik (Förderstufe)', 'Mathematik', '75', 'H', 'H', '21', '674', 9999, 2, 'Ma', ''),
('Pflegewiss', 'Pflegewissenschaft', 'Pflegewissenschaft/-management', 'IA', 'H', 'H', '11', '676', 9999, 9, 'Me', ''),
('Materialwi', 'Materialwissenschaft', 'Materialwissenschaft', '78', 'H', 'H', '11', '677', 9999, 10, '', ''),
('Legum magi', 'Legum magister', 'legum magister', '20', 'H', 'H', '02', '678', 9999, 2, 'Ju', ''),
('Wirtsch.re', 'Wirtschaftsrecht', 'Wirtschaftsrecht', '20', 'H', 'H', '11', '680', 9999, 4, 'Ju', ''),
('Didakt.d.G', 'Didaktik der Geschichte', 'Didaktik der Geschichte', 'CB', 'N', 'N', '02', '681', 9999, 9, 'Ph', ''),
('Wrt.u.Soz.', 'Wirtsch.u.Sozialgesch.', 'Wirtschafts- und Sozialgeschichte', 'CB', 'N', 'N', '02', '682', 9999, 9, 'Ph', ''),
('Zeitgeschi', 'Zeitgeschichte', 'Zeitgeschichte', 'CB', 'N', 'N', '02', '683', 9999, 9, 'Ph', ''),
('Medizin.Ph', 'Medizinische Physik', 'Medizinische Physik', 'GB', 'H', 'H', '11', '684', 2004, 10, 'Ch', ''),
('Bio-Inform', 'Bioinformatik', 'Bioinformatik', 'HC', 'H', 'H', '11', '685', 9999, 9, 'Ma', ''),
('Biomed.Mat', 'Biomedizin.Materialien', 'Biomedizinische Materialien', 'FC', 'H', 'H', '11', '686', 9999, 9, '', ''),
('Pfl./Gesun', 'Pflege-u.Gesundheitswiss.', 'Pflege- und Gesundheitswissenschaft', 'IA', 'H', 'H', '11', '687', 9999, 9, 'Me', ''),
('Werkstf.te', 'Werkstofftechnologie', 'Werkstofftechnologie', '78', 'H', 'H', '11', '688', 9999, 9, '', ''),
('Alt-German', 'Altgermanistik', 'Altgermanistik', 'DB', 'N', 'N', '02', '689', 9999, 9, 'Ph', ''),
('Sp/Kult.n.', 'Spr./Kult.d.neuz.Südasien', 'Sprachen und Kulturen des neuzeitlichen Südasien', 'CD', 'H', 'HHN', '02', '690', 9999, 9, 'Ph', ''),
('Sport(Br+W', 'Sportw.(Breiten u.Wettk.)', 'Sportwissensch. Schw: Breiten- und Wettkampfsport', '65', 'H', 'H', '11', '691', 9999, 4, 'Ph', ''),
('Sport(Ther', 'Sportw.(Präv/Reha/Therap)', 'Sportwiss. (Prävention,Rehabilitation,Therapie)', 'DC', 'H', 'H', '11', '692', 9999, 4, 'Ph', ''),
('Seniorenko', 'Seniorenkolleg', 'Seniorenkolleg', 'QB', 'H', 'H', '97', '777', 9999, 0, '', ''),
('Int.Wissen', 'Interkult.Wissenskommunik', 'Interkulturelle Wissenskommunikation', 'DC', 'H', 'HHN', '02', '693', 9999, 9, 'Ph', ''),
('Biomed.Eng', 'Biomedical Engineering', 'Biomedical Engineering', 'IA', 'H', 'H', '88', '694', 2001, 3, 'Me', ''),
('Appl.Polym', 'Applied Polymer Science', 'Master of Applied Polymer Science', 'GA', 'H', 'H', '88', '695', 2001, 4, '', ''),
('VWL', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB', 'H', 'H', '82', '175', 9999, 6, 'Wi', ''),
('BWL', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', 'BB', 'H', 'H', '82', '021', 9999, 6, 'Wi', ''),
('Bio-Inform', 'M.sc. Bioinformatik', 'M.sc. Bioinformatik', 'HC', 'H', 'H', '88', '685', 2001, 4, 'Ma', ''),
('Europa/Ame', 'Interk.Europa/Amerikastud', 'Interkulturelle Europa- und Amerikastudien', 'DA', 'H', 'H', '88', '696', 2001, 4, 'Ph', ''),
('Europa/Ame', 'Interk.Europa/Amerikastud', 'Interkulturelle Europa- und Amerikastudien', 'DA', 'H', 'H', '82', '696', 9999, 6, 'Ph', ''),
('Musikpädag', 'Musikpädagogik', 'Musikpädagogik', 'DD', 'N', 'N', '02', '697', 9999, 9, 'Ph', ''),
('ChrArch/By', 'Chr.Arch./Byz.Kunstgesch.', 'Christl. Archäologie u. Byzantin. Kunstgeschichte', 'CC', 'H', 'HHN', '02', '698', 9999, 9, 'Ph', ''),
('Denkmalpfl', 'Heritage management', 'Master of Science in Heritage management', 'CC', 'H', 'H', '88', '101', 2002, 4, 'Ph', ''),
('Wirtsch.In', 'Wirtschaftsinformatik', 'Wirtschaftsinformatik', 'BB', 'N', 'N', '02', '277', 2003, 9, 'Wi', ''),
('Ethnologie', 'Ethnologie', 'Ethnologie', 'CG', 'H', 'HHN', '02', '173', 9999, 9, 'Ph', ''),
('Geologie/P', 'Geologie/Paläontologie', 'Geologie/Paläontologie', 'HB', 'H', 'H', '82', '302', 9999, 6, 'Ge', ''),
('Integratio', 'Integrationspädagogik', 'Integrationspädagogik', '61', 'H', 'H', '11', '699', 9999, 4, 'Pä', ''),
('Verh.gest.', 'Prävent.v.Verh.störungen', 'Prävention v.Gefühls- und Verhaltensstörungen/GS', 'EB', 'H', 'H', '94', '170', 9999, 2, 'Pä', ''),
('Schulpädag', 'Schulleit./', 'Schule leiten und gestalten', '61', 'H', 'H', '94', '361', 9999, 2, 'Pä', ''),
('Amerikanis', 'Amerikanistik', 'Amerikanistik', 'DA', 'H', 'H', '11', '617', 9999, 9, 'Ph', ''),
('Wirtsch.re', 'Wirtschaftsrecht', 'Wirtschaftsrecht', 'BA', 'H', 'H', '11', '042', 9999, 4, 'Ju', ''),
('Kathol.Rel', 'Kathol. Theol, -Religio', 'Katholische Thoelogie, -Religionslehre', 'ED', 'H', 'H', '24', '086', 9999, 8, 'Ph', ''),
('Kathol.Rel', 'Kathol. Theol, -Relig', 'Katholische Theologie, -Religionslehre', 'ED', 'H', 'H', '25', '086', 9999, 9, 'Ph', ''),
('Autor./Mul', 'Autorschaft & Multimedia', 'Autorschaft und Multimedia', '64', 'H', 'H', '88', '700', 9999, 4, 'Ph', ''),
('Betriebsw.', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', 'BB', 'N', 'N', '02', '021', 2003, 9, 'Wi', ''),
('Chem.u.Umw', 'Chemie-u.Umweltingenieurw', 'Chemie- und Umweltingenieurwesen', 'HE', 'H', 'H', '11', '701', 9999, 9, '', ''),
('Agrarwisse', 'Agrarwissenschaft', 'Agrarwissenschaft', 'HA', 'H', 'H', '06', '003', 9999, 0, 'Ag', ''),
('Arabistik', 'Arabistik', 'Arabistik', 'CD', 'H', 'H', '06', '010', 9999, 0, 'Ph', ''),
('Musikw.120', 'Musikwissenschaft120', 'Musikwissenschaft', 'DD', 'S', '', '83', '214', 106, 6, 'Ph', ''),
('Biochemie', 'Biochemie', 'Biochemie', 'FA', 'H', 'H', '06', '025', 9999, 0, 'BC', ''),
('Biologie', 'Biologie', 'Biologie', 'FB', 'H', 'H', '06', '026', 9999, 0, 'Bi', ''),
('Sportwisse', 'Sportwissenschaft', 'Sportwissenschaft', 'DC', 'H', 'H', '06', '029', 9999, 0, 'Ph', ''),
('Chemie', 'Chemie', 'Chemie', 'GA', 'H', 'H', '06', '032', 9999, 0, 'Ch', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '06', '050', 9999, 0, 'Ge', ''),
('Erziehungs', 'Erziehungswissenschaft', 'Erziehungswissenschaft(Pädagogik)', 'EA', 'H', 'H', '06', '052', 9999, 0, 'Pä', ''),
('Ev.Theolog', 'Theologie', 'Evangelische Theologie', 'A', 'H', 'H', '06', '053', 9999, 0, 'Th', ''),
('Geschichte', 'Geschichte', 'Geschichte', 'CB', 'H', 'H', '06', '068', 9999, 0, 'Ph', ''),
('Griechisch', 'Griechisch', 'Griechisch', 'CA', 'H', 'H', '06', '070', 9999, 0, 'Ph', ''),
('Indologie', 'Indologie', 'Indologie', 'CA', 'H', 'H', '06', '078', 9999, 0, 'Ph', ''),
('Informatik', 'Informatik', 'Informatik', 'HC', 'H', 'H', '06', '079', 9999, 0, 'Ma', ''),
('Islamwisse', 'Islamwissenschaft', 'Islamwissenschaft', 'CD', 'H', 'H', '06', '083', 9999, 0, 'Ph', ''),
('Japanologi', 'Japanologie', 'Japanologie', 'CE', 'H', 'H', '06', '085', 9999, 0, 'Ph', ''),
('Kunstgesch', 'Kunstgeschichte', 'Kunstgeschichte', 'CC', 'H', 'H', '06', '092', 9999, 0, 'Ph', ''),
('Latein', 'Latein', 'Latein', 'CA', 'H', 'H', '06', '095', 9999, 0, 'Ph', ''),
('Mathematik', 'Mathematik', 'Mathematik', 'HD', 'H', 'H', '06', '105', 9999, 0, 'Ma', ''),
('Medizin', 'Medizin', 'Medizin', 'IA', 'H', 'H', '06', '107', 9999, 0, 'Me', ''),
('Mineralogi', 'Mineralogie', 'Mineralogie', 'HB', 'H', 'H', '06', '111', 9999, 0, 'Ge', ''),
('Musikwiss.', 'Musikwissenschaft', 'Musikwissenschaft', 'DD', 'H', 'H', '06', '114', 9999, 0, 'Ph', ''),
('Orientalis', 'Orientalistik', 'Orientalistik', 'CD', 'H', 'H', '06', '122', 9999, 0, 'Ph', ''),
('Pharmazie', 'Pharmazie', 'Pharmazie', 'FC', 'H', 'H', '06', '126', 9999, 0, 'Ph', ''),
('Philosophi', 'Philosophie', 'Philosophie', 'CG', 'H', 'H', '06', '127', 9999, 0, 'Ph', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '06', '128', 9999, 0, 'Ch', ''),
('Psychologi', 'Psychologie', 'Psychologie', 'CF', 'H', 'H', '06', '132', 9999, 0, 'Ph', ''),
('Medien-u.K', 'Medien-u.Kommunikationsw.', 'Medien- und Kommunikationswissenschaft', 'DC', 'H', 'H', '06', '133', 9999, 0, 'Ph', ''),
('Rechtswiss', 'Rechtswissenschaft', 'Rechtswissenschaft', 'BA', 'H', 'H', '06', '135', 9999, 0, 'Ju', ''),
('Romanistik', 'Romanistik', 'Romanistik', '64', 'H', 'H', '06', '137', 9999, 0, 'Ph', ''),
('Slavistik', 'Slavistik', 'Slavistik', 'DF', 'H', 'H', '06', '146', 9999, 0, 'Ph', ''),
('Soziologie', 'Soziologie', 'Soziologie', 'CH', 'H', 'H', '06', '149', 9999, 0, 'Ph', ''),
('Sprachwiss', 'Sprachwissenschaft', 'Sprachwissenschaft', 'CD', 'H', 'H', '06', '152', 9999, 0, 'Ph', ''),
('Mazedonist', 'Mazedonistik', 'Mazedonistik', '64', 'H', 'H', '06', '153', 9999, 0, 'Ph', ''),
('Ethnologie', 'Ethnologie', 'Ethnologie', 'CG', 'H', 'H', '06', '173', 9999, 0, 'Ph', ''),
('Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB', 'H', 'H', '06', '175', 9999, 0, 'Wi', ''),
('Werkstoffw', 'Werkstoffwissenschaft', 'Werkstoffwissenschaft', 'HE', 'H', 'H', '06', '177', 9999, 0, '', ''),
('Wirt.ing.w', 'Wirtschaftsingenieurwesen', 'Wirtschaftsingenieurwesen', 'BB', 'H', 'H', '06', '179', 9999, 0, 'Wi', ''),
('Zahnmedizi', 'Zahnmedizin', 'Zahnmedizin', 'IA', 'H', 'H', '06', '185', 9999, 0, 'Me', ''),
('Rehab.päda', 'Rehabilitationspädagogik', 'Rehabilitationspädagogik', 'EB', 'H', 'H', '06', '190', 9999, 0, 'Pä', ''),
('Verarb.tec', 'Verarbeitungstechnik', 'Verarbeitungstechnik', '78', 'H', 'H', '06', '202', 9999, 0, '', ''),
('Verfahrens', 'Verfahrenstechnik', 'Verfahrenstechnik', 'HE', 'H', 'H', '06', '226', 9999, 0, '', ''),
('Wirtsch.Ma', 'Wirtschaftsmathematik', 'Wirtschaftsmathematik', 'HD', 'H', 'H', '06', '276', 9999, 0, 'Ma', ''),
('Wirtsch.In', 'Wirtschaftsinformatik', 'Wirtschaftsinformatik', 'BB', 'H', 'H', '06', '277', 9999, 0, 'Wi', ''),
('Bioingenie', 'Bio-Ingenieurwesen', 'Bio-Ingenieurwesen', 'HE', 'H', 'H', '06', '282', 9999, 0, '', ''),
('Politikwis', 'Politikwissenschaft', 'Politikwissenschaft', 'CE', 'H', 'H', '06', '300', 9999, 0, 'Ph', ''),
('Geologie/P', 'Geologie/Paläontologie', 'Geologie/Paläontologie', 'HB', 'H', 'H', '06', '302', 9999, 0, 'Ge', ''),
('Ernährungs', 'Ernährungswissenschaft', 'Ernährungswissenschaft', 'HA', 'H', 'H', '06', '320', 9999, 0, 'Ag', ''),
('Umwelttech', 'Umwelttechnik', 'Umwelttechnik', 'HE', 'H', 'H', '06', '457', 9999, 0, '', ''),
('Präh.Archä', 'Prähistor.Archäologie', 'Prähistorische Archäologie', 'CC', 'H', 'H', '06', '548', 9999, 0, 'Ph', ''),
('Betr.Wirt.', 'Betriebswirschaft d.Landw', 'Betriebswirtschaftslehre der Landwirtschaft', '30', 'H', 'H', '06', '602', 9999, 0, 'Wi', ''),
('Germ.Sprac', 'Germanist.Sprachwissensch', 'Germanistische Sprachwissenschaft', 'DB', 'H', 'H', '06', '603', 9999, 0, 'Ph', ''),
('Germ.Liter', 'Germanist.Literaturwiss.', 'Germanistische Literaturwissenschaft', 'DB', 'H', 'H', '06', '604', 9999, 0, 'Ph', ''),
('Sprechwiss', 'Sprechwissenschaft', 'Sprechwissenschaft', 'DF', 'H', 'H', '06', '605', 9999, 0, 'Ph', ''),
('Semitistik', 'Semitistik', 'Semitistik', 'CD', 'H', 'H', '06', '609', 9999, 0, 'Ph', ''),
('Italianist', 'Italianistik', 'Italianistik', 'DE', 'H', 'H', '06', '610', 9999, 0, 'Ph', ''),
('Angl./Amer', 'Anglistik/Amerikanistik', 'Anglistik/Amerikanistik', 'DA', 'H', 'H', '06', '613', 9999, 0, 'Ph', ''),
('Galloroman', 'Galloromanistik', 'Galloromanistik', 'DE', 'H', 'H', '06', '614', 9999, 0, 'Ph', ''),
('Hispanisti', 'Hispanistik', 'Hispanistik', 'DE', 'H', 'H', '06', '615', 9999, 0, 'Ph', ''),
('Lusitanist', 'Lusitanistik', 'Lusitanistik', 'DC', 'H', 'H', '06', '616', 9999, 0, 'Ph', ''),
('Polonistik', 'Polonistik', 'Polonistik', '64', 'H', 'H', '06', '618', 9999, 0, 'Ph', ''),
('Klass.Arch', 'Klassische Archäologie', 'Klassische Archäologie', 'CA', 'H', 'H', '06', '619', 9999, 0, 'Ph', ''),
('Mittellat.', 'Mittellatein.Philologie', 'Mittellateinische Philologie', 'CA', 'H', 'H', '06', '620', 9999, 0, 'Ph', ''),
('Or.Arch.u.', 'Oriental.Archäol.u.Kunst', 'Orientalische Archäologie und Kunst', 'CA', 'H', 'H', '06', '621', 9999, 0, 'Ph', ''),
('Sp/Lit Chr', 'Spr./Lit.d.Christl.Orient', 'Sprachen und Literaturen des Christlichen Orients', 'CD', 'H', 'H', '06', '623', 9999, 0, 'Ph', ''),
('Osteurop.G', 'Osteuropäische Geschichte', 'Osteuropäische Geschichte', 'CB', 'H', 'H', '06', '629', 9999, 0, 'Ph', ''),
('Mitt.u.Neu', 'Mittl.u.Neue Geschichte', 'Geschichte, Mittlere und Neuere', '62', 'H', 'H', '06', '630', 9999, 0, 'Ph', ''),
('Neueste Ge', 'Neueste Geschichte', 'Neueste Geschichte', '62', 'H', 'H', '06', '631', 9999, 0, 'Ph', ''),
('Sozialgesc', 'Sozialgeschichte', 'Sozialgeschichte', '62', 'H', 'H', '06', '632', 9999, 0, 'Ph', ''),
('Landesgesc', 'Landesgeschichte', 'Landesgeschichte', 'CB', 'H', 'H', '06', '633', 9999, 0, 'Ph', ''),
('Hist.Hilfs', 'Hist. Hilfswissensch.', 'Historische Hilfswissenschaften', 'CB', 'H', 'H', '06', '634', 9999, 0, 'Ph', ''),
('Klass.Phil', 'Klassische Philologie', 'Klassische Philologie', '63', 'H', 'H', '06', '637', 9999, 0, 'Ph', ''),
('Phonetik', 'Phonetik', 'Phonetik', '65', 'H', 'H', '06', '638', 9999, 0, 'Ph', ''),
('Russistik', 'Russistik', 'Russistik', 'DF', 'H', 'H', '06', '642', 9999, 0, 'Ph', ''),
('Latein.Phi', 'Lateinische Philologie', 'Lateinische Philologie', 'CA', 'H', 'H', '06', '644', 9999, 0, 'Ph', ''),
('Griech.Phi', 'Griechische Philologie', 'Griechische Philologie', 'CA', 'H', 'H', '06', '645', 9999, 0, 'Ph', ''),
('Alte Gesch', 'Alte Geschichte', 'Alte Geschichte', 'CB', 'H', 'H', '06', '651', 9999, 0, 'Ph', ''),
('Angl/Amer.', 'Anglistik/Amerikan.(Lit.)', 'Angl./Amerik. - Englische u. Amerikan. Literatur', '64', 'H', 'H', '06', '652', 9999, 0, 'Ph', ''),
('Angl/Amer.', 'Anglistik/Amerikan.(Spr.)', 'Angl./Amerikanistik-Englische Sprachwissenschaft', '64', 'H', 'H', '06', '653', 9999, 0, 'Ph', ''),
('Musik-Th.u', 'Theorie u.Prax.der Musik', 'Theorie und Praxis der Musik', '65', 'H', 'H', '06', '655', 9999, 0, 'Ph', ''),
('Pflegewiss', 'Pflegewissenschaft', 'Pflegewissenschaft/-management', 'IA', 'H', 'H', '06', '676', 9999, 0, 'Me', ''),
('Materialwi', 'Materialwissenschaft', 'Materialwissenschaft', '78', 'H', 'H', '06', '677', 9999, 0, '', ''),
('Didakt.d.G', 'Didaktik der Geschichte', 'Didaktik der Geschichte', 'CB', 'H', 'H', '06', '681', 9999, 0, 'Ph', ''),
('Wrt.u.Soz.', 'Wirtsch.u.Sozialgesch.', 'Wirtschafts- und Sozialgeschichte', 'CB', 'H', 'H', '06', '682', 9999, 0, 'Ph', ''),
('Zeitgeschi', 'Zeitgeschichte', 'Zeitgeschichte', 'CB', 'H', 'H', '06', '683', 9999, 0, 'Ph', ''),
('Medizin.Ph', 'Medizinische Physik', 'Medizinische Physik', 'GB', 'H', 'H', '06', '684', 9999, 0, 'Ch', ''),
('Biomed.Mat', 'Biomedizin.Materialien', 'Biomedizinische Materialien', 'FC', 'H', 'H', '06', '686', 9999, 0, '', ''),
('Alt-German', 'Altgermanistik', 'Altgermanistik', 'DB', 'H', 'H', '06', '689', 9999, 0, 'Ph', ''),
('Sp/Kult.n.', 'Spr./Kult.d.neuz.Südasien', 'Sprachen und Kulturen des neuzeitlichen Südasien', 'CD', 'H', 'H', '06', '690', 9999, 0, 'Ph', ''),
('Int.Wissen', 'Interkult.Wissenskommunik', 'Interkulturelle Wissenskommunikation', 'DC', 'H', 'H', '06', '693', 9999, 0, 'Ph', ''),
('Musikpädag', 'Musikpädagogik', 'Musikpädagogik', 'DD', 'H', 'H', '06', '697', 9999, 0, 'Ph', ''),
('Agrarwisse', 'Agrarwissenschaft', 'Agrarwissenschaft', 'HA', 'H', 'H', '97', '003', 9999, 0, 'Ag', ''),
('Alte Gesch', 'Alte Geschichte', 'Alte Geschichte', 'CB', 'H', 'H', '97', '651', 9999, 0, 'Ph', ''),
('Alt-German', 'Altgermanistik', 'Altgermanistik', 'DB', 'H', 'H', '97', '689', 9999, 0, 'Ph', ''),
('Amerikanis', 'Amerikanistik', 'Amerikanistik', 'DA', 'H', 'H', '97', '617', 9999, 0, 'Ph', ''),
('Anglistik', 'Anglistik', 'Anglistik', 'DA', 'H', 'H', '97', '612', 9999, 0, 'Ph', ''),
('Angl./Amer', 'Anglistik/Amerikanistik', 'Anglistik/Amerikanistik', 'DA', 'H', 'H', '97', '613', 9999, 0, 'Ph', ''),
('Appl.Polym', 'Applied Polymer Science', 'Master of Applied Polymer Science', 'GA', 'H', 'H', '97', '695', 9999, 0, '', ''),
('Arabistik', 'Arabistik', 'Arabistik', 'CD', 'H', 'H', '97', '010', 9999, 0, 'Ph', ''),
('Astronomie', 'Astronomie', 'Astronomie', 'GB', 'H', 'H', '97', '014', 9999, 0, 'Ch', ''),
('Betriebsw.', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', 'BB', 'H', 'H', '97', '021', 9999, 0, 'Wi', ''),
('Betr.Wirt.', 'Betriebswirschaft d.Landw', 'Betriebswirtschaftslehre der Landwirtschaft', '30', 'H', 'H', '97', '602', 9999, 0, 'Wi', ''),
('Biochemie', 'Biochemie', 'Biochemie', 'FA', 'H', 'H', '97', '025', 9999, 0, 'BC', ''),
('Bioingenie', 'Bio-Ingenieurwesen', 'Bio-Ingenieurwesen', 'HE', 'H', 'H', '97', '282', 9999, 0, '', ''),
('Biologie', 'Biologie', 'Biologie', 'FB', 'H', 'H', '97', '026', 9999, 0, 'Bi', ''),
('Biomed.Eng', 'Biomedical Engineering', 'Biomedical Engineering', 'IA', 'H', 'H', '97', '694', 9999, 0, 'Me', ''),
('Bio-Inform', 'Bioinformatik', 'Bioinformatik', 'HC', 'H', 'H', '97', '685', 9999, 0, 'Ma', ''),
('Chemie', 'Chemie', 'Chemie', 'GA', 'H', 'H', '97', '032', 9999, 0, 'Ch', ''),
('Chem.u.Umw', 'Chemie-u.Umweltingenieurw', 'Chemie- und Umweltingenieurwesen', 'HE', 'H', 'H', '97', '701', 9999, 0, '', ''),
('Denkmalpfl', 'Heritage management', 'Master of Science in Heritage management', 'CC', 'H', 'H', '97', '101', 9999, 0, 'Ph', ''),
('Didakt.d.G', 'Didaktik der Geschichte', 'Didaktik der Geschichte', 'CB', 'H', 'H', '97', '681', 9999, 0, 'Ph', ''),
('Englisch', 'Englisch', 'Englisch', 'DA', 'H', 'H', '97', '008', 9999, 0, 'Ph', ''),
('Ernährungs', 'Ernährungswissenschaft', 'Ernährungswissenschaft', 'HA', 'H', 'H', '97', '320', 9999, 0, 'Ag', ''),
('Erziehungs', 'Erziehungswissenschaft', 'Erziehungswissenschaft(Pädagogik)', 'EA', 'H', 'H', '97', '052', 9999, 0, 'Pä', ''),
('Ethik', 'Ethik', 'Ethik', 'CG', 'H', 'H', '97', '169', 9999, 0, 'Ph', ''),
('Ethnologie', 'Ethnologie', 'Ethnologie', 'CG', 'H', 'H', '97', '173', 9999, 0, 'Ph', ''),
('Europa/Ame', 'Interk.Europa/Amerikastud', 'Interkulturelle Europa- und Amerikastudien', 'DA', 'H', 'H', '97', '696', 9999, 0, 'Ph', ''),
('Ev.Religio', 'Evangelische Religion', 'Evangelische Religionslehre', 'A', 'H', 'H', '97', '643', 9999, 0, 'Th', ''),
('Ev.Theolog', 'Theologie', 'Evangelische Theologie', 'A', 'H', 'H', '97', '053', 9999, 0, 'Th', ''),
('Französisc', 'Französisch', 'Französisch', 'DE', 'H', 'H', '97', '059', 9999, 0, 'Ph', ''),
('Galloroman', 'Galloromanistik', 'Galloromanistik', 'DE', 'H', 'H', '97', '614', 9999, 0, 'Ph', ''),
('Geistigbeh', 'Geistigbehindertenpädagog', 'Geistigbehindertenpädagogik', 'EB', 'H', 'H', '97', '063', 9999, 0, 'Pä', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '97', '050', 9999, 0, 'Ge', ''),
('Geologie/P', 'Geologie/Paläontologie', 'Geologie/Paläontologie', 'HB', 'H', 'H', '97', '302', 9999, 0, 'Ge', ''),
('Germ.Liter', 'Germanist.Literaturwiss.', 'Germanistische Literaturwissenschaft', 'DB', 'H', 'H', '97', '604', 9999, 0, 'Ph', ''),
('Germ.Sprac', 'Germanist.Sprachwissensch', 'Germanistische Sprachwissenschaft', 'DB', 'H', 'H', '97', '603', 9999, 0, 'Ph', ''),
('Geschichte', 'Geschichte', 'Geschichte', 'CB', 'H', 'H', '97', '068', 9999, 0, 'Ph', ''),
('Griechisch', 'Griechisch', 'Griechisch', 'CA', 'H', 'H', '97', '070', 9999, 0, 'Ph', ''),
('Griech.Phi', 'Griechische Philologie', 'Griechische Philologie', 'CA', 'H', 'H', '97', '645', 9999, 0, 'Ph', ''),
('Hispanisti', 'Hispanistik', 'Hispanistik', 'DE', 'H', 'H', '97', '615', 9999, 0, 'Ph', ''),
('Hist.Hilfs', 'Hist. Hilfswissensch.', 'Historische Hilfswissenschaften', 'CB', 'H', 'H', '97', '634', 9999, 0, 'Ph', ''),
('Indologie', 'Indologie', 'Indologie', 'CA', 'H', 'H', '97', '078', 9999, 0, 'Ph', ''),
('Informatik', 'Informatik', 'Informatik', 'HC', 'H', 'H', '97', '079', 9999, 0, 'Ma', ''),
('Integratio', 'Integrationspädagogik', 'Integrationspädagogik', '61', 'H', 'H', '97', '699', 9999, 0, 'Pä', ''),
('Int.Wissen', 'Interkult.Wissenskommunik', 'Interkulturelle Wissenskommunikation', 'DC', 'H', 'H', '97', '693', 9999, 0, 'Ph', ''),
('Islamwisse', 'Islamwissenschaft', 'Islamwissenschaft', 'CD', 'H', 'H', '97', '083', 9999, 0, 'Ph', ''),
('Italianist', 'Italianistik', 'Italianistik', 'DE', 'H', 'H', '97', '610', 9999, 0, 'Ph', ''),
('Italienisc', 'Italienisch', 'Italienisch', 'DE', 'H', 'H', '97', '084', 9999, 0, 'Ph', ''),
('Japanologi', 'Japanologie', 'Japanologie', 'CE', 'H', 'H', '97', '085', 9999, 0, 'Ph', ''),
('Jüdisch.St', 'Jüdische Studien', 'Jüdische Studien', 'CD', 'H', 'H', '97', '073', 9999, 0, 'Ph', ''),
('Klass.Arch', 'Klassische Archäologie', 'Klassische Archäologie', 'CA', 'H', 'H', '97', '619', 9999, 0, 'Ph', ''),
('Klass.Phil', 'Klassische Philologie', 'Klassische Philologie', '63', 'H', 'H', '97', '637', 9999, 0, 'Ph', ''),
('Körperbeh.', 'Körperbehindertenpädagog.', 'Körperbehindertenpädagogik', '61', 'H', 'H', '97', '087', 9999, 0, 'Pä', ''),
('Kunstgesch', 'Kunstgeschichte', 'Kunstgeschichte', 'CC', 'H', 'H', '97', '092', 9999, 0, 'Ph', ''),
('Landesgesc', 'Landesgeschichte', 'Landesgeschichte', 'CB', 'H', 'H', '97', '633', 9999, 0, 'Ph', ''),
('Latein', 'Latein', 'Latein', 'CA', 'H', 'H', '97', '095', 9999, 0, 'Ph', ''),
('Latein.Phi', 'Lateinische Philologie', 'Lateinische Philologie', 'CA', 'H', 'H', '97', '644', 9999, 0, 'Ph', ''),
('Lebensm.-C', 'Lebensmittelchemie', 'Lebensmittelchemie', 'GA', 'H', 'H', '97', '096', 9999, 0, 'Ch', ''),
('Lernbeh.pä', 'Lernbehindertenpädagogik', 'Lernbehindertenpädagogik', 'EB', 'H', 'H', '97', '099', 9999, 0, 'Pä', ''),
('Mathematik', 'Mathematik', 'Mathematik', 'HD', 'H', 'H', '97', '105', 9999, 0, 'Ma', ''),
('Medien-u.K', 'Medien-u.Kommunikationsw.', 'Medien- und Kommunikationswissenschaft', 'DC', 'H', 'H', '97', '133', 9999, 0, 'Ph', ''),
('Medizin', 'Medizin', 'Medizin', 'IA', 'H', 'H', '97', '107', 9999, 0, 'Me', ''),
('Medizin.Ph', 'Medizinische Physik', 'Medizinische Physik', 'GB', 'H', 'H', '97', '684', 9999, 0, 'Ch', ''),
('Mineralogi', 'Mineralogie', 'Mineralogie', 'HB', 'H', 'H', '97', '111', 9999, 0, 'Ge', ''),
('Musik', 'Musik', 'Musik', 'DD', 'H', 'H', '97', '113', 9999, 0, 'Ph', ''),
('Musikerz.(', 'Musikerzieher Hf:Gesang', 'Musikerzieher - Hauptfach: Gesang', 'DD', 'H', 'H', '97', '679', 9999, 0, 'Ph', ''),
('Musikpädag', 'Musikpädagogik', 'Musikpädagogik', 'DD', 'H', 'H', '97', '697', 9999, 0, 'Ph', ''),
('Musikwiss.', 'Musikwissenschaft', 'Musikwissenschaft', 'DD', 'H', 'H', '97', '114', 9999, 0, 'Ph', ''),
('Orientalis', 'Orientalistik', 'Orientalistik', 'CD', 'H', 'H', '97', '122', 9999, 0, 'Ph', ''),
('Or.Arch.u.', 'Oriental.Archäol.u.Kunst', 'Orientalische Archäologie und Kunst', 'CA', 'H', 'H', '97', '621', 9999, 0, 'Ph', ''),
('Osteurop.G', 'Osteuropäische Geschichte', 'Osteuropäische Geschichte', 'CB', 'H', 'H', '97', '629', 9999, 0, 'Ph', ''),
('Pfl./Gesun', 'Pflege-u.Gesundheitswiss.', 'Pflege- und Gesundheitswissenschaft', 'IA', 'H', 'H', '97', '687', 9999, 0, 'Me', ''),
('Pharmazie', 'Pharmazie', 'Pharmazie', 'FC', 'H', 'H', '97', '126', 9999, 0, 'Ph', ''),
('Philosophi', 'Philosophie', 'Philosophie', 'CG', 'H', 'H', '97', '127', 9999, 0, 'Ph', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '97', '128', 9999, 0, 'Ch', ''),
('Politikwis', 'Politikwissenschaft', 'Politikwissenschaft', 'CE', 'H', 'H', '97', '300', 9999, 0, 'Ph', ''),
('Präh.Archä', 'Prähistor.Archäologie', 'Prähistorische Archäologie', 'CC', 'H', 'H', '97', '548', 9999, 0, 'Ph', ''),
('Psychologi', 'Psychologie', 'Psychologie', 'CF', 'H', 'H', '97', '132', 9999, 0, 'Ph', ''),
('Rechtswiss', 'Rechtswissenschaft (LLM)', 'Rechtswissenschaft (legum magister)', 'BA', 'H', 'H', '97', '135', 9999, 0, 'Ju', ''),
('Russisch', 'Russisch', 'Russisch', 'DF', 'H', 'H', '97', '139', 9999, 0, 'Ph', ''),
('Russistik', 'Russistik', 'Russistik', 'DF', 'H', 'H', '97', '642', 9999, 0, 'Ph', ''),
('Semitistik', 'Semitistik', 'Semitistik', 'CD', 'H', 'H', '97', '609', 9999, 0, 'Ph', ''),
('Slavistik', 'Slavistik', 'Slavistik', 'DF', 'H', 'H', '97', '146', 9999, 0, 'Ph', ''),
('Sozialkund', 'Sozialkunde', 'Sozialkunde', 'CE', 'H', 'H', '97', '147', 9999, 0, 'Ph', ''),
('Soziologie', 'Soziologie', 'Soziologie', 'CH', 'H', 'H', '97', '149', 9999, 0, 'Ph', ''),
('Spanisch', 'Spanisch', 'Spanisch', 'DE', 'H', 'H', '97', '150', 9999, 0, 'Ph', ''),
('Sport', 'Sport', 'Sport', 'DC', 'H', 'H', '97', '098', 9999, 0, 'Ph', ''),
('Sportwisse', 'Sportwissenschaft', 'Sportwissenschaft', 'DC', 'H', 'H', '97', '029', 9999, 0, 'Ph', ''),
('Sport(Br+W', 'Sportw.(Breiten u.Wettk.)', 'Sportwissensch. Schw: Breiten- und Wettkampfsport', '65', 'H', 'H', '97', '691', 9999, 0, 'Ph', ''),
('Sport(Ther', 'Sportw.(Präv/Reha/Therap)', 'Sportwiss. (Prävention,Rehabilitation,Therapie)', 'DC', 'H', 'H', '97', '692', 9999, 0, 'Ph', ''),
('Sprachbeh.', 'Sprachbehindertenpädagog.', 'Sprachbehindertenpädagogik', 'EB', 'H', 'H', '97', '151', 9999, 0, 'Pä', ''),
('Sprachwiss', 'Sprachwissenschaft', 'Sprachwissenschaft', 'CD', 'H', 'H', '97', '152', 9999, 0, 'Ph', ''),
('Sprechwiss', 'Sprechwissenschaft', 'Sprechwissenschaft', 'DF', 'H', 'H', '97', '605', 9999, 0, 'Ph', ''),
('Sp/Kult.n.', 'Spr./Kult.d.neuz.Südasien', 'Sprachen und Kulturen des neuzeitlichen Südasien', 'CD', 'H', 'H', '97', '690', 9999, 0, 'Ph', ''),
('Sp/Lit Chr', 'Spr./Lit.d.Christl.Orient', 'Sprachen und Literaturen des Christlichen Orients', 'CD', 'H', 'H', '97', '623', 9999, 0, 'Ph', ''),
('Technomath', 'Technomathematik', 'Technomathematik', 'HD', 'H', 'H', '97', '118', 9999, 0, 'Ma', ''),
('Umwelttech', 'Umwelttechnik', 'Umwelttechnik', 'HE', 'H', 'H', '97', '457', 9999, 0, '', ''),
('Verarb.tec', 'Verarbeitungstechnik', 'Verarbeitungstechnik', '78', 'H', 'H', '97', '202', 9999, 0, '', ''),
('Verh.gest.', 'Verhaltensgest.pädagogik', 'Verhaltensgestörtenpädagogik', 'EB', 'H', 'H', '97', '170', 9999, 0, 'Pä', ''),
('Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB', 'H', 'H', '97', '175', 9999, 0, 'Wi', ''),
('Werkstf.te', 'Werkstofftechnologie', 'Werkstofftechnologie', '78', 'H', 'H', '97', '688', 9999, 0, '', ''),
('Werkstoffw', 'Werkstoffwissenschaft', 'Werkstoffwissenschaft', 'HE', 'H', 'H', '97', '177', 9999, 0, '', ''),
('Wirtsch.In', 'Wirtschaftsinformatik', 'Wirtschaftsinformatik', 'BB', 'H', 'H', '97', '277', 9999, 0, 'Wi', ''),
('Wirtsch.Ma', 'Wirtschaftsmathematik', 'Wirtschaftsmathematik', 'HD', 'H', 'H', '97', '276', 9999, 0, 'Ma', ''),
('Wirtsch/Te', 'Wirtschaft/Technik', 'Wirtschaft und Technik', 'HE', 'H', 'H', '97', '606', 9999, 0, '', ''),
('Wirt.ing.w', 'Wirtschaftsingenieurwesen', 'Wirtschaftsingenieurwesen', 'BB', 'H', 'H', '97', '179', 9999, 0, 'Wi', ''),
('Wrt.u.Soz.', 'Wirtsch.u.Sozialgesch.', 'Wirtschafts- und Sozialgeschichte', 'CB', 'H', 'H', '97', '682', 9999, 0, 'Ph', ''),
('Zahnmedizi', 'Zahnmedizin', 'Zahnmedizin', 'IA', 'H', 'H', '97', '185', 9999, 0, 'Me', ''),
('Zeitgeschi', 'Zeitgeschichte', 'Zeitgeschichte', 'CB', 'H', 'H', '97', '683', 9999, 0, 'Ph', ''),
('Chemie', 'Master of chemistry', 'Master of chemistry', 'GA', 'H', 'H', '88', '032', 2000, 4, 'Ch', ''),
('Kath.Relig', 'Kathol.Religion(Grundsch)', 'Katholische Religionslehre (Grundschule)', 'EC', 'H', 'H', '21', '702', 9999, 7, 'Pä', ''),
('Kath.Relig', 'Kathol.Religion(Grundsch)', 'Katholische Religionslehre (Grundschule)', 'EC', 'H', 'H', '26', '702', 9999, 9, 'Pä', ''),
('Kunstgesch', 'Kunstgeschichte', 'Kunstgeschichte', 'CC', 'N', 'HHN', '02', '092', 9999, 9, 'Ph', ''),
('Latein', 'Latein', 'Latein', 'CA', 'H', 'H', '94', '095', 9999, 2, 'Ph', ''),
('Technik (S', 'Technik an Sekundarschul.', 'Technik an Sekundarschulen', '78', 'H', 'H', '94', '199', 9999, 2, '', ''),
('Musik', 'Musik', 'Musik', 'DD', 'H', 'H', '94', '113', 9999, 2, 'Ph', ''),
('Wirtsch.re', 'Master of Business Law', 'Master of Business Law', 'BA', 'H', 'H', '88', '042', 2004, 4, 'Ju', ''),
('Polnisch (', 'Fachübersetzen Polnisch', 'Fachübersetzen (Polnisch)', 'DC', 'N', 'N', '97', '130', 9999, 0, 'Ph', ''),
('Englisch (', 'Fachübersetzen Englisch', 'Fachübersetzen (Englisch)', 'DC', 'N', 'N', '97', '647', 9999, 0, 'Ph', ''),
('Lebensm.-C', 'Lebensmittelchemie', 'Lebensmittelchemie', 'GA', 'H', 'H', '06', '096', 9999, 0, 'Ch', ''),
('Wirtsch.re', 'LLM in oeconomics', 'Legum magister in oeconomics', 'BA', 'H', 'H', '93', '042', 9999, 4, 'Ju', ''),
('Jüdisch.St', 'Jüdische Studien', 'Jüdische Studien', 'CD', 'H', 'H', '06', '073', 9999, 0, 'Ph', ''),
('Ingwiss.In', 'Ing.wiss./Vert.Ing.Inform', 'Ingenieurwiss.,Vertiefung Ingenieurinformatik', 'HE', 'H', 'H', '06', '123', 9999, 0, '', ''),
('Anglistik', 'Anglistik', 'Anglistik', 'DA', 'H', 'H', '06', '612', 9999, 0, 'Ph', ''),
('Ik.EAs./US', 'Interk.Eur.Am.st./USA', 'Interkult. Europa- und Amerikastudien / USA', 'DA', 'S', 'SSK', '82', '711', 9999, 6, 'Ph', ''),
('Ik.EAs./Gr', 'Interk.Eur.Am.st./Gr.Brit', 'Interkult. Europa- und Amerikastudien / Gr.Brit.', 'DA', 'S', 'SSK', '82', '712', 9999, 6, 'Ph', ''),
('Ik.EAs./Fr', 'Interk.Eur.Am.st./Frankr.', 'Interkult. Europa- und Amerikastudien / Frankr.', 'DE', 'S', 'SSK', '82', '713', 9999, 6, 'Ph', ''),
('Ik.EAs./Ru', 'Interk.Eur.Am.st./Russl.', 'Interkult. Europa- und Amerikastudien / Russland', 'DF', 'S', 'SSK', '82', '714', 9999, 6, 'Ph', ''),
('Ik.EAs./La', 'Interk.Eur.Am.st./Lat.Am.', 'Interkult. Europa- und Amerikastudien / Lat.Amer.', 'DE', 'K', 'K', '82', '715', 9999, 6, 'Ph', ''),
('Ik.EAs./It', 'Interk.Eur.Am.st./Italien', 'Interkult. Europa- und Amerikastudien / Italien', 'DE', 'K', 'K', '82', '716', 9999, 6, 'Ph', ''),
('Ik.EAs./Po', 'Interk.Eur.Am.st./Polen', 'Interkult. Europa- und Amerikastudien / Polen', 'DF', 'K', 'K', '82', '717', 9999, 6, 'Ph', ''),
('Ik.EAs./SO', 'Interk.Eur.Am.st./SO-Eur.', 'Interkult. Europa- und Amerikastudien / SO-Europa', 'DF', 'K', 'K', '82', '718', 9999, 6, 'Ph', ''),
('Ik.EAs./D-', 'Interk.Eur.Am.st./D-Land', 'Interkult. Europa- und Amerikastudien / Deutschl.', 'DB', 'K', 'K', '82', '719', 9999, 6, 'Ph', ''),
('Ik.EAs./US', 'Interk.Eur.Am.st./USA', 'Interkult. Europa- und Amerikastudien / USA', 'DA', 'S', 'SSK', '88', '711', 2001, 4, 'Ph', ''),
('Ik.EAs./Gr', 'Interk.Eur.Am.st./Gr.Brit', 'Interkult. Europa- und Amerikastudien / Gr.Brit.', 'DA', 'S', 'SSK', '88', '712', 2001, 4, 'Ph', ''),
('Ik.EAs./Fr', 'Interk.Eur.Am.st./Frankr.', 'Interkult. Europa- und Amerikastudien / Frankr.', 'DE', 'S', 'SSK', '88', '713', 2001, 4, 'Ph', ''),
('Ik.EAs./Ru', 'Interk.Eur.Am.st./Russl.', 'Interkult. Europa- und Amerikastudien / Russland', 'DF', 'S', 'SSK', '88', '714', 2001, 4, 'Ph', ''),
('Ik.EAs./La', 'Interk.Eur.Am.st./Lat.Am.', 'Interkult. Europa- und Amerikastudien / Lat.Amer.', 'DE', 'K', 'K', '88', '715', 2001, 4, 'Ph', ''),
('Ik.EAs./It', 'Interk.Eur.Am.st./Italien', 'Interkult. Europa- und Amerikastudien / Italien', 'DE', 'K', 'K', '88', '716', 2001, 4, 'Ph', ''),
('Ik.EAs./Po', 'Interk.Eur.Am.st./Polen', 'Interkult. Europa- und Amerikastudien / Polen', 'DF', 'K', 'K', '88', '717', 2001, 4, 'Ph', ''),
('Ik.EAs./SO', 'Interk.Eur.Am.st./SO-Eur.', 'Interkult. Europa- und Amerikastudien / SO-Europa', 'DF', 'K', 'K', '88', '718', 2001, 4, 'Ph', ''),
('Ik.EAs./D-', 'Interk.Eur.Am.st./D-Land', 'Interkult. Europa- und Amerikastudien / Deutschl.', 'DB', 'K', 'K', '88', '719', 2001, 4, 'Ph', ''),
('Staatsbürg', 'Staatsbürgerkunde', 'Staatsbürgerkunde', '62', 'H', 'H', '24', '154', 9999, 8, 'Ph', ''),
('Staatsbürg', 'Staatsbürgerkunde', 'Staatsbürgerkunde', '62', 'H', 'H', '25', '154', 9999, 10, 'Ph', ''),
('Empir.Ökon', 'Empir.Ökonom/Polit.berat.', 'Empirische Ökonomik und Politikberatung', 'BB', 'H', 'H', '88', '775', 2003, 4, 'Wi', ''),
('Lebensm.-C', 'Lebensmittelchemie', 'Lebensmittelchemie', 'GA', 'H', 'H', '08', '096', 9999, 9, 'Ch', ''),
('Chem.u.Umw', 'Chemie-u.Umweltingenieurw', 'Chemie- und Umweltingenieurwesen', 'HE', 'H', 'H', '06', '701', 9999, 0, '', ''),
('Ik.EAs./US', 'Interk.Eur.Am.st./USA', 'Interkult. Europa- und Amerikastudien / USA', 'DA', 'S', 'SSK', '97', '711', 9999, 0, 'Ph', ''),
('Ik.EAs./Gr', 'Interk.Eur.Am.st./Gr.Brit', 'Interkult. Europa- und Amerikastudien / Gr.Brit.', 'DA', 'S', 'SSK', '97', '712', 9999, 0, 'Ph', ''),
('Ik.EAs./Fr', 'Interk.Eur.Am.st./Frankr.', 'Interkult. Europa- und Amerikastudien / Frankr.', 'DE', 'S', 'SSK', '97', '713', 9999, 0, 'Ph', ''),
('Ik.EAs./Ru', 'Interk.Eur.Am.st./Russl.', 'Interkult. Europa- und Amerikastudien / Russland', 'DF', 'S', 'SSK', '97', '714', 9999, 0, 'Ph', ''),
('Ik.EAs./La', 'Interk.Eur.Am.st./Lat.Am.', 'Interkult. Europa- und Amerikastudien / Lat.Amer.', 'DE', 'K', 'K', '97', '715', 9999, 0, 'Ph', ''),
('Ik.EAs./It', 'Interk.Eur.Am.st./Italien', 'Interkult. Europa- und Amerikastudien / Italien', 'DE', 'K', 'K', '97', '716', 9999, 0, 'Ph', ''),
('Ik.EAs./Po', 'Interk.Eur.Am.st./Polen', 'Interkult. Europa- und Amerikastudien / Polen', 'DF', 'K', 'K', '97', '717', 9999, 0, 'Ph', ''),
('Ik.EAs./SO', 'Interk.Eur.Am.st./SO-Eur.', 'Interkult. Europa- und Amerikastudien / SO-Europa', 'DF', 'K', 'K', '97', '718', 9999, 0, 'Ph', ''),
('Ik.EAs./D-', 'Interk.Eur.Am.st./D-Land', 'Interkult. Europa- und Amerikastudien / Deutschl.', 'DB', 'K', 'K', '97', '719', 9999, 0, 'Ph', ''),
('Betriebsw.', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', 'BB', 'H', 'H', '11', '021', 2003, 9, 'Wi', ''),
('Wirtsch.In', 'Wirtschaftsinformatik', 'Wirtschaftsinformatik', 'BB', 'H', 'H', '11', '277', 2003, 10, 'Wi', ''),
('Geowiss', 'Angew. Geowissenschaften', 'Angewandte Geowissenschaften', 'HB', 'H', 'H', '82', '039', 9999, 6, 'Ge', ''),
('Geowiss', 'Angew. Geowissenschaften', 'Angewandte Geowissenschaften', 'HB', 'H', 'H', '88', '039', 2003, 3, 'Ge', ''),
('Integratio', 'Integrationspädagogik', 'Integrationspädagogik', '61', 'H', 'H', '26', '699', 9999, 4, 'Pä', ''),
('Hauswirtsc', 'Hauswirtschaft', 'Hauswirtschaft', 'EA', 'H', 'H', '97', '654', 9999, 8, 'Pä', ''),
('Ethik', 'Ethik', 'Ethik', 'CG', 'H', 'H', '94', '169', 9999, 0, 'Ph', ''),
('Astronomie', 'Astronomie', 'Astronomie', 'GB', 'H', 'H', '94', '014', 9999, 0, 'Ch', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '94', '128', 9999, 0, 'Ch', ''),
('Englisch', 'Englisch', 'Englisch', 'DA', 'H', 'H', '21', '008', 9999, 0, 'Ph', ''),
('Multim/VRI', 'Multimedia/Virtual R.Inf.', 'Multimedia/Virtulal Reality-Informatik', 'HC', 'H', 'H', '11', '121', 9999, 9, 'Ma', ''),
('Stkoll W', 'W-Kurs', 'W-Kurs', 'QA', 'H', 'H', '95', '722', 9999, 2, '', ''),
('Stkoll T', 'T-Kurs', 'T-Kurs', 'QA', 'H', 'H', '95', '723', 9999, 2, '', ''),
('Stkoll S/G', 'S/G-Kurs', 'S/G-Kurs', 'QA', 'H', 'H', '95', '724', 9999, 2, '', ''),
('Stkoll M', 'M-Kurs', 'M-Kurs', 'QA', 'H', 'H', '95', '725', 9999, 2, '', ''),
('Stkoll DSH', 'DSH-Kurs', 'DSH-Kurs', 'QA', 'H', 'H', '95', '726', 9999, 2, '', ''),
('Polnisch (', 'Fachübersetzen Polnisch', 'Fachübersetzen (Polnisch)', 'DC', 'H', 'H', '97', '130', 9999, 0, 'Ph', ''),
('Klavier', 'Klavier', 'Klavier', 'DD', 'H', 'H', '11', '675', 9999, 9, 'Ph', ''),
('Klavier', 'Klavier', 'Klavier', 'DD', 'H', 'H', '97', '675', 9999, 9, 'Ph', ''),
('MM&A', 'MultiMedia & Autor', 'MultiMedia & Autorschaft', 'DC', 'H', 'H', '88', '727', 2005, 4, 'Ph', ''),
('Bio-Inform', 'Bioinformatik', 'Bioinformatik', 'HC', 'H', 'H', '06', '685', 9999, 9, 'Ma', ''),
('Sportwisse', 'Sportwissenschaft', 'Sportwissenschaft', 'DC', 'H', 'H', '26', '029', 9999, 9, 'Ph', ''),
('Geologie/P', 'Geologie/Paläontologie', 'Geologie/Paläontologie', 'HB', 'H', 'H', '11', '302', 9999, 9, 'Ge', ''),
('Qu/Bi/Sozi', 'Quali./Bildg./Sozialf.', 'Qualitative Bildungs- und Sozialforschung', '61', 'H', 'H', '94', '720', 9999, 4, 'Pä', '');
INSERT INTO `his_abstgv` (`ktxt`, `dtxt`, `ltxt`, `fb`, `kzfa`, `kzfaarray`, `abschl`, `stg`, `pversion`, `regelstz`, `login_part`, `studip_studiengang`) VALUES
('Pfl./Gesun', 'Pflege-u.Gesundheitswiss.', 'Pflege- und Gesundheitswissenschaft', 'IA', 'H', 'H', '06', '687', 9999, 0, 'Me', ''),
('Sportwisse', 'Sportwissenschaft', 'Sportwissenschaft', 'DC', 'H', 'H', '82', '029', 9999, 6, 'Ph', ''),
('M./Eth./R.', 'Medizin-Ethik-Recht', 'Medizin-Ethik-Recht', 'BA', 'H', 'H', '94', '721', 9999, 2, 'Ju', ''),
('Sport', 'Sport', 'Sport', 'DC', 'H', 'H', '06', '098', 9999, 0, 'Ph', ''),
('GehörlPäd', 'Gehörl/Schwerhö/Pädagogik', 'Gehörlosen-/Schwerhörigenpädagogik', 'EB', 'H', 'H', '26', '062', 9999, 9, 'Pä', ''),
('Sehbeh.Päd', 'Blind/Sehbehindertenpäd.', 'Blinden-/Sehbehindertenpädagogik', '61', 'H', 'H', '26', '027', 9999, 9, 'Pä', ''),
('ChrArch/By', 'Chr.Arch./Byz.Kunstgesch.', 'Christl. Archäologie u. Byzantin. Kunstgeschichte', 'CC', 'H', 'H', '06', '698', 9999, 0, 'Ph', ''),
('Geistigbeh', 'Geistigbehindertenpädagog', 'Geistigbehindertenpädagogik', 'EB', 'H', 'H', '26', '063', 9999, 9, 'Pä', ''),
('Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB', 'H', 'H', '11', '175', 9999, 9, 'Wi', ''),
('Latein', 'Latein', 'Latein', 'CA', 'H', 'H', '25', '095', 9999, 9, 'Ph', ''),
('Mathematik', 'Mathematik', 'Mathematik', 'HD', 'H', 'H', '11', '105', 9999, 9, 'Ma', ''),
('Medien-u.K', 'Medien-u.Kommunikationsw.', 'Medien- und Kommunikationswissenschaft', 'DC', 'N', 'HHN', '02', '133', 9999, 9, 'Ph', ''),
('Chemie', 'Chemie', 'Chemie', 'GA', 'H', 'H', '11', '032', 9999, 10, 'Ch', ''),
('Chemie', 'Chemistry', 'Chemistry', 'GA', 'H', 'H', '82', '032', 9999, 6, 'Ch', ''),
('Psychologi', 'Psychologie', 'Psychologie', 'CF', 'H', 'H', '11', '132', 9999, 9, 'Ph', ''),
('Informatik', 'Informatik', 'Informatik', 'HC', 'H', 'H', '11', '079', 2003, 9, 'Ma', ''),
('Soziologie', 'Soziologie', 'Soziologie', 'CH', 'H', 'H', '11', '149', 9999, 9, 'Ph', ''),
('Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB', 'N', 'N', '02', '175', 9999, 9, 'Wi', ''),
('Politikwis', 'Politikwissenschaft', 'Politikwisschenschaften', 'CE', 'H', 'H', '11', '300', 1996, 9, 'Ph', ''),
('Ev.Theolog', 'Ev. Theologie', 'Evangelische Theologie', 'A', 'N', 'HHN', '02', '053', 9999, 9, 'Th', ''),
('Geschichte', 'Geschichte', 'Geschichte', 'CB', 'N', 'HHN', '02', '068', 9999, 9, 'Ph', ''),
('Japanologi', 'Japanologie', 'Japanologie', 'CE', 'N', 'HHN', '02', '085', 9999, 9, 'Ph', ''),
('Jüdisch.St', 'Jüdische Studien', 'Jüdische Studien', 'CD', 'N', 'HHN', '02', '073', 9999, 9, 'Ph', ''),
('Betriebsw.', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', 'BB', 'H', 'H', '06', '021', 9999, 0, 'Wi', ''),
('Rechtswiss', 'Rechtswissenschaft', 'Rechtswissenschaft', 'BA', 'N', 'H', '02', '135', 9999, 9, 'Ju', ''),
('MNRessourc', 'Management nat Ressourcen', 'Management natürlicher Ressourcen', 'HA', 'H', 'H', '06', '093', 9999, 0, 'Ag', ''),
('Chemie', 'Master of chemistry', 'Master of chemistry', 'GA', 'H', 'H', '88', '032', 9999, 4, 'Ch', ''),
('KirMusik', 'Kirchenmusik', 'Kirchenmusik', '65', 'H', '', '25', '193', 9999, 10, 'Ph', ''),
('Erziehungs', 'Erziehungswissenschaft', 'Erziehungswissenschaft(Pädagogik)', 'EA', 'N', 'N', '02', '052', 9999, 9, 'Pä', ''),
('Empir.Ökon', 'Empir.Ökonom/Polit.berat.', 'Empirische Ökonomik und Politikberatung', 'BB', 'H', 'H', '88', '775', 9999, 4, 'Wi', ''),
('Betriebsw.', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', 'BB', 'H', 'H', '11', '021', 9999, 9, 'Wi', ''),
('Philosophi', 'Philosophie', 'Philosophie', 'CG', 'N', 'HHN', '02', '127', 9999, 9, 'Ph', ''),
('Musikwiss.', 'Musikwissenschaft', 'Musikwissenschaft', 'DD', 'N', 'HHN', '02', '114', 9999, 9, 'Ph', ''),
('Indologie', 'Indologie', 'Indologie', 'CA', 'N', 'HHN', '02', '078', 9999, 9, 'Ph', ''),
('Agrarw180', 'Agrarwissenschaft180', 'Agrarwissenschaft', 'HA', 'H', '', '82', '803', 106, 6, 'Ag', ''),
('Geowiss180', 'Angew. Geowissen180', 'Angewandte Geowissenschaften (Applied Geosciences)', 'HB', 'H', '', '82', '839', 106, 6, 'Ge', ''),
('Arabist60', 'Arabistik/Islamwiss.60', 'Arabistik/Islamwissenschaft', 'CD', 'N', '', '83', '510', 106, 6, 'Ph', ''),
('Arabist90', 'Arabistik/Islamwiss.90', 'Arabistik/Islamwissenschaft', 'CD', 'K', '', '83', '910', 106, 6, 'Ph', ''),
('Chemie180', 'Chemie180', 'Chemie', 'GA', 'H', '', '82', '832', 106, 6, 'Ch', ''),
('DSprLit90', 'Deut.SpracheLiteratur90', 'Deutsche Sprache und Literatur', 'DB', 'K', '', '83', '967', 106, 6, 'Ph', ''),
('Ethnolo60', 'Ethnologie60', 'Ethnologie', 'CG', 'N', '', '83', '573', 106, 6, 'Ph', ''),
('Ethnolo90', 'Ethnologie90', 'Ethnologie', 'CG', 'K', '', '83', '973', 106, 6, 'Ph', ''),
('Geogra60', 'Geographie60', 'Geographie', 'HB', 'N', '', '83', '550', 106, 6, 'Ge', ''),
('Geogra120', 'Geographie120', 'Geographie', 'HB', 'S', '', '83', '250', 106, 6, 'Ge', ''),
('Geogra180', 'Geographie180', 'Geographie', 'HB', 'H', '', '82', '850', 106, 6, 'Ge', ''),
('Gesch60', 'Geschichte60', 'Geschichte', 'CB', 'N', '', '83', '568', 106, 6, 'Ph', ''),
('Gesch90', 'Geschichte90', 'Geschichte', 'CB', 'K', '', '83', '968', 106, 6, 'Ph', ''),
('Slavistik', 'Slavistik', 'Slavistik', 'DF', 'N', 'HHN', '02', '146', 9999, 9, 'Ph', ''),
('Soziologie', 'Soziologie', 'Soziologie', 'CH', 'N', 'HHN', '02', '149', 9999, 9, 'Ph', ''),
('Sprachwiss', 'Sprachwissenschaft', 'Sprachwissenschaft', 'CD', 'N', 'HHN', '02', '152', 9999, 9, 'Ph', ''),
('Rehab.päda', 'Rehabilitationspädagogik', 'Rehabilitationspädagogik', 'EB', 'N', 'HHN', '02', '190', 9999, 9, 'Pä', ''),
('Politikwis', 'Politikwissenschaft', 'Politikwissenschaft', 'CE', 'N', 'HHN', '02', '300', 9999, 9, 'Ph', ''),
('Präh.Archä', 'Prähistor.Archäologie', 'Prähistorische Archäologie', 'CC', 'N', 'HHN', '02', '548', 9999, 9, 'Ph', ''),
('Germ.Sprac', 'Germanist.Sprachwissensch', 'Germanistische Sprachwissenschaft', 'DB', 'N', 'HHN', '02', '603', 9999, 9, 'Ph', ''),
('Germ.Liter', 'Germanist.Literaturwiss.', 'Germanistische Literaturwissenschaft', 'DB', 'N', 'HHN', '02', '604', 9999, 9, 'Ph', ''),
('Sprechwiss', 'Sprechwissenschaft', 'Sprechwissenschaft', 'DF', 'N', 'HHN', '02', '605', 9999, 9, 'Ph', ''),
('Semitistik', 'Semitistik', 'Semitistik', 'CD', 'N', 'HHN', '02', '609', 9999, 9, 'Ph', ''),
('Italianist', 'Italianistik', 'Italianistik', 'DE', 'N', 'HHN', '02', '610', 9999, 9, 'Ph', ''),
('Angl./Amer', 'Anglistik/Amerikanistik', 'Anglistik/Amerikanistik', 'DA', 'N', 'HHN', '02', '613', 9999, 9, 'Ph', ''),
('Galloroman', 'Galloromanistik', 'Galloromanistik', 'DE', 'N', 'HHN', '02', '614', 9999, 9, 'Ph', ''),
('Kunstgesch', 'Kunstgeschichte Byz.', 'Kunstgeschichte Byzantinistik', '63', 'N', 'HHN', '02', '624', 9999, 9, 'Ph', ''),
('Hispanisti', 'Hispanistik', 'Hispanistik', 'DE', 'N', 'HHN', '02', '615', 9999, 9, 'Ph', ''),
('Klass.Arch', 'Klassische Archäologie', 'Klassische Archäologie', 'CA', 'N', 'HHN', '02', '619', 9999, 9, 'Ph', ''),
('Mittellat.', 'Mittellatein.Philologie', 'Mittellateinische Philologie', 'CA', 'N', 'HHN', '02', '620', 9999, 9, 'Ph', ''),
('Or.Arch.u.', 'Oriental.Archäol.u.Kunst', 'Orientalische Archäologie und Kunst', 'CA', 'N', 'HHN', '02', '621', 9999, 9, 'Ph', ''),
('Sp/Lit Chr', 'Spr./Lit.d.Christl.Orient', 'Sprachen und Literaturen des Christlichen Orients', 'CD', 'N', 'HHN', '02', '623', 9999, 9, 'Ph', ''),
('Latein.Phi', 'Lateinische Philologie', 'Lateinische Philologie', 'CA', 'N', 'HHN', '02', '644', 9999, 9, 'Ph', ''),
('Griech.Phi', 'Griechische Philologie', 'Griechische Philologie', 'CA', 'N', 'HHN', '02', '645', 9999, 9, 'Ph', ''),
('Alte Gesch', 'Alte Geschichte', 'Alte Geschichte', 'CB', 'N', 'HHN', '02', '651', 9999, 9, 'Ph', ''),
('Sp/Kult.n.', 'Spr./Kult.d.neuz.Südasien', 'Sprachen und Kulturen des neuzeitlichen Südasien', 'CD', 'N', 'HHN', '02', '690', 9999, 9, 'Ph', ''),
('Int.Wissen', 'Interkult.Wissenskommunik', 'Interkulturelle Wissenskommunikation', 'DC', 'N', 'HHN', '02', '693', 9999, 9, 'Ph', ''),
('ChrArch/By', 'Chr.Arch./Byz.Kunstgesch.', 'Christl. Archäologie u. Byzantin. Kunstgeschichte', 'CC', 'N', 'HHN', '02', '698', 9999, 9, 'Ph', ''),
('Ethnologie', 'Ethnologie', 'Ethnologie', 'CG', 'N', 'HHN', '02', '173', 9999, 9, 'Ph', ''),
('Ik.EAs./US', 'Interk.Eur.Am.st./USA', 'Interkult. Europa- und Amerikastudien / USA', 'DA', 'K', 'SSK', '82', '711', 9999, 6, 'Ph', ''),
('Ik.EAs./Gr', 'Interk.Eur.Am.st./Gr.Brit', 'Interkult. Europa- und Amerikastudien / Gr.Brit.', 'DA', 'K', 'SSK', '82', '712', 9999, 6, 'Ph', ''),
('Ik.EAs./Fr', 'Interk.Eur.Am.st./Frankr.', 'Interkult. Europa- und Amerikastudien / Frankr.', 'DE', 'K', 'SSK', '82', '713', 9999, 6, 'Ph', ''),
('Ik.EAs./Ru', 'Interk.Eur.Am.st./Russl.', 'Interkult. Europa- und Amerikastudien / Russland', 'DF', 'K', 'SSK', '82', '714', 9999, 6, 'Ph', ''),
('Ik.EAs./US', 'Interk.Eur.Am.st./USA', 'Interkult. Europa- und Amerikastudien / USA', 'DA', 'K', 'SSK', '88', '711', 2001, 4, 'Ph', ''),
('Ik.EAs./Gr', 'Interk.Eur.Am.st./Gr.Brit', 'Interkult. Europa- und Amerikastudien / Gr.Brit.', 'DA', 'K', 'SSK', '88', '712', 2001, 4, 'Ph', ''),
('Ik.EAs./Fr', 'Interk.Eur.Am.st./Frankr.', 'Interkult. Europa- und Amerikastudien / Frankr.', 'DE', 'K', 'SSK', '88', '713', 2001, 4, 'Ph', ''),
('Ik.EAs./Ru', 'Interk.Eur.Am.st./Russl.', 'Interkult. Europa- und Amerikastudien / Russland', 'DF', 'K', 'SSK', '88', '714', 2001, 4, 'Ph', ''),
('Ik.EAs./US', 'Interk.Eur.Am.st./USA', 'Interkult. Europa- und Amerikastudien / USA', 'DA', 'K', 'SSK', '97', '711', 9999, 0, 'Ph', ''),
('Ik.EAs./Gr', 'Interk.Eur.Am.st./Gr.Brit', 'Interkult. Europa- und Amerikastudien / Gr.Brit.', 'DA', 'K', 'SSK', '97', '712', 9999, 0, 'Ph', ''),
('Ik.EAs./Fr', 'Interk.Eur.Am.st./Frankr.', 'Interkult. Europa- und Amerikastudien / Frankr.', 'DE', 'K', 'SSK', '97', '713', 9999, 0, 'Ph', ''),
('Ik.EAs./Ru', 'Interk.Eur.Am.st./Russl.', 'Interkult. Europa- und Amerikastudien / Russland', 'DF', 'K', 'SSK', '97', '714', 9999, 0, 'Ph', ''),
('Int.Fi.Man', 'Inter.Finanzmanagement', 'Internationales Finanzmanagement', 'BB', 'H', 'H', '88', '728', 2003, 4, 'Wi', ''),
('Gesch120', 'Geschichte120', 'Geschichte', 'CB', 'S', '', '83', '268', 106, 6, 'Ph', ''),
('AAAMA45', 'Angew.Amerik./Angli.MA45', 'Angewandte Amerikanistik und Anglistik (AAA)', 'DA', 'N', '', '89', '406', 107, 4, 'Ph', ''),
('Indolog90', 'Indologie90', 'Indologie (Kultur- und Geistesgeschichte des Vormodernen Indien)', 'CA', 'K', '', '83', '978', 106, 6, 'Ph', ''),
('Inform180', 'Informatik180', 'Informatik', 'HC', 'H', 'H', '82', '879', 106, 6, 'Ma', ''),
('Japano60', 'Japanologie60', 'Japanologie', 'CE', 'N', '', '83', '585', 106, 6, 'Ph', ''),
('Japano90', 'Japanologie90', 'Japanologie', 'CE', 'K', '', '83', '985', 106, 6, 'Ph', ''),
('Kunstge60', 'Kunstgeschichte60', 'Kunstgeschichte', 'CC', 'N', '', '83', '592', 106, 6, 'Ph', ''),
('Kunstge90', 'Kunstgeschichte90', 'Kunstgeschichte', 'CC', 'K', '', '83', '992', 106, 6, 'Ph', ''),
('Kunstge120', 'Kunstgeschichte120', 'Kunstgeschichte', 'CC', 'S', '', '83', '292', 106, 6, 'Ph', ''),
('LateinEU90', 'Latein Europas90', 'Latein Europas', 'CA', 'K', '', '83', '995', 107, 6, 'Ph', ''),
('Mathe180', 'Mathematik180', 'Mathematik mit Anwendungsfach', 'HD', 'H', '', '82', '805', 106, 6, 'Ma', ''),
('Med.Phy180', 'Medizinische Physik180', 'Medizinische Physik', 'GB', 'H', '', '82', '884', 106, 6, 'Ch', ''),
('Philo60', 'Philosophie60', 'Philosophie', 'CG', 'N', '', '83', '527', 106, 6, 'Ph', ''),
('Philo90', 'Philosophie90', 'Philosophie', 'CG', 'K', '', '83', '927', 106, 6, 'Ph', ''),
('Physik180', 'Physik180', 'Physik', 'GB', 'H', '', '82', '828', 106, 6, 'Ch', ''),
('Politikw60', 'Politikwissenschaft60', 'Politikwissenschaft', 'CE', 'N', '', '83', '500', 106, 6, 'Ph', ''),
('Politikw90', 'Politikwissenschaft90', 'Politikwissenschaft', 'CE', 'K', '', '83', '900', 106, 6, 'Ph', ''),
('Politik120', 'Politikwissenschaft120', 'Politikwissenschaft', 'CE', 'S', '', '83', '200', 106, 6, 'Ph', ''),
('Psycho60', 'Psychologie60', 'Psychologie', 'CF', 'N', '', '83', '531', 107, 6, 'Ph', ''),
('Psycho180', 'Psychologie180', 'Psychologie', 'CF', 'H', '', '82', '831', 106, 6, 'Ph', ''),
('Soziolo60', 'Soziologie60', 'Soziologie', 'CH', 'N', '', '83', '549', 106, 6, 'Ph', ''),
('Soziolo90', 'Soziologie90', 'Soziologie', 'CH', 'K', '', '83', '949', 106, 6, 'Ph', ''),
('Soziolo120', 'Soziologie120', 'Soziologie', 'CH', 'S', '', '83', '249', 106, 6, 'Ph', ''),
('Sportwi60', 'Sportwissenschaft60', 'Sportwissenschaft', 'DC', 'N', '', '83', '598', 106, 6, 'Ph', ''),
('Sportwi90', 'Sportwissenschaft90', 'Sportwissenschaft', 'DC', 'K', '', '83', '998', 106, 6, 'Ph', ''),
('Sportwi120', 'Sportwissenschaft120', 'Sportwissenschaft', 'DC', 'S', '', '83', '298', 106, 6, 'Ph', ''),
('MRessou180', 'Management nat.Ressour180', 'Management natürlicher Ressourcen', 'HA', 'H', '', '82', '893', 106, 6, 'Ag', ''),
('WirInfo60', 'Wirtschaftsinformatik60', 'Grundlagen Wirtschaftsinformatik (Fundamentals Business Information Systems)', 'BB', 'N', '', '83', '572', 106, 6, 'Wi', ''),
('WirInfo120', 'Wirtschaftsinformatik120', 'Kernfach Wirtschaftsinformatik  (Core Subject Business Information Systems)', 'BB', 'S', '', '83', '272', 106, 6, 'Wi', ''),
('WirInfo180', 'Wirtschaftsinformatik180', 'Wirtschaftsinformatik (Business Information Systems)', 'BB', 'H', '', '82', '872', 106, 6, 'Wi', ''),
('SAKunde90', 'Südasienkunde90', 'Südasienkunde (South Asian Studies)', 'CD', 'K', '', '83', '936', 106, 6, 'Ph', ''),
('WirtMat180', 'Wirtschaftsmathematik180', 'Wirtschaftsmathematik', 'HD', 'H', '', '82', '876', 106, 6, 'Ma', ''),
('WissChOr60', 'WissChristOrient60', 'Wissenschaft vom Christlichen Orient', 'CD', 'N', '', '83', '522', 106, 6, 'Ph', ''),
('WissChOr90', 'WissChristOrient90', 'Wissenschaft vom Christlichen Orient', 'CD', 'K', '', '83', '922', 106, 6, 'Ph', ''),
('ArchKu60', 'Archäol Kunst Orient60', 'Archäologie und Kunstgeschichte des vorislamischen Orients', 'CA', 'N', '', '83', '512', 106, 6, 'Ph', ''),
('ArchKu90', 'Archäol Kunst Orient90', 'Archäologie und Kunstgeschichte des vorislamischen Orients', 'CA', 'K', '', '83', '912', 106, 6, 'Ph', ''),
('ArchäoEU90', 'Archäologien EU90', 'Archäologien Europas', 'CC', 'K', '', '83', '913', 106, 6, 'Ph', ''),
('BLIK90', 'Beruforient.Linguistik90', 'Berufsorientierte Linguistik im interkulturellen Kontext (BLIK)', 'CD', 'K', '', '83', '952', 106, 6, 'Ph', ''),
('IntSüdas60', 'InterkulturelleSüdasien60', 'Interkulturelle Südasienkunde', 'CD', 'N', '', '83', '536', 106, 6, 'Ph', ''),
('JüdiSt60', 'Judaistik/Jüdische Stud60', 'Judaistik/Jüdische Studien', 'CD', 'N', '', '83', '574', 106, 6, 'Ph', ''),
('JüdiSt90', 'Judaistik/Jüdische Stud90', 'Judaistik/Jüdische Studien', 'CD', 'K', '', '83', '974', 106, 6, 'Ph', ''),
('KAArcGes90', 'K.Altertum/Archäologie90', 'Klassisches Altertum/Klassische Archäologie', 'CA', 'K', '', '83', '924', 106, 6, 'Ph', ''),
('KlasAlt120', 'Klassisches Altertum120', 'Klassisches Altertum', 'CA', 'S', '', '83', '224', 106, 6, 'Ph', ''),
('KlasAlt180', 'Klassisches Altertum180', 'Klassisches Altertum', 'CA', 'H', '', '82', '824', 106, 6, 'Ph', ''),
('KAAltGes90', 'K.Altertum/AlteGeschich90', 'Klassisches Altertum/Alte Geschichte', 'CA', 'K', '', '83', '923', 106, 6, 'Ph', ''),
('Sprechw180', 'Sprechwissenschaft180', 'Sprechwissenschaft', 'DF', 'H', '', '82', '806', 106, 6, 'Ph', ''),
('RelOrien90', 'Religionsges d.Orients90', 'Religionsgeschichte des Orients', 'CD', 'K', '', '83', '940', 106, 6, 'Ph', ''),
('Agrarwisse', 'Agrarwissenschaft', 'Agrarwissenschaft', 'HA', 'H', 'H', '11', '003', 2005, 9, 'Ag', ''),
('Bio-Inform', 'Bioinformatik', 'Bioinformatik', 'HC', 'H', 'H', '11', '685', 2003, 9, 'Ma', ''),
('WirtWiss60', 'Wirtschaftswiss60', 'Grundlagen Wirtschaftswissenschaften (Fundamental Economics and Management)', 'BB', 'N', '', '83', '584', 106, 6, 'Wi', ''),
('WirtWis120', 'Wirtschaftswiss120', 'Wirtschaftswissenschaften (Economics and Management)', 'BB', 'S', '', '83', '284', 106, 6, 'Wi', ''),
('KAGräzis90', 'K.Altertum/Gräzistik90', 'Klassisches Altertum/Gräzistik', 'CA', 'K', '', '83', '925', 106, 6, 'Ph', ''),
('KALatini90', 'K.Altertum/Latinistik90', 'Klassisches Altertum/Latinistik', 'CA', 'K', '', '83', '926', 106, 6, 'Ph', ''),
('PoliSoz180', 'Politikwiss.Soziologie180', 'Politikwissenschaft - Soziologie', 'CE', 'H', '', '82', '800', 106, 6, 'Ph', ''),
('Rechtswiss', 'Rechtswissenschaft', 'Rechtswissenschaft', 'BA', 'H', 'H', '08', '135', 1111, 9, 'Ju', ''),
('BWL180', 'BWL (Business Studies)180', 'Betriebswirtschaftslehre (Business Studies)', 'BB', 'H', '', '82', '820', 106, 6, 'Wi', ''),
('VWL180', 'VWL (Economics)180', 'Volkswirtschaftslehre (Economics)', 'BB', 'H', '', '82', '874', 106, 6, 'Wi', ''),
('Busines180', 'Business Studies(Int.)180', 'Business Studies (International)', 'BB', 'H', '', '82', '821', 2003, 6, 'Wi', ''),
('Economi180', 'Economics(Int.)180', 'Economics (International)', 'BB', 'H', '', '82', '875', 2003, 6, 'Wi', ''),
('AlteWelt90', 'Alte Welt90', 'Alte Welt', 'CD', 'K', '', '83', '953', 106, 6, 'Ph', ''),
('BWLMA120', 'BWL (Business Stud.)MA120', 'Betriebswirtschaftslehre (Business Studies)', 'BB', 'H', '', '88', '731', 106, 4, 'Wi', ''),
('AcTaxMA120', 'Accounting&TaxationMA120', 'Accounting and Taxation', 'BB', 'H', '', '88', '730', 106, 4, 'Wi', ''),
('HRManMA120', 'HumanRes.ManagementMA120', 'Human Resource Management', 'BB', 'H', '', '88', '729', 106, 4, 'Wi', ''),
('WiInfMA120', 'WirtschaftsinformatMA120', 'Wirtschaftsinformatik (Business Information Systems)', 'BB', 'H', '', '88', '777', 106, 4, 'Wi', ''),
('VWLMA120', 'VWL (Economics)MA120', 'Volkswirtschaftslehre (Economics)', 'BB', 'H', '', '88', '776', 106, 4, 'Wi', ''),
('Gesang', 'Gesang', 'Gesang', 'DD', 'H', 'H', '11', '679', 9999, 8, 'Ph', ''),
('DSLitMA120', 'DeutSpracheLiteraturMA120', 'Deutsche Sprache und Literatur', 'DB', 'H', '', '88', '767', 106, 4, 'Ph', ''),
('Astronomie', 'Astronomie', 'Astronomie', 'GB', 'H', 'HHN', '26', '014', 9999, 2, 'Ch', ''),
('Kathol.Rel', 'Kathol. Theol, -Religio', 'Katholische Thoelogie, -Religionslehre', 'ED', 'H', 'H', '26', '086', 9999, 8, 'Ph', ''),
('Russistik', 'Russistik', 'Russistik', 'DF', 'N', 'N', '02', '642', 9999, 9, 'Ph', ''),
('Islamwisse', 'Islamwissenschaft', 'Islamwissenschaft', 'CD', 'N', 'HHN', '02', '083', 9999, 9, 'Ph', ''),
('Ernährungs', 'Ernährungswissenschaft', 'Ernährungswissenschaft', 'HA', 'H', 'H', '11', '320', 2000, 9, 'Ag', ''),
('Biochemie', 'Biochemie', 'Biochemie', 'FA', 'H', 'H', '11', '025', 2005, 10, 'BC', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '11', '050', 1996, 9, 'Ge', ''),
('Geologie/P', 'Geologie/Paläontologie', 'Geologie/Paläontologie', 'HB', 'H', 'H', '11', '302', 1997, 9, 'Ge', ''),
('Business S', 'Business Studies', 'Betriebswirtschaftslehre Business Studies', 'BB', 'H', 'H', '82', '821', 9999, 6, 'Wi', ''),
('Economics', 'Economics', 'Economics (International)', 'BB', 'H', 'H', '82', '875', 9999, 6, 'Wi', ''),
('Physik', 'Physik', 'Physik', 'GB', 'H', 'H', '11', '128', 9999, 10, 'Ch', ''),
('Med. Phys', 'Medizinische Physik', 'Medizinische Physik', 'GB', 'H', 'H', '11', '684', 9999, 10, 'Ch', ''),
('Arabistik', 'Arabistik', 'Arabistik', 'CD', 'N', 'HHN', '02', '010', 9999, 9, 'Ph', ''),
('MatheMA120', 'MathematikMA120', 'Mathematik', 'HD', 'H', '', '88', '705', 106, 4, 'Ma', ''),
('WirMaMA120', 'WirtschaftsmatheMA120', 'Wirtschaftsmathematik', 'HD', 'H', '', '88', '778', 106, 4, 'Ma', ''),
('InforMA120', 'InformatikMA120', 'Informatik', 'HC', 'H', '', '88', '779', 106, 4, 'Ma', ''),
('ChemMA120', 'ChemieMA120', 'Chemie', 'GA', 'H', 'H', '88', '732', 106, 4, 'Ch', ''),
('GeowiMA120', 'Angew. Geowissensch.MA120', 'Angewandte Geowissenschaften (Applied Geosciences)', 'HB', 'H', 'H', '88', '739', 106, 3, 'Ge', ''),
('WirreMA120', 'WirtschaftsrechtMA60', 'Wirtschaftsrecht', 'BA', 'H', 'H', '88', '742', 106, 2, 'Ju', ''),
('DenkmMA120', 'DenkmalpflegeMA120', 'Denkmalpflege', 'CC', 'H', 'H', '88', '703', 106, 4, 'Ph', ''),
('AAAMA75', 'Angew.Amerik./Angli.MA75', 'Angewandte Amerikanistik und Anglistik (AAA)', 'DA', 'S', '', '89', '306', 107, 4, 'Ph', ''),
('ASQ-Ber.', 'ASQ90/120/180', 'Alle Bachelor (90/120/180)', 'QD', '', '', '82', '000', 0, 0, '', ''),
('IKFD120', 'IKEASFraDeu120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Deutschland', 'DE', 'S', '', '83', '2F1', 107, 6, 'Ph', ''),
('IKFG120', 'IKEASFraGro120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Großbritannien', 'DE', 'S', '', '83', '2F2', 107, 6, 'Ph', ''),
('IKFI120', 'IKEASFraIta120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Italien', 'DE', 'S', '', '83', '2F3', 107, 6, 'Ph', ''),
('MM&AMA120', 'MultiMedia & AutorMA120', 'MultiMedia & Autorschaft', 'DC', 'H', 'H', '88', '727', 107, 4, 'Ph', ''),
('Angl/Am60', 'Anglistik/Amerikan.60', 'Anglistik und Amerikanistik', 'DA', 'N', '', '83', '506', 107, 6, 'Ph', ''),
('Angl/Am90', 'Anglistik/Amerikan.90', 'Anglistik und Amerikanistik', 'DA', 'K', '', '83', '906', 107, 6, 'Ph', ''),
('Angl/Am120', 'Anglistik/Amerikan.120', 'Anglistik und Amerikanistik', 'DA', 'S', '', '83', '206', 107, 6, 'Ph', ''),
('ArchäoEU60', 'Archäologien EU60', 'Archäologien Europas', 'CC', 'N', '', '83', '513', 107, 6, 'Ph', ''),
('Biolog180', 'Biologie180', 'Biologie', 'FB', 'H', '', '82', '826', 107, 6, 'Bi', ''),
('Bioch180', 'Biochemie180', 'Biochemie', 'FA', 'H', '', '82', '825', 107, 6, 'BC', ''),
('Bio-Inf180', 'Bioinformatik180', 'Bioinformatik', 'HC', 'H', '', '82', '885', 107, 6, 'Ma', ''),
('BioInMA120', 'BioinformatikMA120', 'Bioinformatik', 'HC', 'H', '', '88', '785', 107, 4, 'Ma', ''),
('BusEcon180', 'BusinessEconomics180', 'Business Econimics', 'BB', 'H', '', '82', '822', 107, 6, 'Wi', ''),
('DSprLit60', 'Deut.SpracheLiteratur60', 'Deutsche Sprache und Literatur', 'DB', 'N', '', '83', '567', 107, 6, 'Ph', ''),
('DLiKuMA45', 'Deut.LiteraturKulturMA45', 'Deutsche Literatur und Kultur', 'DB', 'N', '', '89', '467', 107, 4, 'Ph', ''),
('DLiKuMA75', 'Deut.LiteraturKulturMA75', 'Deutsche Literatur und Kultur', 'DB', 'S', '', '89', '367', 107, 4, 'Ph', ''),
('Ernähr180', 'Ernährungswissenschaft180', 'Ernährungswissenschaften', 'HA', 'H', '', '82', '819', 107, 6, 'Ag', ''),
('Erziehu180', 'Erziehungswissenschaft180', 'Erziehungswissenschaft', 'EA', 'H', '', '82', '854', 107, 6, 'Pä', ''),
('Erziehu90', 'Erziehungswissenschaft90', 'Erziehungswissenschaft', 'EA', 'K', '', '83', '954', 107, 6, 'Pä', ''),
('EvTheol60', 'EvangelischeTheologie60', 'Evangelische Theologie', 'A', 'N', '', '83', '555', 107, 6, 'Th', ''),
('EvTheol90', 'EvangelischeTheologie90', 'Evangelische Theologie', 'A', 'K', '', '83', '955', 107, 6, 'Th', ''),
('EvTheol120', 'EvangelischeTheologie120', 'Evangelische Theologie', 'A', 'S', '', '83', '255', 107, 6, 'Th', ''),
('DaFMA45', 'Deut.alsFremdspr.MA45', 'Deutsch als Fremdsprache (DaF)', 'DB', 'N', '', '89', '469', 107, 4, 'Ph', ''),
('DaFMA75', 'Deut.alsFremdspr.MA75', 'Deutsch als Fremdsprache (DaF)', 'DB', 'S', '', '89', '369', 107, 4, 'Ph', ''),
('Romanis120', 'Romanistik120', 'Romanistik (zwei Sprachdomänen)', 'DE', 'S', '', '83', '237', 107, 6, 'Ph', ''),
('Romanis180', 'Romanistik180', 'Romanistik (drei Sprachdomänen)', 'DE', 'H', '', '82', '837', 107, 6, 'Ph', ''),
('Frankoro90', 'Frankoromanistik90', 'Frankoromanistik', 'DE', 'K', '', '83', '937', 107, 6, 'Ph', ''),
('Hispani90', 'Hispanistik90', 'Hispanistik', 'DE', 'K', '', '83', '915', 107, 6, 'Ph', ''),
('Italiani60', 'Italianistik60', 'Italianistik', 'DE', 'N', '', '83', '511', 107, 6, 'Ph', ''),
('Italiani90', 'Italianistik90', 'Italianistik', 'DE', 'K', '', '83', '911', 107, 6, 'Ph', ''),
('Gesang180', 'Gesang u.Gesangsspäd180', 'Gesang und Gesangspädagogik', 'DD', 'H', '', '82', '880', 107, 6, 'Ph', ''),
('GesanMA120', 'Gesang u.GesangsspädMA180', 'Gesang und Gesangspädagogik', 'DD', 'H', '', '88', '780', 107, 4, 'Ph', ''),
('GeschMA120', 'GeschichteMA120', 'Geschichte', 'CB', 'H', '', '88', '768', 107, 6, 'Ph', ''),
('JapanoMA45', 'JapanologieMA45', 'Japanologie', 'CE', 'N', '', '89', '485', 107, 4, 'Ph', ''),
('JapanoMA75', 'JapanologieMA75', 'Japanologie', 'CE', 'S', '', '89', '385', 107, 4, 'Ph', ''),
('Klavier180', 'Klavier u.Klavierpäd180', 'Klavier und Klavierpädagogik', 'DD', 'H', '', '82', '881', 107, 6, 'Ph', ''),
('KlaviMA120', 'Klavier u.KlavierpädMA120', 'Klavier und Klavierpädagogik', 'DD', 'H', '', '88', '781', 107, 4, 'Ph', ''),
('LifeSMA120', 'LifeScienceMA120', 'Life Science', 'FB', 'H', '', '88', '736', 107, 6, 'Bi', ''),
('Nahost120', 'Nahoststudien120', 'Nahoststudien', 'CD', 'S', '', '83', '210', 107, 6, 'Ph', ''),
('PflGe180', 'Pflege-u.Gesundheits180', 'Pflege- und Gesundheitswissenschaften', 'IA', 'H', '', '82', '887', 107, 8, 'Me', ''),
('PflGeMA120', 'Pflege-u.GesundheitsMA120', 'Pflege- und Gesundheitswissenschaften', 'IA', 'H', '', '88', '787', 107, 4, 'Me', ''),
('PolitMA120', 'PolitikwissenschaftMA120', 'Politikwissenschaft: Parlamentsfragen und Zivilgesellschaft', 'CE', 'H', '', '88', '733', 107, 6, 'Ph', ''),
('Polonis60', 'Polonistik60', 'Polonistik', 'DF', 'N', '', '83', '518', 107, 0, 'Ph', ''),
('Russist60', 'Russistik60', 'Russistik', 'DF', 'N', '', '83', '542', 107, 6, 'Ph', ''),
('Russist90', 'Russistik90', 'Russistik', 'DF', 'K', '', '83', '942', 107, 6, 'Ph', ''),
('SlavSpr120', 'SlavischeSprLitKult120', 'Slavische Sprachen, Literaturen und Kulturen (zwei Slavinen)', 'DF', 'S', '', '83', '247', 107, 6, 'Ph', ''),
('Südslav60', 'Südslavistik60', 'Südslavistik', 'DF', 'N', '', '83', '547', 107, 6, 'Ph', ''),
('IKFL120', 'IKEASFraLat120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Lateinamerika', 'DE', 'S', '', '83', '2F4', 107, 6, 'Ph', ''),
('IKFP120', 'IKEASFraPol120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Polen', 'DE', 'S', '', '83', '2F5', 107, 6, 'Ph', ''),
('IKFR120', 'IKEASFraRus120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Russland', 'DE', 'S', '', '83', '2F6', 107, 6, 'Ph', ''),
('IKFS120', 'IKEASFraSüd120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Südostasien', 'DE', 'S', '', '83', '2F7', 107, 6, 'Ph', ''),
('IKFU120', 'IKEASFraUSA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / USA', 'DE', 'S', '', '83', '2F8', 107, 6, 'Ph', ''),
('IKGD120', 'IKEASGroDeu120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Deutschland', 'DA', 'S', '', '83', '2G1', 107, 6, 'Ph', ''),
('IKGF120', 'IKEASGroFra120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Frankreich', 'DA', 'S', '', '83', '2G2', 107, 6, 'Ph', ''),
('IKGI120', 'IKEASGroIta120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Italien', 'DA', 'S', '', '83', '2G3', 107, 6, 'Ph', ''),
('IKGL120', 'IKEASGroLat120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Lateinamerika', 'DA', 'S', '', '83', '2G4', 107, 6, 'Ph', ''),
('IKGP120', 'IKEASGroPol120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Polen', 'DA', 'S', '', '83', '2G5', 107, 6, 'Ph', ''),
('IKGR120', 'IKEASGroRus120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Russland', 'DA', 'S', '', '83', '2G6', 107, 6, 'Ph', ''),
('IKGS120', 'IKEASGroSüd120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Südostasien', 'DA', 'S', '', '83', '2G7', 107, 6, 'Ph', ''),
('IKRD120', 'IKEASRusDeu120', 'Interkulturelle Europa- und Amerikastudien Russland / Deutschland', 'DF', 'S', '', '83', '2R1', 107, 6, 'Ph', ''),
('IKRF120', 'IKEASRusFra120', 'Interkulturelle Europa- und Amerikastudien Russland / Frankreich', 'DF', 'S', '', '83', '2R2', 107, 6, 'Ph', ''),
('IKRG120', 'IKEASRusGro120', 'Interkulturelle Europa- und Amerikastudien Russland / Großbritannien', 'DF', 'S', '', '83', '2R3', 107, 6, 'Ph', ''),
('IKRI120', 'IKEASRusIta120', 'Interkulturelle Europa- und Amerikastudien Russland / Italien', 'DF', 'S', '', '83', '2R4', 107, 6, 'Ph', ''),
('IKRL120', 'IKEASRusLat120', 'Interkulturelle Europa- und Amerikastudien Russland / Lateinamerika', 'DF', 'S', '', '83', '2R5', 107, 6, 'Ph', ''),
('IKRP120', 'IKEASRusPol120', 'Interkulturelle Europa- und Amerikastudien Russland / Polen', 'DF', 'S', '', '83', '2R6', 107, 6, 'Ph', ''),
('IKRS120', 'IKEASRusSüd120', 'Interkulturelle Europa- und Amerikastudien Russland / Südostasien', 'DF', 'S', '', '83', '2R7', 107, 6, 'Ph', ''),
('IKRU120', 'IKEASRusUSA120', 'Interkulturelle Europa- und Amerikastudien Russland / USA', 'DF', 'S', '', '83', '2R8', 107, 6, 'Ph', ''),
('IKUD120', 'IKEASUSADeu120', 'Interkulturelle Europa- und Amerikastudien USA / Deutschland', 'DA', 'S', '', '83', '2U1', 107, 6, 'Ph', ''),
('IKUF120', 'IKEASUSAFra120', 'Interkulturelle Europa- und Amerikastudien USA / Frankreich', 'DA', 'S', '', '83', '2U2', 107, 6, 'Ph', ''),
('IKUI120', 'IKEASUSAIta120', 'Interkulturelle Europa- und Amerikastudien USA / Italien', 'DA', 'S', '', '83', '2U3', 107, 6, 'Ph', ''),
('IKUL120', 'IKEASUSALat120', 'Interkulturelle Europa- und Amerikastudien USA / Lateinamerika', 'DA', 'S', '', '83', '2U4', 107, 6, 'Ph', ''),
('IKUP120', 'IKEASUSAPol120', 'Interkulturelle Europa- und Amerikastudien USA / Polen', 'DA', 'S', '', '83', '2U5', 107, 6, 'Ph', ''),
('IKUR120', 'IKEASUSARus120', 'Interkulturelle Europa- und Amerikastudien USA / Russland', 'DA', 'S', '', '83', '2U6', 107, 6, 'Ph', ''),
('IKUS120', 'IKEASUSASüd120', 'Interkulturelle Europa- und Amerikastudien USA / Südostasien', 'DA', 'S', '', '83', '2U7', 107, 6, 'Ph', ''),
('IKFDMA120', 'IKEASFraDeuMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Deutschland', 'DE', 'H', '', '88', '7F1', 107, 4, 'Ph', ''),
('IKFGMA120', 'IKEASFraGroMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Großbritannien', 'DE', 'H', '', '88', '7F2', 107, 4, 'Ph', ''),
('IKFIMA120', 'IKEASFraItaMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Italien', 'DE', 'H', '', '88', '7F3', 107, 4, 'Ph', ''),
('IKFLMA120', 'IKEASFraLatMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Lateinamerika', 'DE', 'H', '', '88', '7F4', 107, 4, 'Ph', ''),
('IKFPMA120', 'IKEASFraPolMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Polen', 'DE', 'H', '', '88', '7F5', 107, 4, 'Ph', ''),
('IKFRMA120', 'IKEASFraRusMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Russland', 'DE', 'H', '', '88', '7F6', 107, 4, 'Ph', ''),
('IKFSMA120', 'IKEASFraSüdMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Südostasien', 'DE', 'H', '', '88', '7F7', 107, 4, 'Ph', ''),
('IKFUMA120', 'IKEASFraUSAMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / USA', 'DE', 'H', '', '88', '7F8', 107, 4, 'Ph', ''),
('IKGDMA120', 'IKEASGroDeuMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Deutschland', 'DA', 'H', '', '88', '7G1', 107, 4, 'Ph', ''),
('IKGFMA120', 'IKEASGroFraMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Frankreich', 'DA', 'H', '', '88', '7G2', 107, 4, 'Ph', ''),
('IKGIMA120', 'IKEASGroItaMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Italien', 'DA', 'H', '', '88', '7G3', 107, 4, 'Ph', ''),
('IKGLMA120', 'IKEASGroLatMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Lateinamerika', 'DA', 'H', '', '88', '7G4', 107, 4, 'Ph', ''),
('IKGPMA120', 'IKEASGroPolMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Polen', 'DA', 'H', '', '88', '7G5', 107, 4, 'Ph', ''),
('IKGRMA120', 'IKEASGroRusMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Russland', 'DA', 'H', '', '88', '7G6', 107, 4, 'Ph', ''),
('IKGSMA120', 'IKEASGroSüdMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Südostasien', 'DA', 'H', '', '88', '7G7', 107, 4, 'Ph', ''),
('IKRDMA120', 'IKEASRusDeuMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Deutschland', 'DF', 'H', '', '88', '7R1', 107, 4, 'Ph', ''),
('IKRFMA120', 'IKEASRusFraMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Frankreich', 'DF', 'H', '', '88', '7R2', 107, 4, 'Ph', ''),
('IKRGMA120', 'IKEASRusGroMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Großbritannien', 'DF', 'H', '', '88', '7R3', 107, 4, 'Ph', ''),
('IKRIMA120', 'IKEASRusItaMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Italien', 'DF', 'H', '', '88', '7R4', 107, 4, 'Ph', ''),
('IKRLMA120', 'IKEASRusLatMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Lateinamerika', 'DF', 'H', '', '88', '7R5', 107, 4, 'Ph', ''),
('IKRPMA120', 'IKEASRusPolMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Polen', 'DF', 'H', '', '88', '7R6', 107, 4, 'Ph', ''),
('IKRSMA120', 'IKEASRusSüdMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Südostasien', 'DF', 'H', '', '88', '7R7', 107, 4, 'Ph', ''),
('IKRUMA120', 'IKEASRusUSAMA120', 'Interkulturelle Europa- und Amerikastudien Russland / USA', 'DF', 'H', '', '88', '7R8', 107, 4, 'Ph', ''),
('IKUDMA120', 'IKEASUSADeuMA120', 'Interkulturelle Europa- und Amerikastudien USA / Deutschland', 'DA', 'H', '', '88', '7U1', 107, 4, 'Ph', ''),
('IKUFMA120', 'IKEASUSAFraMA120', 'Interkulturelle Europa- und Amerikastudien USA / Frankreich', 'DA', 'H', '', '88', '7U2', 107, 4, 'Ph', ''),
('IKUIMA120', 'IKEASUSAItaMA120', 'Interkulturelle Europa- und Amerikastudien USA / Italien', 'DA', 'H', '', '88', '7U3', 107, 4, 'Ph', ''),
('IKULMA120', 'IKEASUSALatMA120', 'Interkulturelle Europa- und Amerikastudien USA / Lateinamerika', 'DA', 'H', '', '88', '7U4', 107, 4, 'Ph', ''),
('IKUPMA120', 'IKEASUSAPolMA120', 'Interkulturelle Europa- und Amerikastudien USA / Polen', 'DA', 'H', '', '88', '7U5', 107, 4, 'Ph', ''),
('IKURMA120', 'IKEASUSARusMA120', 'Interkulturelle Europa- und Amerikastudien USA / Russland', 'DA', 'H', '', '88', '7U6', 107, 4, 'Ph', ''),
('IKUSMA120', 'IKEASUSASüdMA120', 'Interkulturelle Europa- und Amerikastudien USA / Südostasien', 'DA', 'H', '', '88', '7U7', 107, 4, 'Ph', ''),
('IntFMMA120', 'Int.FinanzmanagementMA120', 'Internationales Finanzmanagement (International Financial Management)', 'BB', 'H', '', '88', '728', 107, 4, 'Wi', ''),
('EmpÖkMA120', 'Empir.Ökonom/PoliberMA120', 'Empirische Ökonomik und Politikberatung', 'BB', 'H', '', '88', '775', 107, 4, 'Wi', ''),
('Agrarwisse', 'Agrarwissenschaft', 'Agrarwissenschaft', 'HA', 'H', 'H', '11', '003', 9999, 9, 'Ag', ''),
('Agrarwisse', 'Agrarwissenschaft', 'Agrarwissenschaft', 'HA', 'H', 'H', '88', '003', 9999, 4, 'Ag', ''),
('Englisch', 'Englisch', 'Englisch', 'DA', 'H', 'H', '26', '008', 9999, 9, 'Ph', ''),
('Englisch', 'Englisch', 'Englisch', 'DA', 'H', 'H', '24', '008', 9999, 8, 'Ph', ''),
('Englisch', 'Englisch', 'Englisch', 'DA', 'H', 'H', '25', '008', 9999, 9, 'Ph', ''),
('Arabistik', 'Arabistik', 'Arabistik', 'CD', 'H', 'HHN', '02', '010', 9999, 9, 'Ph', ''),
('Astronomie', 'Astronomie', 'Astronomie', 'GB', 'H', 'H', '25', '014', 9999, 2, 'Ch', ''),
('Astronomie', 'Astronomie', 'Astronomie', 'GB', 'H', 'HHN', '24', '014', 9999, 2, 'Ch', ''),
('MuK60', 'Medien-u.Kommunikation60', 'Medien- und Kommunikationswissenschaft', 'DC', 'N', '', '83', '533', 106, 6, 'Ph', ''),
('Biochemie', 'Biochemie', 'Biochemie', 'FA', 'H', 'H', '11', '025', 9999, 10, 'BC', ''),
('Biologie', 'Biologie', 'Biologie', 'FB', 'H', 'H', '02', '026', 9999, 9, 'Bi', ''),
('Biologie', 'Biologie', 'Biologie', 'FB', 'H', 'H', '11', '026', 9999, 10, 'Bi', ''),
('Biologie', 'Biologie', 'Biologie', 'FB', 'H', 'H', '24', '026', 9999, 8, 'Bi', ''),
('Biologie', 'Biologie', 'Biologie', 'FB', 'H', 'H', '25', '026', 9999, 9, 'Bi', ''),
('Biologie', 'Biologie', 'Biologie', 'FB', 'H', 'H', '26', '026', 9999, 9, 'Bi', ''),
('Sportwisse', 'Sportwissenschaft', 'Sportwissenschaft', 'DC', 'H', 'HHN', '02', '029', 9999, 9, 'Ph', ''),
('Sportwisse', 'Sportwissenschaft', 'Sportwissenschaft', 'DC', 'H', 'H', '11', '029', 9999, 8, 'Ph', ''),
('Chemie', 'Chemie', 'Chemie', 'GA', 'H', 'H', '11', '032', 2000, 10, 'Ch', ''),
('Chemie', 'Chemie', 'Chemie', 'GA', 'H', 'H', '24', '032', 9999, 8, 'Ch', ''),
('Chemie', 'Chemie', 'Chemie', 'GA', 'H', 'H', '25', '032', 9999, 9, 'Ch', ''),
('Chemie', 'Chemie', 'Chemie', 'GA', 'H', 'H', '26', '032', 9999, 9, 'Ch', ''),
('Chemie', 'Chemistry', 'Chemistry', 'GA', 'H', 'H', '82', '032', 2000, 6, 'Ch', ''),
('Elektrotec', 'Elektrotechnik/Elektronik', 'Elektrotechnik/ Elektronik', '78', 'H', 'H', '11', '048', 9999, 10, '', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '24', '050', 9999, 8, 'Ge', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '25', '050', 9999, 9, 'Ge', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '26', '050', 9999, 9, 'Ge', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '11', '050', 9999, 9, 'Ge', ''),
('Geographie', 'Geographie', 'Geographie', 'HB', 'H', 'H', '02', '050', 9999, 9, 'Ge', ''),
('Erziehungs', 'Erziehungswissenschaft', 'Erziehungswissenschaft(Pädagogik)', 'EA', 'H', 'HHN', '02', '052', 9999, 9, 'Pä', ''),
('Erziehungs', 'Erziehungswissenschaft', 'Erziehungswissenschaft(Pädagogik)', 'EA', 'H', 'H', '11', '052', 9999, 10, 'Pä', ''),
('Ev.Theolog', 'Ev. Theologie', 'Evangelische Theologie', 'A', 'H', 'HHN', '02', '053', 9999, 9, 'Th', ''),
('Ev.Theolog', 'Ev. Theologie', 'Evangelische Theologie', 'A', 'H', 'H', '04', '053', 9999, 11, 'Th', ''),
('Ev.Theolog', 'Ev. Theologie', 'Evangelische Theologie', 'A', 'H', 'H', '11', '053', 9999, 11, 'Th', ''),
('Französisc', 'Französisch', 'Französisch', 'DE', 'H', 'H', '24', '059', 9999, 8, 'Ph', ''),
('Französisc', 'Französisch', 'Französisch', 'DE', 'H', 'H', '25', '059', 9999, 9, 'Ph', ''),
('Französisc', 'Französisch', 'Französisch', 'DE', 'H', 'H', '26', '059', 9999, 9, 'Ph', ''),
('Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB', 'H', 'H', '11', '175', 2003, 9, 'Wi', ''),
('Deutsch', 'Deutsch', 'Deutsch', 'DB', 'H', 'H', '24', '067', 9999, 8, 'Ph', ''),
('Deutsch', 'Deutsch', 'Deutsch', 'DB', 'H', 'H', '25', '067', 9999, 9, 'Ph', ''),
('Deutsch (F', 'Deutsch', 'Deutsch', 'DB', 'H', 'H', '40', '067', 9999, 2, 'Ph', ''),
('Deutsch (H', 'Deutsch (Hpt.+Realsch.)', 'Deutsch', 'DB', 'H', 'H', '26', '067', 9999, 9, 'Ph', ''),
('Geschichte', 'Geschichte', 'Geschichte', 'CB', 'H', 'HHN', '02', '068', 9999, 9, 'Ph', ''),
('Geschichte', 'Geschichte', 'Geschichte', 'CB', 'H', 'H', '24', '068', 9999, 8, 'Ph', ''),
('Geschichte', 'Geschichte', 'Geschichte', 'CB', 'H', 'H', '25', '068', 9999, 9, 'Ph', ''),
('Geschichte', 'Geschichte', 'Geschichte', 'CB', 'H', 'H', '26', '068', 9999, 9, 'Ph', ''),
('Griechisch', 'Griechisch', 'Griechisch', 'CA', 'H', 'H', '25', '070', 9999, 9, 'Ph', ''),
('Griechisch', 'Griechisch', 'Griechisch', 'CA', 'H', 'H', '02', '070', 9999, 9, 'Ph', ''),
('Jüdisch.St', 'Jüdische Studien', 'Jüdische Studien', 'CD', 'H', 'HHN', '02', '073', 9999, 9, 'Ph', ''),
('Indologie', 'Indologie', 'Indologie', 'CA', 'H', 'HHN', '02', '078', 9999, 9, 'Ph', ''),
('Informatik', 'Informatik', 'Informatik', 'HC', 'H', 'H', '11', '079', 9999, 9, 'Ma', ''),
('Informatik', 'Informatik', 'Informatik', 'HC', 'H', 'H', '26', '079', 9999, 4, 'Ma', ''),
('Informatik', 'Informatik', 'Informatik', 'HC', 'H', 'H', '24', '079', 9999, 4, 'Ma', ''),
('Informatik', 'Informatik', 'Informatik', 'HC', 'H', 'H', '25', '079', 9999, 4, 'Ma', ''),
('Islamwisse', 'Islamwissenschaft', 'Islamwissenschaft', 'CD', 'H', 'HHN', '02', '083', 9999, 9, 'Ph', ''),
('Italienisc', 'Italienisch', 'Italienisch', 'DE', 'H', 'H', '25', '084', 9999, 9, 'Ph', ''),
('Japanologi', 'Japanologie', 'Japanologie', 'CE', 'H', 'HHN', '02', '085', 9999, 9, 'Ph', ''),
('Körperbeh.', 'Körperbehindertenpädagog.', 'Körperbehindertenpädagogik', '61', 'H', 'H', '26', '087', 9999, 9, 'Pä', ''),
('Kunstgesch', 'Kunstgeschichte', 'Kunstgeschichte', 'CC', 'H', 'HHN', '02', '092', 9999, 9, 'Ph', ''),
('Kunstgesch', 'Kunstgeschichte', 'Kunstgeschichte', 'CC', 'H', 'H', '11', '092', 9999, 10, 'Ph', ''),
('Latein', 'Latein', 'Latein', 'CA', 'H', 'H', '02', '095', 9999, 9, 'Ph', ''),
('Lebensm.-C', 'Lebensmittelchemie', 'Lebensmittelchemie', 'GA', 'H', 'H', '11', '096', 9999, 9, 'Ch', ''),
('Sport', 'Sport', 'Sport', 'DC', 'H', 'H', '02', '098', 9999, 9, 'Ph', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `his_pvers`
--

DROP TABLE IF EXISTS `his_pvers`;
CREATE TABLE `his_pvers` (
  `pvers` smallint(6) NOT NULL DEFAULT '0',
  `aikz` char(1) COLLATE latin1_general_ci DEFAULT NULL,
  `ktxt` char(10) COLLATE latin1_general_ci DEFAULT NULL,
  `dtxt` char(25) COLLATE latin1_general_ci DEFAULT NULL,
  `ltxt` char(50) COLLATE latin1_general_ci DEFAULT NULL,
  `sprache` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `refpvers` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`pvers`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `his_pvers`
--

INSERT INTO `his_pvers` (`pvers`, `aikz`, `ktxt`, `dtxt`, `ltxt`, `sprache`, `refpvers`) VALUES
(107, 'A', '107', '1. Version 2007', '1. Version 2007', 'D', 107),
(9999, 'A', 'k.Pversion', 'keine Pversion', 'keine PO-Version', 'D', 9999),
(0, 'A', 'PP', 'PP Version 0', 'PP Version 0', 'D', 0),
(2000, 'A', '2000', 'Version 2000', 'Version 2000', 'D', 2000),
(2001, 'A', '2001', 'Version 2001', 'Version 2001', 'D', 2001),
(2002, 'A', '2002', 'Version 2002', 'Version 2002', 'D', 2002),
(2003, 'A', '2003', 'Version 2003', 'Version 2003', 'D', 2003),
(1998, 'A', '1998', 'Version 1998', 'Version 1998', 'D', 1998),
(1997, 'A', '1997', 'Version 1997', 'Version 1997', 'D', 1997),
(1995, 'A', '1995', 'Version 1995', 'Version 1995', 'D', 1995),
(2004, 'A', '2004', 'Version 2004', 'Version 2004', 'D', 2004),
(1996, 'A', '1996', 'Version 1996', 'Version 1996', 'D', 1996),
(2005, 'A', '2005', 'Version 2005', 'Version 2005', 'D', 2005),
(1111, 'A', '1111', 'Jura-alt', 'Jura-alt', 'D', 1111),
(106, 'A', '106', '1. Version 2006', '1. Version 2006', 'D', 106),
(-1, 'A', 'Pool', 'Pool', 'Pool', 'D', -1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `his_stg`
--

DROP TABLE IF EXISTS `his_stg`;
CREATE TABLE `his_stg` (
  `stg` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ktxt` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `dtxt` varchar(25) COLLATE latin1_general_ci DEFAULT NULL,
  `ltxt` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `fb` char(2) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`stg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Studienfaecher aus der HIS DB';

--
-- Daten für Tabelle `his_stg`
--

INSERT INTO `his_stg` (`stg`, `ktxt`, `dtxt`, `ltxt`, `fb`) VALUES
('003', 'Agrarwisse', 'Agrarwissenschaft', 'Agrarwissenschaft', 'HA'),
('008', 'Englisch', 'Englisch', 'Englisch', 'DA'),
('010', 'Arabistik', 'Arabistik', 'Arabistik', 'CD'),
('014', 'Astronomie', 'Astronomie', 'Astronomie', 'GB'),
('021', 'BWL', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', 'BB'),
('025', 'Biochemie', 'Biochemie', 'Biochemie', 'FA'),
('026', 'Biologie', 'Biologie', 'Biologie', 'FB'),
('029', 'Sportwisse', 'Sportwissenschaft', 'Sportwissenschaft', 'DC'),
('032', 'Chemie', 'Chemie', 'Chemie', 'GA'),
('048', 'Elektrotec', 'Elektrotechnik/Elektronik', 'Elektrotechnik/ Elektronik', '78'),
('050', 'Geographie', 'Geographie', 'Geographie', 'HB'),
('052', 'Erziehungs', 'Erziehungswissenschaft', 'Erziehungswissenschaft(Pädagogik)', 'EA'),
('053', 'Ev.Theolog', 'Theologie', 'Evangelische Theologie', 'A'),
('059', 'Französisc', 'Französisch', 'Französisch', 'DE'),
('063', 'Geistigbeh', 'Geistigbehindertenpädagog', 'Geistigbehindertenpädagogik', 'EB'),
('067', 'Deutsch', 'Deutsch', 'Deutsch', 'DB'),
('068', 'Geschichte', 'Geschichte', 'Geschichte', 'CB'),
('070', 'Griechisch', 'Griechisch', 'Griechisch', 'CA'),
('073', 'Jüdisch.St', 'Jüdische Studien', 'Jüdische Studien', 'CD'),
('078', 'Indologie', 'Indologie', 'Indologie', 'CA'),
('079', 'Informatik', 'Informatik', 'Informatik', 'HC'),
('083', 'Islamwisse', 'Islamwissenschaft', 'Islamwissenschaft', 'CD'),
('084', 'Italienisc', 'Italienisch', 'Italienisch', 'DE'),
('085', 'Japanologi', 'Japanologie', 'Japanologie', 'CE'),
('087', 'Körperbeh.', 'Körperbehindertenpädagog.', 'Körperbehindertenpädagogik', '61'),
('092', 'Kunstgesch', 'Kunstgeschichte', 'Kunstgeschichte', 'CC'),
('095', 'Latein', 'Latein', 'Latein', 'CA'),
('096', 'Lebensm.-C', 'Lebensmittelchemie', 'Lebensmittelchemie', 'GA'),
('098', 'Sport (HRS', 'Sport (Hpt.+Realsch.)', 'Sport', 'DC'),
('099', 'Lernbeh.pä', 'Lernbehindertenpädagogik', 'Lernbehindertenpädagogik', 'EB'),
('104', 'Maschinenb', 'Maschinenbau/ -wesen', 'Maschinenbau / -wesen', '78'),
('105', 'Mathematik', 'Mathematik', 'Mathematik', 'HD'),
('107', 'Medizin', 'Medizin', 'Medizin', 'IA'),
('111', 'Mineralogi', 'Mineralogie', 'Mineralogie', 'HB'),
('113', 'Musik', 'Musik', 'Musik', 'DD'),
('114', 'Musikwiss.', 'Musikwissenschaft', 'Musikwissenschaft', 'DD'),
('115', 'Grundsch.l', 'Grundschullehrer', 'Grundschullehrer', 'EC'),
('118', 'Technomath', 'Technomathematik', 'Technomathematik', 'HD'),
('123', 'Ingwiss.In', 'Ing.wiss./Vert.Ing.Inform', 'Ingenieurwiss.,Vertiefung Ingenieurinformatik', 'HE'),
('126', 'Pharmazie', 'Pharmazie', 'Pharmazie', 'FC'),
('127', 'Philosophi', 'Philosophie', 'Philosophie', 'CG'),
('128', 'Physik', 'Physik', 'Physik', 'GB'),
('130', 'Polnisch (', 'Fachübersetzen Polnisch', 'Fachübersetzen (Polnisch)', 'DC'),
('132', 'Psychologi', 'Psychologie', 'Psychologie', 'CF'),
('133', 'Medien-u.K', 'Medien-u.Kommunikationsw.', 'Medien- und Kommunikationswissenschaft', 'DC'),
('135', 'Rechtswiss', 'Rechtswissenschaft', 'Rechtswissenschaft', 'BA'),
('139', 'Russisch', 'Russisch', 'Russisch', 'DF'),
('146', 'Slavistik', 'Slavistik', 'Slavistik', 'DF'),
('147', 'Sozialkund', 'Sozialkunde', 'Sozialkunde', 'CE'),
('149', 'Soziologie', 'Soziologie', 'Soziologie', 'CH'),
('150', 'Spanisch', 'Spanisch', 'Spanisch', 'DE'),
('151', 'Sprachbeh.', 'Sprachbehindertenpädagog.', 'Sprachbehindertenpädagogik', 'EB'),
('152', 'Sprachwiss', 'Sprachwissenschaft', 'Sprachwissenschaft', 'CD'),
('153', 'Mazedonist', 'Mazedonistik', 'Mazedonistik', '64'),
('169', 'Ethik', 'Ethik', 'Ethik', 'CG'),
('170', 'Verh.gest.', 'Verhaltensgest.pädagogik', 'Verhaltensgestörtenpädagogik', 'EB'),
('175', 'Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', 'BB'),
('177', 'Werkstoffw', 'Werkstoffwissenschaft', 'Werkstoffwissenschaft', 'HE'),
('179', 'Wirt.ing.w', 'Wirtschaftsingenieurwesen', 'Wirtschaftsingenieurwesen', 'BB'),
('185', 'Zahnmedizi', 'Zahnmedizin', 'Zahnmedizin', 'IA'),
('190', 'Rehab.päda', 'Rehabilitationspädagogik', 'Rehabilitationspädagogik', 'EB'),
('196', 'Studienkol', 'Studienkolleg', 'Studienkolleg', 'QA'),
('202', 'Verarb.tec', 'Verarbeitungstechnik', 'Verarbeitungstechnik', '78'),
('226', 'Verfahrens', 'Verfahrenstechnik', 'Verfahrenstechnik', 'HE'),
('276', 'Wirtsch.Ma', 'Wirtschaftsmathematik', 'Wirtschaftsmathematik', 'HD'),
('277', 'Wirtsch.In', 'Wirtschaftsinformatik', 'Wirtschaftsinformatik', 'BB'),
('282', 'Bioingenie', 'Bio-Ingenieurwesen', 'Bio-Ingenieurwesen', 'HE'),
('300', 'Politikwis', 'Politikwissenschaft', 'Politikwissenschaft', 'CE'),
('302', 'Geologie/P', 'Geologie/Paläontologie', 'Geologie/Paläontologie', 'HB'),
('320', 'Ernährungs', 'Ernährungswissenschaft', 'Ernährungswissenschaft', 'HA'),
('457', 'Umwelttech', 'Umwelttechnik', 'Umwelttechnik', 'HE'),
('548', 'Präh.Archä', 'Prähistor.Archäologie', 'Prähistorische Archäologie', 'CC'),
('603', 'Germ.Sprac', 'Germanist.Sprachwissensch', 'Germanistische Sprachwissenschaft', 'DB'),
('604', 'Germ.Liter', 'Germanist.Literaturwiss.', 'Germanistische Literaturwissenschaft', 'DB'),
('605', 'Sprechwiss', 'Sprechwissenschaft', 'Sprechwissenschaft', 'DF'),
('606', 'Wirtsch/Te', 'Wirtschaft/Technik', 'Wirtschaft und Technik', 'HE'),
('609', 'Semitistik', 'Semitistik', 'Semitistik', 'CD'),
('610', 'Italianist', 'Italianistik', 'Italianistik', 'DE'),
('612', 'Anglistik', 'Anglistik', 'Anglistik', 'DA'),
('613', 'Angl./Amer', 'Anglistik/Amerikanistik', 'Anglistik/Amerikanistik', 'DA'),
('614', 'Galloroman', 'Galloromanistik', 'Galloromanistik', 'DE'),
('615', 'Hispanisti', 'Hispanistik', 'Hispanistik', 'DE'),
('618', 'Polonistik', 'Polonistik', 'Polonistik', '64'),
('619', 'Klass.Arch', 'Klassische Archäologie', 'Klassische Archäologie', 'CA'),
('620', 'Mittellat.', 'Mittellatein.Philologie', 'Mittellateinische Philologie', 'CA'),
('621', 'Or.Arch.u.', 'Oriental.Archäol.u.Kunst', 'Orientalische Archäologie und Kunst', 'CA'),
('623', 'Sp/Lit Chr', 'Spr./Lit.d.Christl.Orient', 'Sprachen und Literaturen des Christlichen Orients', 'CD'),
('624', 'Kunstgesch', 'Kunstgeschichte Byz.', 'Kunstgeschichte Byzantinistik', '63'),
('629', 'Osteurop.G', 'Osteuropäische Geschichte', 'Osteuropäische Geschichte', 'CB'),
('630', 'Mitt.u.Neu', 'Mittl.u.Neue Geschichte', 'Geschichte, Mittlere und Neuere', '62'),
('631', 'Neueste Ge', 'Neueste Geschichte', 'Neueste Geschichte', '62'),
('632', 'Sozialgesc', 'Sozialgeschichte', 'Sozialgeschichte', '62'),
('633', 'Landesgesc', 'Landesgeschichte', 'Landesgeschichte', 'CB'),
('634', 'Hist.Hilfs', 'Hist. Hilfswissensch.', 'Historische Hilfswissenschaften', 'CB'),
('636', 'Mediz.Päda', 'Medizinpädagogik', 'Medizinpädagogik', 'IA'),
('638', 'Phonetik', 'Phonetik', 'Phonetik', '65'),
('641', 'Therapiesp', 'Therapiesport', 'Therapiesport', '65'),
('642', 'Russistik', 'Russistik', 'Russistik', 'DF'),
('643', 'Ev.Religio', 'Evangelische Religion', 'Evangelische Religionslehre', 'A'),
('644', 'Latein.Phi', 'Lateinische Philologie', 'Lateinische Philologie', 'CA'),
('645', 'Griech.Phi', 'Griechische Philologie', 'Griechische Philologie', 'CA'),
('646', 'Russisch (', 'Fachübersetzen Russisch', 'Fachübersetzen (Russisch)', '64'),
('647', 'Englisch (', 'Fachübersetzen Englisch', 'Fachübersetzen (Englisch)', 'DC'),
('648', 'Französisc', 'Fachübersetzen Französ.', 'Fachübersetzen (Französisch)', '64'),
('649', 'Deutsch/Fr', 'Deutsch als Fremdsprache', 'Deutsch als Fremdsprache', '64'),
('651', 'Alte Gesch', 'Alte Geschichte', 'Alte Geschichte', 'CB'),
('652', 'Angl/Amer.', 'Anglistik/Amerikan.(Lit.)', 'Angl./Amerik. - Englische u. Amerikan. Literatur', '64'),
('653', 'Angl/Amer.', 'Anglistik/Amerikan.(Spr.)', 'Angl./Amerikanistik-Englische Sprachwissenschaft', '64'),
('654', 'Hauswirtsc', 'Hauswirtschaft', 'Hauswirtschaft', 'EA'),
('655', 'Musik-Th.u', 'Theorie u.Prax.der Musik', 'Theorie und Praxis der Musik', '65'),
('656', 'Polnisch', 'Polnisch', 'Polnisch', '64'),
('657', 'Sozialkund', 'Sozialkunde/DIF', 'Sozialkunde', '62'),
('660', 'Schulgarte', 'Schulgarten', 'Schulgarten', 'EC'),
('661', 'Werken', 'Werken', 'Werkunterricht', 'EC'),
('662', 'Heimat-/Sa', 'Heimatkunde/Sachkunde', 'Heimatkunde/Sachkunde', 'EC'),
('663', 'Kunsterz.(', 'Kunsterziehung (Grundsch)', 'Kunsterziehung (Grundschule)', 'EC'),
('664', 'Sport(Grun', 'Sport (Grundsch)', 'Sport (Grundschule)', 'EC'),
('665', 'Musik(Grun', 'Musik (Grundsch)', 'Musik (Grundsch)', 'EC'),
('666', 'Ethik(Grun', 'Ethik (Grundsch)', 'Ethik (Grundsch)', 'EC'),
('667', 'Ev.Relig.(', 'Evangel.Relig.(Grundsch.)', 'Evangelische Religionslehre (Grundschule)', 'EC'),
('668', 'Deutsch (G', 'Deutsch (Grundschule)', 'Deutsch (Grundschule)', 'EC'),
('669', 'Mathematik', 'Mathematik (Grundschule)', 'Mathematik (Grundschule)', 'EC'),
('670', 'Betriebsw.', 'Betriebswirtschaftslehre', 'Betriebswirtschaftslehre', '30'),
('671', 'Volkswirt.', 'Volkswirtschaftslehre', 'Volkswirtschaftslehre', '30'),
('672', 'Wirtsch.In', 'Wirtschaftsinformatik', 'Wirtschaftsinformatik', '30'),
('673', 'Deutsch (F', 'Deutsch (Förderstufe)', 'Deutsch', '64'),
('674', 'Mathematik', 'Mathematik (Förderstufe)', 'Mathematik', '75'),
('675', 'Klavier', 'Klavier', 'Klavier', 'DD'),
('676', 'Pflegewiss', 'Pflegewissenschaft', 'Pflegewissenschaft/-management', 'IA'),
('677', 'Materialwi', 'Materialwissenschaft', 'Materialwissenschaft', '78'),
('678', 'Legum magi', 'Legum magister', 'legum magister', '20'),
('679', 'Musikerz.(', 'Musikerzieher Hf:Gesang', 'Musikerzieher - Hauptfach: Gesang', 'DD'),
('680', 'Wirtsch.re', 'Wirtschaftsrecht', 'Wirtschaftsrecht', '20'),
('681', 'Didakt.d.G', 'Didaktik der Geschichte', 'Didaktik der Geschichte', 'CB'),
('682', 'Wrt.u.Soz.', 'Wirtsch.u.Sozialgesch.', 'Wirtschafts- und Sozialgeschichte', 'CB'),
('683', 'Zeitgeschi', 'Zeitgeschichte', 'Zeitgeschichte', 'CB'),
('684', 'Medizin.Ph', 'Medizinische Physik', 'Medizinische Physik', 'GB'),
('685', 'Bio-Inform', 'Bioinformatik', 'Bioinformatik', 'HC'),
('686', 'Biomed.Mat', 'Biomedizin.Materialien', 'Biomedizinische Materialien', 'FC'),
('687', 'Pfl./Gesun', 'Pflege-u.Gesundheitswiss.', 'Pflege- und Gesundheitswissenschaft', 'IA'),
('688', 'Werkstf.te', 'Werkstofftechnologie', 'Werkstofftechnologie', '78'),
('689', 'Alt-German', 'Altgermanistik', 'Altgermanistik', 'DB'),
('690', 'Sp/Kult.n.', 'Spr./Kult.d.neuz.Südasien', 'Sprachen und Kulturen des neuzeitlichen Südasien', 'CD'),
('691', 'Sport(Br+W', 'Sportw.(Breiten u.Wettk.)', 'Sportwissensch. Schw: Breiten- und Wettkampfsport', '65'),
('692', 'Sport(Ther', 'Sportw.(Präv/Reha/Therap)', 'Sportwiss. (Prävention,Rehabilitation,Therapie)', 'DC'),
('777', 'Seniorenko', 'Seniorenkolleg', 'Seniorenkolleg', 'QB'),
('693', 'Int.Wissen', 'Interkult.Wissenskommunik', 'Interkulturelle Wissenskommunikation', 'DC'),
('694', 'Biomed.Eng', 'Biomedical Engineering', 'Biomedical Engineering', 'IA'),
('695', 'Appl.Polym', 'Applied Polymer Science', 'Master of Applied Polymer Science', 'GA'),
('696', 'Europa/Ame', 'Interk.Europa/Amerikastud', 'Interkulturelle Europa- und Amerikastudien', 'DA'),
('697', 'Musikpädag', 'Musikpädagogik', 'Musikpädagogik', 'DD'),
('698', 'ChrArch/By', 'Chr.Arch./Byz.Kunstgesch.', 'Christl. Archäologie u. Byzantin. Kunstgeschichte', 'CC'),
('101', 'Denkmalpfl', 'Heritage management', 'Master of Science in Heritage management', 'CC'),
('173', 'Ethnologie', 'Ethnologie', 'Ethnologie', 'CG'),
('699', 'Integratio', 'Integrationspädagogik', 'Integrationspädagogik', '61'),
('361', 'Schulpädag', 'Schulleit./', 'Schule leiten und gestalten', '61'),
('617', 'Amerikanis', 'Amerikanistik', 'Amerikanistik', 'DA'),
('042', 'Wirtsch.re', 'Wirtschaftsrecht', 'Wirtschaftsrecht', 'BA'),
('086', 'Kathol.Rel', 'Kathol. Theol, -Religio', 'Katholische Thoelogie, -Religionslehre', 'ED'),
('700', 'Autor./Mul', 'Autorschaft & Multimedia', 'Autorschaft und Multimedia', '64'),
('701', 'Chem.u.Umw', 'Chemie-u.Umweltingenieurw', 'Chemie- und Umweltingenieurwesen', 'HE'),
('137', 'Romanistik', 'Romanistik', 'Romanistik', '64'),
('602', 'Betr.Wirt.', 'Betriebswirschaft d.Landw', 'Betriebswirtschaftslehre der Landwirtschaft', '30'),
('616', 'Lusitanist', 'Lusitanistik', 'Lusitanistik', 'DC'),
('637', 'Klass.Phil', 'Klassische Philologie', 'Klassische Philologie', '63'),
('122', 'Orientalis', 'Orientalistik', 'Orientalistik', 'CD'),
('702', 'Kath.Relig', 'Kathol.Religion(Grundsch)', 'Katholische Religionslehre (Grundschule)', 'EC'),
('821', 'Busines180', 'Business Studies(Int.)180', 'Business Studies (International)', 'BB'),
('875', 'Economi180', 'Economics(Int.)180', 'Economics (International)', 'BB'),
('199', 'Technik (S', 'Technik an Sekundarschul.', 'Technik an Sekundarschulen', '78'),
('711', 'Ik.EAs./US', 'Interk.Eur.Am.st./USA', 'Interkult. Europa- und Amerikastudien / USA', 'DA'),
('712', 'Ik.EAs./Gr', 'Interk.Eur.Am.st./Gr.Brit', 'Interkult. Europa- und Amerikastudien / Gr.Brit.', 'DA'),
('713', 'Ik.EAs./Fr', 'Interk.Eur.Am.st./Frankr.', 'Interkult. Europa- und Amerikastudien / Frankr.', 'DE'),
('714', 'Ik.EAs./Ru', 'Interk.Eur.Am.st./Russl.', 'Interkult. Europa- und Amerikastudien / Russland', 'DF'),
('715', 'Ik.EAs./La', 'Interk.Eur.Am.st./Lat.Am.', 'Interkult. Europa- und Amerikastudien / Lat.Amer.', 'DE'),
('716', 'Ik.EAs./It', 'Interk.Eur.Am.st./Italien', 'Interkult. Europa- und Amerikastudien / Italien', 'DE'),
('717', 'Ik.EAs./Po', 'Interk.Eur.Am.st./Polen', 'Interkult. Europa- und Amerikastudien / Polen', 'DF'),
('718', 'Ik.EAs./SO', 'Interk.Eur.Am.st./SO-Eur.', 'Interkult. Europa- und Amerikastudien / SO-Europa', 'DF'),
('719', 'Ik.EAs./D-', 'Interk.Eur.Am.st./D-Land', 'Interkult. Europa- und Amerikastudien / Deutschl.', 'DB'),
('154', 'Staatsbürg', 'Staatsbürgerkunde', 'Staatsbürgerkunde', '62'),
('775', 'Empir.Ökon', 'Empir.Ökonom/Polit.berat.', 'Empirische Ökonomik und Politikberatung', 'BB'),
('039', 'Geowiss', 'Angew. Geowissenschaften', 'Angewandte Geowissenschaften', 'HB'),
('121', 'Multim/VRI', 'Multimedia/Virtual R.Inf.', 'Multimedia/Virtulal Reality-Informatik', 'HC'),
('722', 'Stkoll W', 'W-Kurs', 'W-Kurs', 'QA'),
('723', 'Stkoll T', 'T-Kurs', 'T-Kurs', 'QA'),
('724', 'Stkoll S/G', 'S/G-Kurs', 'S/G-Kurs', 'QA'),
('725', 'Stkoll M', 'M-Kurs', 'M-Kurs', 'QA'),
('726', 'Stkoll DSH', 'DSH-Kurs', 'DSH-Kurs', 'QA'),
('720', 'Qu/Bi/Sozi', 'Quali./Bildg./Sozialf.', 'Qualitative Bildungs- und Sozialforschung', '61'),
('721', 'M./Eth./R.', 'Medizin-Ethik-Recht', 'Medizin-Ethik-Recht', 'BA'),
('727', 'MM&A', 'MultiMedia & Autor', 'MultiMedia & Autorschaft', 'DC'),
('728', 'Int.Fi.Man', 'Inter.Finanzmanagement', 'Internationales Finanzmanagement', 'BB'),
('000', 'ASQ-Ber.', 'ASQ90/120/180', 'Alle Bachelor (90/120/180)', 'QD'),
('027', 'Sehbeh.Päd', 'Blind/Sehbehindertenpäd.', 'Blinden-/Sehbehindertenpädagogik', '61'),
('062', 'GehörlPäd', 'Gehörl/Schwerhö/Pädagogik', 'Gehörlosen-/Schwerhörigenpädagogik', 'EB'),
('093', 'MNRessourc', 'Management nat Ressourcen', 'Management natürlicher Ressourcen', 'HA'),
('193', 'KirMusik', 'Kirchenmusik', 'Kirchenmusik', '65'),
('200', 'Politik120', 'Politikwissenschaft120', 'Politikwissenschaft', 'CE'),
('206', 'Angl/Am120', 'Anglistik/Amerikan.120', 'Anglistik und Amerikanistik', 'DA'),
('210', 'Nahost120', 'Nahoststudien120', 'Nahoststudien', 'CD'),
('214', 'Musikw.120', 'Musikwissenschaft120', 'Musikwissenschaft', 'DD'),
('224', 'KlasAlt120', 'Klassisches Altertum120', 'Klassisches Altertum', 'CA'),
('233', 'MuK120', 'Medien-u.Kommunikation120', 'Medien- und Kommunikationswissenschaft', 'DC'),
('237', 'Romanis120', 'Romanistik120', 'Romanistik (zwei Sprachdomänen)', 'DE'),
('247', 'SlavSpr120', 'SlavischeSprLitKult120', 'Slavische Sprachen, Literaturen und Kulturen (zwei Slavinen)', 'DF'),
('249', 'Soziolo120', 'Soziologie120', 'Soziologie', 'CH'),
('250', 'Geogra120', 'Geographie120', 'Geographie', 'HB'),
('255', 'EvTheol120', 'EvangelischeTheologie120', 'Evangelische Theologie', 'A'),
('268', 'Gesch120', 'Geschichte120', 'Geschichte', 'CB'),
('272', 'WirInfo120', 'Wirtschaftsinformatik120', 'Kernfach Wirtschaftsinformatik  (Core Subject Business Information Systems)', 'BB'),
('284', 'WirtWis120', 'Wirtschaftswiss120', 'Wirtschaftswissenschaften (Economics and Management)', 'BB'),
('292', 'Kunstge120', 'Kunstgeschichte120', 'Kunstgeschichte', 'CC'),
('298', 'Sportwi120', 'Sportwissenschaft120', 'Sportwissenschaft', 'DC'),
('2F1', 'IKFD120', 'IKEASFraDeu120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Deutschland', 'DE'),
('2F2', 'IKFG120', 'IKEASFraGro120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Großbritannien', 'DE'),
('2F3', 'IKFI120', 'IKEASFraIta120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Italien', 'DE'),
('2F4', 'IKFL120', 'IKEASFraLat120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Lateinamerika', 'DE'),
('2F5', 'IKFP120', 'IKEASFraPol120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Polen', 'DE'),
('2F6', 'IKFR120', 'IKEASFraRus120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Russland', 'DE'),
('2F7', 'IKFS120', 'IKEASFraSüd120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Südostasien', 'DE'),
('2F8', 'IKFU120', 'IKEASFraUSA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / USA', 'DE'),
('2G1', 'IKGD120', 'IKEASGroDeu120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Deutschland', 'DA'),
('2G2', 'IKGF120', 'IKEASGroFra120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Frankreich', 'DA'),
('2G3', 'IKGI120', 'IKEASGroIta120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Italien', 'DA'),
('2G4', 'IKGL120', 'IKEASGroLat120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Lateinamerika', 'DA'),
('2G5', 'IKGP120', 'IKEASGroPol120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Polen', 'DA'),
('2G6', 'IKGR120', 'IKEASGroRus120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Russland', 'DA'),
('2G7', 'IKGS120', 'IKEASGroSüd120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Südostasien', 'DA'),
('2R1', 'IKRD120', 'IKEASRusDeu120', 'Interkulturelle Europa- und Amerikastudien Russland / Deutschland', 'DF'),
('2R2', 'IKRF120', 'IKEASRusFra120', 'Interkulturelle Europa- und Amerikastudien Russland / Frankreich', 'DF'),
('2R3', 'IKRG120', 'IKEASRusGro120', 'Interkulturelle Europa- und Amerikastudien Russland / Großbritannien', 'DF'),
('2R4', 'IKRI120', 'IKEASRusIta120', 'Interkulturelle Europa- und Amerikastudien Russland / Italien', 'DF'),
('2R5', 'IKRL120', 'IKEASRusLat120', 'Interkulturelle Europa- und Amerikastudien Russland / Lateinamerika', 'DF'),
('2R6', 'IKRP120', 'IKEASRusPol120', 'Interkulturelle Europa- und Amerikastudien Russland / Polen', 'DF'),
('2R7', 'IKRS120', 'IKEASRusSüd120', 'Interkulturelle Europa- und Amerikastudien Russland / Südostasien', 'DF'),
('2R8', 'IKRU120', 'IKEASRusUSA120', 'Interkulturelle Europa- und Amerikastudien Russland / USA', 'DF'),
('2U1', 'IKUD120', 'IKEASUSADeu120', 'Interkulturelle Europa- und Amerikastudien USA / Deutschland', 'DA'),
('2U2', 'IKUF120', 'IKEASUSAFra120', 'Interkulturelle Europa- und Amerikastudien USA / Frankreich', 'DA'),
('2U3', 'IKUI120', 'IKEASUSAIta120', 'Interkulturelle Europa- und Amerikastudien USA / Italien', 'DA'),
('2U4', 'IKUL120', 'IKEASUSALat120', 'Interkulturelle Europa- und Amerikastudien USA / Lateinamerika', 'DA'),
('2U5', 'IKUP120', 'IKEASUSAPol120', 'Interkulturelle Europa- und Amerikastudien USA / Polen', 'DA'),
('2U6', 'IKUR120', 'IKEASUSARus120', 'Interkulturelle Europa- und Amerikastudien USA / Russland', 'DA'),
('2U7', 'IKUS120', 'IKEASUSASüd120', 'Interkulturelle Europa- und Amerikastudien USA / Südostasien', 'DA'),
('306', 'AAAMA75', 'Angew.Amerik./Angli.MA75', 'Angewandte Amerikanistik und Anglistik (AAA)', 'DA'),
('367', 'DLiKuMA75', 'Deut.LiteraturKulturMA75', 'Deutsche Literatur und Kultur', 'DB'),
('369', 'DaFMA75', 'Deut.alsFremdspr.MA75', 'Deutsch als Fremdsprache (DaF)', 'DB'),
('385', 'JapanoMA75', 'JapanologieMA75', 'Japanologie', 'CE'),
('406', 'AAAMA45', 'Angew.Amerik./Angli.MA45', 'Angewandte Amerikanistik und Anglistik (AAA)', 'DA'),
('467', 'DLiKuMA45', 'Deut.LiteraturKulturMA45', 'Deutsche Literatur und Kultur', 'DB'),
('469', 'DaFMA45', 'Deut.alsFremdspr.MA45', 'Deutsch als Fremdsprache (DaF)', 'DB'),
('485', 'JapanoMA45', 'JapanologieMA45', 'Japanologie', 'CE'),
('500', 'Politikw60', 'Politikwissenschaft60', 'Politikwissenschaft', 'CE'),
('506', 'Angl/Am60', 'Anglistik/Amerikan.60', 'Anglistik und Amerikanistik', 'DA'),
('510', 'Arabist60', 'Arabistik/Islamwiss.60', 'Arabistik/Islamwissenschaft', 'CD'),
('511', 'Italiani60', 'Italianistik60', 'Italianistik', 'DE'),
('512', 'ArchKu60', 'Archäol Kunst Orient60', 'Archäologie und Kunstgeschichte des vorislamischen Orients', 'CA'),
('513', 'ArchäoEU60', 'Archäologien EU60', 'Archäologien Europas', 'CC'),
('514', 'Musikw.60', 'Musikwissenschaft60', 'Musikwissenschaft', 'DD'),
('518', 'Polonis60', 'Polonistik60', 'Polonistik', 'DF'),
('522', 'WissChOr60', 'WissChristOrient60', 'Wissenschaft vom Christlichen Orient', 'CD'),
('527', 'Philo60', 'Philosophie60', 'Philosophie', 'CG'),
('531', 'Psycho60', 'Psychologie60', 'Psychologie', 'CF'),
('533', 'MuK60', 'Medien-u.Kommunikation60', 'Medien- und Kommunikationswissenschaft', 'DC'),
('536', 'IntSüdas60', 'InterkulturelleSüdasien60', 'Interkulturelle Südasienkunde', 'CD'),
('542', 'Russist60', 'Russistik60', 'Russistik', 'DF'),
('547', 'Südslav60', 'Südslavistik60', 'Südslavistik', 'DF'),
('549', 'Soziolo60', 'Soziologie60', 'Soziologie', 'CH'),
('550', 'Geogra60', 'Geographie60', 'Geographie', 'HB'),
('555', 'EvTheol60', 'EvangelischeTheologie60', 'Evangelische Theologie', 'A'),
('567', 'DSprLit60', 'Deut.SpracheLiteratur60', 'Deutsche Sprache und Literatur', 'DB'),
('568', 'Gesch60', 'Geschichte60', 'Geschichte', 'CB'),
('572', 'WirInfo60', 'Wirtschaftsinformatik60', 'Grundlagen Wirtschaftsinformatik (Fundamentals Business Information Systems)', 'BB'),
('573', 'Ethnolo60', 'Ethnologie60', 'Ethnologie', 'CG'),
('574', 'JüdiSt60', 'Judaistik/Jüdische Stud60', 'Judaistik/Jüdische Studien', 'CD'),
('584', 'WirtWiss60', 'Wirtschaftswiss60', 'Grundlagen Wirtschaftswissenschaften (Fundamental Economics and Management)', 'BB'),
('585', 'Japano60', 'Japanologie60', 'Japanologie', 'CE'),
('592', 'Kunstge60', 'Kunstgeschichte60', 'Kunstgeschichte', 'CC'),
('598', 'Sportwi60', 'Sportwissenschaft60', 'Sportwissenschaft', 'DC'),
('703', 'DenkmMA120', 'DenkmalpflegeMA120', 'Denkmalpflege', 'CC'),
('705', 'MatheMA120', 'MathematikMA120', 'Mathematik', 'HD'),
('729', 'HRManMA120', 'HumanRes.ManagementMA120', 'Human Resource Management', 'BB'),
('730', 'AcTaxMA120', 'Accounting&TaxationMA120', 'Accounting and Taxation', 'BB'),
('731', 'BWLMA120', 'BWL (Business Stud.)MA120', 'Betriebswirtschaftslehre (Business Studies)', 'BB'),
('732', 'ChemMA120', 'ChemieMA120', 'Chemie', 'GA'),
('733', 'PolitMA120', 'PolitikwissenschaftMA120', 'Politikwissenschaft: Parlamentsfragen und Zivilgesellschaft', 'CE'),
('736', 'LifeSMA120', 'LifeScienceMA120', 'Life Science', 'FB'),
('739', 'GeowiMA120', 'Angew. Geowissensch.MA120', 'Angewandte Geowissenschaften (Applied Geosciences)', 'HB'),
('742', 'WirreMA120', 'WirtschaftsrechtMA60', 'Wirtschaftsrecht', 'BA'),
('767', 'DSLitMA120', 'DeutSpracheLiteraturMA120', 'Deutsche Sprache und Literatur', 'DB'),
('768', 'GeschMA120', 'GeschichteMA120', 'Geschichte', 'CB'),
('776', 'VWLMA120', 'VWL (Economics)MA120', 'Volkswirtschaftslehre (Economics)', 'BB'),
('778', 'WirMaMA120', 'WirtschaftsmatheMA120', 'Wirtschaftsmathematik', 'HD'),
('779', 'InforMA120', 'InformatikMA120', 'Informatik', 'HC'),
('780', 'GesanMA120', 'Gesang u.GesangsspädMA180', 'Gesang und Gesangspädagogik', 'DD'),
('781', 'KlaviMA120', 'Klavier u.KlavierpädMA120', 'Klavier und Klavierpädagogik', 'DD'),
('785', 'BioInMA120', 'BioinformatikMA120', 'Bioinformatik', 'HC'),
('787', 'PflGeMA120', 'Pflege-u.GesundheitsMA120', 'Pflege- und Gesundheitswissenschaften', 'IA'),
('7F1', 'IKFDMA120', 'IKEASFraDeuMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Deutschland', 'DE'),
('7F2', 'IKFGMA120', 'IKEASFraGroMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Großbritannien', 'DE'),
('7F3', 'IKFIMA120', 'IKEASFraItaMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Italien', 'DE'),
('7F4', 'IKFLMA120', 'IKEASFraLatMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Lateinamerika', 'DE'),
('7F5', 'IKFPMA120', 'IKEASFraPolMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Polen', 'DE'),
('7F6', 'IKFRMA120', 'IKEASFraRusMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Russland', 'DE'),
('7F7', 'IKFSMA120', 'IKEASFraSüdMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / Südostasien', 'DE'),
('7F8', 'IKFUMA120', 'IKEASFraUSAMA120', 'Interkulturelle Europa- und Amerikastudien Frankreich / USA', 'DE'),
('7G1', 'IKGDMA120', 'IKEASGroDeuMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Deutschland', 'DA'),
('7G2', 'IKGFMA120', 'IKEASGroFraMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Frankreich', 'DA'),
('7G3', 'IKGIMA120', 'IKEASGroItaMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Italien', 'DA'),
('7G4', 'IKGLMA120', 'IKEASGroLatMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Lateinamerika', 'DA'),
('7G5', 'IKGPMA120', 'IKEASGroPolMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Polen', 'DA'),
('7G6', 'IKGRMA120', 'IKEASGroRusMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Russland', 'DA'),
('7G7', 'IKGSMA120', 'IKEASGroSüdMA120', 'Interkulturelle Europa- und Amerikastudien Großbritannien / Südostasien', 'DA'),
('7R1', 'IKRDMA120', 'IKEASRusDeuMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Deutschland', 'DF'),
('7R2', 'IKRFMA120', 'IKEASRusFraMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Frankreich', 'DF'),
('7R3', 'IKRGMA120', 'IKEASRusGroMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Großbritannien', 'DF'),
('7R4', 'IKRIMA120', 'IKEASRusItaMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Italien', 'DF'),
('7R5', 'IKRLMA120', 'IKEASRusLatMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Lateinamerika', 'DF'),
('7R6', 'IKRPMA120', 'IKEASRusPolMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Polen', 'DF'),
('7R7', 'IKRSMA120', 'IKEASRusSüdMA120', 'Interkulturelle Europa- und Amerikastudien Russland / Südostasien', 'DF'),
('7R8', 'IKRUMA120', 'IKEASRusUSAMA120', 'Interkulturelle Europa- und Amerikastudien Russland / USA', 'DF'),
('7U1', 'IKUDMA120', 'IKEASUSADeuMA120', 'Interkulturelle Europa- und Amerikastudien USA / Deutschland', 'DA'),
('7U2', 'IKUFMA120', 'IKEASUSAFraMA120', 'Interkulturelle Europa- und Amerikastudien USA / Frankreich', 'DA'),
('7U3', 'IKUIMA120', 'IKEASUSAItaMA120', 'Interkulturelle Europa- und Amerikastudien USA / Italien', 'DA'),
('7U4', 'IKULMA120', 'IKEASUSALatMA120', 'Interkulturelle Europa- und Amerikastudien USA / Lateinamerika', 'DA'),
('7U5', 'IKUPMA120', 'IKEASUSAPolMA120', 'Interkulturelle Europa- und Amerikastudien USA / Polen', 'DA'),
('7U6', 'IKURMA120', 'IKEASUSARusMA120', 'Interkulturelle Europa- und Amerikastudien USA / Russland', 'DA'),
('7U7', 'IKUSMA120', 'IKEASUSASüdMA120', 'Interkulturelle Europa- und Amerikastudien USA / Südostasien', 'DA'),
('800', 'PoliSoz180', 'Politikwiss.Soziologie180', 'Politikwissenschaft - Soziologie', 'CE'),
('803', 'Agrarw180', 'Agrarwissenschaft180', 'Agrarwissenschaft', 'HA'),
('805', 'Mathe180', 'Mathematik180', 'Mathematik mit Anwendungsfach', 'HD'),
('806', 'Sprechw180', 'Sprechwissenschaft180', 'Sprechwissenschaft', 'DF'),
('819', 'Ernähr180', 'Ernährungswissenschaft180', 'Ernährungswissenschaften', 'HA'),
('820', 'BWL180', 'BWL (Business Studies)180', 'Betriebswirtschaftslehre (Business Studies)', 'BB'),
('822', 'BusEcon180', 'BusinessEconomics180', 'Business Econimics', 'BB'),
('824', 'KlasAlt180', 'Klassisches Altertum180', 'Klassisches Altertum', 'CA'),
('825', 'Bioch180', 'Biochemie180', 'Biochemie', 'FA'),
('826', 'Biolog180', 'Biologie180', 'Biologie', 'FB'),
('828', 'Physik180', 'Physik180', 'Physik', 'GB'),
('831', 'Psycho180', 'Psychologie180', 'Psychologie', 'CF'),
('832', 'Chemie180', 'Chemie180', 'Chemie', 'GA'),
('837', 'Romanis180', 'Romanistik180', 'Romanistik (drei Sprachdomänen)', 'DE'),
('839', 'Geowiss180', 'Angew. Geowissen180', 'Angewandte Geowissenschaften (Applied Geosciences)', 'HB'),
('850', 'Geogra180', 'Geographie180', 'Geographie', 'HB'),
('854', 'Erziehu180', 'Erziehungswissenschaft180', 'Erziehungswissenschaft', 'EA'),
('872', 'WirInfo180', 'Wirtschaftsinformatik180', 'Wirtschaftsinformatik (Business Information Systems)', 'BB'),
('874', 'VWL180', 'VWL (Economics)180', 'Volkswirtschaftslehre (Economics)', 'BB'),
('876', 'WirtMat180', 'Wirtschaftsmathematik180', 'Wirtschaftsmathematik', 'HD'),
('879', 'Inform180', 'Informatik180', 'Informatik', 'HC'),
('880', 'Gesang180', 'Gesang u.Gesangsspäd180', 'Gesang und Gesangspädagogik', 'DD'),
('881', 'Klavier180', 'Klavier u.Klavierpäd180', 'Klavier und Klavierpädagogik', 'DD'),
('884', 'Med.Phy180', 'Medizinische Physik180', 'Medizinische Physik', 'GB'),
('885', 'Bio-Inf180', 'Bioinformatik180', 'Bioinformatik', 'HC'),
('887', 'PflGe180', 'Pflege-u.Gesundheits180', 'Pflege- und Gesundheitswissenschaften', 'IA'),
('893', 'MRessou180', 'Management nat.Ressour180', 'Management natürlicher Ressourcen', 'HA'),
('900', 'Politikw90', 'Politikwissenschaft90', 'Politikwissenschaft', 'CE'),
('906', 'Angl/Am90', 'Anglistik/Amerikan.90', 'Anglistik und Amerikanistik', 'DA'),
('910', 'Arabist90', 'Arabistik/Islamwiss.90', 'Arabistik/Islamwissenschaft', 'CD'),
('911', 'Italiani90', 'Italianistik90', 'Italianistik', 'DE'),
('912', 'ArchKu90', 'Archäol Kunst Orient90', 'Archäologie und Kunstgeschichte des vorislamischen Orients', 'CA'),
('913', 'ArchäoEU90', 'Archäologien EU90', 'Archäologien Europas', 'CC'),
('915', 'Hispani90', 'Hispanistik90', 'Hispanistik', 'DE'),
('922', 'WissChOr90', 'WissChristOrient90', 'Wissenschaft vom Christlichen Orient', 'CD'),
('923', 'KAAltGes90', 'K.Altertum/AlteGeschich90', 'Klassisches Altertum/Alte Geschichte', 'CA'),
('924', 'KAArcGes90', 'K.Altertum/Archäologie90', 'Klassisches Altertum/Klassische Archäologie', 'CA'),
('925', 'KAGräzis90', 'K.Altertum/Gräzistik90', 'Klassisches Altertum/Gräzistik', 'CA'),
('926', 'KALatini90', 'K.Altertum/Latinistik90', 'Klassisches Altertum/Latinistik', 'CA'),
('927', 'Philo90', 'Philosophie90', 'Philosophie', 'CG'),
('933', 'MuK90', 'Medien-u.Kommunikation90', 'Medien- und Kommunikationswissenschaft', 'DC'),
('936', 'SAKunde90', 'Südasienkunde90', 'Südasienkunde (South Asian Studies)', 'CD'),
('937', 'Frankoro90', 'Frankoromanistik90', 'Frankoromanistik', 'DE'),
('940', 'RelOrien90', 'Religionsges d.Orients90', 'Religionsgeschichte des Orients', 'CD'),
('942', 'Russist90', 'Russistik90', 'Russistik', 'DF'),
('949', 'Soziolo90', 'Soziologie90', 'Soziologie', 'CH'),
('952', 'BLIK90', 'Beruforient.Linguistik90', 'Berufsorientierte Linguistik im interkulturellen Kontext (BLIK)', 'CD'),
('953', 'AlteWelt90', 'Alte Welt90', 'Alte Welt', 'CD'),
('954', 'Erziehu90', 'Erziehungswissenschaft90', 'Erziehungswissenschaft', 'EA'),
('955', 'EvTheol90', 'EvangelischeTheologie90', 'Evangelische Theologie', 'A'),
('967', 'DSprLit90', 'Deut.SpracheLiteratur90', 'Deutsche Sprache und Literatur', 'DB'),
('968', 'Gesch90', 'Geschichte90', 'Geschichte', 'CB'),
('973', 'Ethnolo90', 'Ethnologie90', 'Ethnologie', 'CG'),
('974', 'JüdiSt90', 'Judaistik/Jüdische Stud90', 'Judaistik/Jüdische Studien', 'CD'),
('978', 'Indolog90', 'Indologie90', 'Indologie (Kultur- und Geistesgeschichte des Vormodernen Indien)', 'CA'),
('985', 'Japano90', 'Japanologie90', 'Japanologie', 'CE'),
('992', 'Kunstge90', 'Kunstgeschichte90', 'Kunstgeschichte', 'CC'),
('995', 'LateinEU90', 'Latein Europas90', 'Latein Europas', 'CA'),
('998', 'Sportwi90', 'Sportwissenschaft90', 'Sportwissenschaft', 'DC');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Institute`
--

DROP TABLE IF EXISTS `Institute`;
CREATE TABLE `Institute` (
  `Institut_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `fakultaets_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Strasse` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Plz` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `url` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'http://www.studip.de',
  `telefon` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `fax` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `modules` int(10) unsigned DEFAULT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `lit_plugin_name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `srienabled` tinyint(4) NOT NULL DEFAULT '0',
  `lock_rule` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`Institut_id`),
  KEY `fakultaets_id` (`fakultaets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `Institute`
--

INSERT INTO `Institute` (`Institut_id`, `Name`, `fakultaets_id`, `Strasse`, `Plz`, `url`, `telefon`, `email`, `fax`, `type`, `modules`, `mkdate`, `chdate`, `lit_plugin_name`, `srienabled`, `lock_rule`) VALUES
('1535795b0d6ddecac6813f5f6ac47ef2', 'Test Fakultät', '1535795b0d6ddecac6813f5f6ac47ef2', 'Geismar Landstr. 17b', '37083 Göttingen', 'http://www.studip.de', '0551 / 381 985 0', 'testfakultaet@studip.de', '0551 / 381 985 3', 1, 16, 1156516698, 1156516698, 'Studip', 0, ''),
('2560f7c7674942a7dce8eeb238e15d93', 'Test Einrichtung', '1535795b0d6ddecac6813f5f6ac47ef2', '', '', '', '', '', '', 1, 16, 1156516698, 1156516698, 'Studip', 0, ''),
('536249daa596905f433e1f73578019db', 'Test Lehrstuhl', '1535795b0d6ddecac6813f5f6ac47ef2', '', '', '', '', '', '', 3, 16, 1156516698, 1156516698, 'Studip', 0, ''),
('f02e2b17bc0e99fc885da6ac4c2532dc', 'Test Abteilung', '1535795b0d6ddecac6813f5f6ac47ef2', '', '', '', '', '', '', 4, 16, 1156516698, 1156516698, 'Studip', 0, ''),
('ec2e364b28357106c0f8c282733dbe56', 'externe Bildungseinrichtungen', 'ec2e364b28357106c0f8c282733dbe56', '', '', '', '', '', '', 1, 16, 1156516698, 1156516698, 'Studip', 0, ''),
('7a4f19a0a2c321ab2b8f7b798881af7c', 'externe Einrichtung A', 'ec2e364b28357106c0f8c282733dbe56', '', '', '', '', '', '', 1, 16, 1156516698, 1156516698, 'Studip', 0, ''),
('110ce78ffefaf1e5f167cd7019b728bf', 'externe Einrichtung B', 'ec2e364b28357106c0f8c282733dbe56', '', '', '', '', '', '', 1, 16, 1156516698, 1156516698, 'Studip', 0, '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kategorien`
--

DROP TABLE IF EXISTS `kategorien`;
CREATE TABLE `kategorien` (
  `kategorie_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `content` text COLLATE latin1_general_ci NOT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`kategorie_id`),
  KEY `priority` (`priority`),
  KEY `range_id` (`range_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `kategorien`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lit_catalog`
--

DROP TABLE IF EXISTS `lit_catalog`;
CREATE TABLE `lit_catalog` (
  `catalog_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(11) NOT NULL DEFAULT '0',
  `chdate` int(11) NOT NULL DEFAULT '0',
  `lit_plugin` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'Studip',
  `accession_number` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_title` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dc_creator` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `dc_subject` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_description` text COLLATE latin1_general_ci,
  `dc_publisher` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_contributor` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_date` date DEFAULT NULL,
  `dc_type` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_format` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_identifier` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_source` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_language` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_relation` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_coverage` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `dc_rights` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`catalog_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `lit_catalog`
--

INSERT INTO `lit_catalog` (`catalog_id`, `user_id`, `mkdate`, `chdate`, `lit_plugin`, `accession_number`, `dc_title`, `dc_creator`, `dc_subject`, `dc_description`, `dc_publisher`, `dc_contributor`, `dc_date`, `dc_type`, `dc_format`, `dc_identifier`, `dc_source`, `dc_language`, `dc_relation`, `dc_coverage`, `dc_rights`) VALUES
('54181f281faa777941acc252aebaf26d', 'studip', 1156516698, 1156516698, 'Gvk', '387042768', 'Quickguide Strahlenschutz : [Aufgaben, Organisation, Schutzmaßnahmen].', 'Wolf, Heike', '', '', 'Kissing : WEKA Media', '', '2004-01-01', '', '74 S : Ill.', '', '', 'ger', '[Der Strahlenschutzbeauftragte in Medizin und Technik / Heike Wolf] Praxislösungen', '', ''),
('d6623a3c2b8285fb472aa759150148ad', 'studip', 1156516698, 1156516698, 'Gvk', '387042253', 'Röntgenverordnung : (RÖV) ; Verordnung über den Schutz vor Schäden durch Röntgenstrahlen.', 'Wolf, Heike', '', '', 'Kissing : WEKA Media', '', '2004-01-01', '', '50 S.', '', '', 'ger', '[Der Strahlenschutzbeauftragte in Medizin und Technik / Heike Wolf] Praxislösungen', '', ''),
('15074ad4f2bd2c57cbc9dfb343c1355b', 'studip', 1156516698, 1156516698, 'Gvk', '384065813', 'Der Kater mit Hut', 'Geisel, Theodor Seuss', '', '', 'München [u.a.] : Piper', '', '2004-01-01', '', '75 S : zahlr. Ill ; 19 cm.', 'ISBN: 349224078X (kart.)', '', 'ger', 'Serie Piper ;, 4078', '', ''),
('ce704bbc9453994daa05d76d2d04aba0', 'studip', 1156516698, 1156516698, 'Gvk', '379252104', 'Die volkswirtschaftliche Perspektive', 'Heise, Michael', '', '', 'In: Zeitschrift für das gesamte Kreditwesen, Vol. 57, No. 4 (2004), p. 211-217, Frankfurt, M. : Knapp', 'Kater, Ulrich;', '2004-01-01', '', 'graph. Darst.', '', '', 'ger', '', '', ''),
('b5d115a7f7cad02b4535fb3090bf18da', 'studip', 1156516698, 1156516698, 'Gvk', '386883831', 'E-Learning: Qualität und Nutzerakzeptanz sichern : Beiträge zur Planung, Umsetzung und Evaluation multimedialer und netzgestützter Anwendungen', 'Zinke, Gert', '', '', 'Bielefeld : Bertelsmann', 'Härtel, Michael; Bundesinstitut für Berufsbildung, ;', '2004-01-01', '', '159 S : graph. Darst ; 225 mm x 155 mm.', 'ISBN: 3763910204', '', 'ger', 'Berichte zur beruflichen Bildung ;, 265', '', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lit_list`
--

DROP TABLE IF EXISTS `lit_list`;
CREATE TABLE `lit_list` (
  `list_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `format` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(11) NOT NULL DEFAULT '0',
  `chdate` int(11) NOT NULL DEFAULT '0',
  `priority` smallint(6) NOT NULL DEFAULT '0',
  `visibility` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`list_id`),
  KEY `range_id` (`range_id`),
  KEY `priority` (`priority`),
  KEY `visibility` (`visibility`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `lit_list`
--

INSERT INTO `lit_list` (`list_id`, `range_id`, `name`, `format`, `user_id`, `mkdate`, `chdate`, `priority`, `visibility`) VALUES
('3332f270b96fb23cdd2463cef8220b29', '834499e2b8a2cd71637890e5de31cba3', 'Basisliteratur der Veranstaltung', '**{dc_creator}** |({dc_contributor})||\r\n{dc_title}||\r\n{dc_identifier}||\r\n%%{published}%%||\r\n{note}||\r\n[{lit_plugin}]{external_link}|\r\n', '76ed43ef286fb55cf9e41beadb484a9f', 1156516698, 1156516698, 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lit_list_content`
--

DROP TABLE IF EXISTS `lit_list_content`;
CREATE TABLE `lit_list_content` (
  `list_element_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `list_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `catalog_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(11) NOT NULL DEFAULT '0',
  `chdate` int(11) NOT NULL DEFAULT '0',
  `note` text COLLATE latin1_general_ci,
  `priority` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`list_element_id`),
  KEY `list_id` (`list_id`),
  KEY `catalog_id` (`catalog_id`),
  KEY `priority` (`priority`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `lit_list_content`
--

INSERT INTO `lit_list_content` (`list_element_id`, `list_id`, `catalog_id`, `user_id`, `mkdate`, `chdate`, `note`, `priority`) VALUES
('1e6d6e6f179986f8c2be5b1c2ed37631', '3332f270b96fb23cdd2463cef8220b29', '15074ad4f2bd2c57cbc9dfb343c1355b', '76ed43ef286fb55cf9e41beadb484a9f', 1156516698, 1156516698, '', 1),
('4bd3001d8260001914e9ab8716a4fe70', '3332f270b96fb23cdd2463cef8220b29', 'ce704bbc9453994daa05d76d2d04aba0', '76ed43ef286fb55cf9e41beadb484a9f', 1156516698, 1156516698, '', 2),
('ce226125c3cf579cf28e5c96a8dea7a9', '3332f270b96fb23cdd2463cef8220b29', '54181f281faa777941acc252aebaf26d', '76ed43ef286fb55cf9e41beadb484a9f', 1156516698, 1156516698, '', 3),
('1d4ff2d55489dd9284f6a83dfc69149e', '3332f270b96fb23cdd2463cef8220b29', 'd6623a3c2b8285fb472aa759150148ad', '76ed43ef286fb55cf9e41beadb484a9f', 1156516698, 1156516698, '', 4),
('293e90c3c6511d2c8e1d4ba7b51daa98', '3332f270b96fb23cdd2463cef8220b29', 'b5d115a7f7cad02b4535fb3090bf18da', '76ed43ef286fb55cf9e41beadb484a9f', 1156516698, 1156516698, '', 5);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `lock_rules`
--

DROP TABLE IF EXISTS `lock_rules`;
CREATE TABLE `lock_rules` (
  `lock_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `permission` enum('autor','tutor','dozent','admin','root') COLLATE latin1_general_ci NOT NULL DEFAULT 'dozent',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `attributes` text COLLATE latin1_general_ci NOT NULL,
  `object_type` enum('sem','inst','user') COLLATE latin1_general_ci NOT NULL DEFAULT 'sem',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`lock_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `lock_rules`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `log_actions`
--

DROP TABLE IF EXISTS `log_actions`;
CREATE TABLE `log_actions` (
  `action_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(128) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `info_template` text COLLATE latin1_general_ci,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `expires` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `log_actions`
--

INSERT INTO `log_actions` (`action_id`, `name`, `description`, `info_template`, `active`, `expires`) VALUES
('0ee290df95f0547caafa163c4d533991', 'SEM_VISIBLE', 'Veranstaltung sichtbar schalten', '%user schaltet %sem(%affected) sichtbar.', 1, 0),
('a94706b41493e32f8336194262418c01', 'SEM_INVISIBLE', 'Veranstaltung unsichtbar schalten', '%user versteckt %sem(%affected).', 1, 0),
('bd2103035a8021942390a78a431ba0c4', 'DUMMY', 'Dummy-Aktion', '%user tut etwas.', 1, 0),
('4490aa3d29644e716440fada68f54032', 'LOG_ERROR', 'Allgemeiner Log-Fehler', 'Allgemeiner Logging-Fehler, Details siehe Debug-Info.', 1, 0),
('f858b05c11f5faa2198a109a783087a8', 'SEM_CREATE', 'Veranstaltung anlegen', '%user legt %sem(%affected) an.', 1, 0),
('5b96f2fe994637253ba0fe4a94ad1b98', 'SEM_ARCHIVE', 'Veranstaltung archivieren', '%user archiviert %info (ID: %affected).', 1, 0),
('bf192518a9c3587129ed2fdb9ea56f73', 'SEM_DELETE_FROM_ARCHIVE', 'Veranstaltung aus Archiv löschen', '%user löscht %info aus dem Archiv (ID: %affected).', 1, 0),
('4869cd69f20d4d7ed4207e027d763a73', 'INST_USER_STATUS', 'Einrichtungsnutzerstatus ändern', '%user ändert Status für %user(%coaffected) in Einrichtung %inst(%affected): %info.', 1, 0),
('6be59dcd70197c59d7bf3bcd3fec616f', 'INST_USER_DEL', 'Benutzer aus Einrichtung löschen', '%user löscht %user(%coaffected) aus Einrichtung %inst(%affected).', 1, 0),
('cf8986a67e67ca273e15fd9230f6e872', 'USER_CHANGE_TITLE', 'Akademische Titel ändern', '%user ändert/setzt akademischen Titel für %user(%affected) - %info.', 1, 0),
('ca216ccdf753f59ba7fd621f7b22f7bd', 'USER_CHANGE_NAME', 'Personennamen ändern', '%user ändert/setzt Name für %user(%affected) - %info.', 1, 0),
('8aad296e52423452fc75cabaf2bee384', 'USER_CHANGE_USERNAME', 'Benutzernamen ändern', '%user ändert/setzt Benutzernamen für %user(%affected): %info.', 1, 0),
('0d87c25b624b16fb9b8cdaf9f4e96e53', 'INST_CREATE', 'Einrichtung anlegen', '%user legt Einrichtung %inst(%affected) an.', 1, 0),
('1a1e8c9c3125ea8d2c58c875a41226d6', 'INST_DEL', 'Einrichtung löschen', '%user löscht Einrichtung %info (%affected).', 1, 0),
('d18d750fb2c166e1c425976e8bca96e7', 'USER_CHANGE_EMAIL', 'E-Mail-Adresse ändern', '%user ändert/setzt E-Mail-Adresse für %user(%affected): %info.', 1, 0),
('a92afa63584cc2a62d2dd2996727b2c5', 'USER_CREATE', 'Nutzer anlegen', '%user legt Nutzer %user(%affected) an.', 1, 0),
('e406e407501c8418f752e977182cd782', 'USER_CHANGE_PERMS', 'Globalen Nutzerstatus ändern', '%user ändert/setzt globalen Status von %user(%affected): %info', 1, 0),
('63042706e5cd50924987b9515e1e6cae', 'INST_USER_ADD', 'Benutzer zu Einrichtung hinzufügen', '%user fügt %user(%coaffected) zu Einrichtung %inst(%affected) mit Status %info hinzu.', 1, 0),
('4dd6b4101f7bf3bd7fe8374042da95e9', 'USER_NEWPWD', 'Neues Passwort', '%user generiert neues Passwort für %user(%affected)', 1, 0),
('e8646729e5e04970954c8b9679af389b', 'USER_DEL', 'Benutzer löschen', '%user löscht %user(%affected) (%info)', 1, 0),
('2e816bfd792e4a99913f11c04ad49198', 'SEM_UNDELETE_SINGLEDATE', 'Einzeltermin wiederherstellen', '%user stellt Einzeltermin %singledate(%affected) in %sem(%coaffected) wieder her.', 1, 0),
('997cf01328d4d9f36b9f50ac9b6ace47', 'SEM_DELETE_SINGLEDATE', 'Einzeltermin löschen', '%user löscht Einzeltermin %singledate(%affected) in %sem(%coaffected).', 1, 0),
('b205bde204b5607e036c10557a6ce149', 'SEM_SET_STARTSEMESTER', 'Startsemester ändern', '%user hat in %sem(%affected) das Startsemester auf %semester(%coaffected) geändert.', 1, 0),
('9d13643a1833c061dc3d10b4fb227f12', 'SEM_SET_ENDSEMESTER', 'Semesterlaufzeit ändern', '%user hat in %sem(%affected) die Laufzeit auf %semester(%coaffected) geändert', 1, 0),
('5f8fda12a4c0bd6eadbb94861de83696', 'SEM_ADD_CYCLE', 'Regelmäßige Zeit hinzugefügt', '%user hat in %sem(%affected) die regelmäßige Zeit %info hinzugefügt.', 1, 0),
('6f4bb66c1caf89879d89f3b1921a93dd', 'SEM_DELETE_CYCLE', 'Regelmäßige Zeit gelöscht', '%user hat in %sem(%affected) die regelmäßige Zeit %info gelöscht.', 1, 0),
('3f7dcf6cc85d6fba1281d18c4d9aba6f', 'SEM_ADD_SINGLEDATE', 'Einzeltermin hinzufügen', '%user hat in %sem(%affected) den Einzeltermin <em>%coaffected</em> hinzugefügt', 1, 0),
('c36fa0f804cde78a6dcb1c30c2ee47ba', 'SEM_DELETE_REQUEST', 'Raumanfrage gelöscht', '%user hat in %sem(%affected) die Raumanfrage für die gesamte Veranstaltung gelöscht.', 1, 0),
('370db4eb0e38051dd3c5d7c52717215a', 'SEM_DELETE_SINGLEDATE_REQUEST', 'Einzeltermin, Raumanfrage gelöscht', '%user hat in %sem(%affected) die Raumanfrage für den Termin <em>%coaffected</em> gelöscht.', 1, 0),
('9d642dc93540580d42ba2ea502c3fbf6', 'SINGLEDATE_CHANGE_TIME', 'Einzeltermin bearbeiten', '%user hat in %sem(%affected) den Einzeltermin %coaffected geändert.', 1, 0),
('10c31be1aec819c03b0dc299d0111576', 'CHANGE_BASIC_DATA', 'Basisdaten geändert', '%user hat in Veranstaltung %sem(%affected) die Daten %info geändert.', 0, 0),
('fd74339a9ea038d084569e33e2655b6a', 'CHANGE_INSTITUTE_DATA', 'Institutdaten geändert', '%user hat in Veranstaltung %sem(%affected) die Daten %info geändert.', 0, 0),
('89114dcd6f02dd7f94488a616c21a7c3', 'PLUGIN_ENABLE', 'Plugin einschalten', '%user hat in Veranstaltung %sem(%affected) das Plugin %plugin(%coaffected) aktiviert.', 1, 0),
('a66c9e04e9c41bf5cc4d23fa509a8667', 'PLUGIN_DISABLE', 'Plugin ausschalten', '%user hat in Veranstaltung %sem(%affected) das Plugin %plugin(%coaffected) deaktiviert.', 1, 0),
('005df8d5eb23c66214b28b3c9792680b', 'SEM_CHANGED_ACCESS', 'Zugangsberechtigungen geändert', '%user ändert die Zugangsberechtigungen der Veranstaltung %sem(%affected).', 0, 0),
('535010528d6c012ec0e3535e2d754f66', 'SEM_USER_ADD', 'In Veranstaltung eingetragen', '%user hat %user(%coaffected) für %sem(%affected) mit dem status %info eingetragen. (%dbg_info)', 0, 0),
('6e2b789a57b9125af59c0273f5b47cb1', 'SEM_USER_DEL', 'Aus Veranstaltung ausgetragen', '%user hat %user(%coaffected) aus %sem(%affected) ausgetragen. (%info)', 0, 0),
('d07c8b37c6d3e206cd012d07ba8028b1', 'SEM_CHANGED_RIGHTS', 'Veranstaltungsrechte geändert', '%user hat %user(%coaffected) in %sem(%affected) als %info eingetragen. (%dbg_info)', 0, 0),
('2420da2946df66a5ad96c6d45e97d5b9', 'SEM_ADD_STUDYAREA', 'Studienbereich zu Veranst. hinzufügen', '%user fügt Studienbereich "%studyarea(%coaffected)" zu %sem(%affected) hinzu.', 0, 0),
('754708c8c0c61a916855c5031014acbb', 'SEM_DELETE_STUDYAREA', 'Studienbereich aus Veranst. löschen', '%user entfernt Studienbereich "%studyarea(%coaffected)" aus %sem(%affected).', 0, 0),
('30dfb509cb1a8e228af3bd17dd6c8d1d', 'RES_ASSIGN_SEM', 'Buchen einer Ressource (VA)', '%user bucht %res(%affected) für %sem(%coaffected) (%info).', 0, 0),
('e8b1105ca4f2305ef0db6c961d2fbe4c', 'RES_ASSIGN_SINGLE', 'Buchen einer Ressource (Einzel)', '%user bucht %res(%affected) direkt (%info).', 0, 0),
('7d26ffbf73103601966f7517e40d7e66', 'RES_REQUEST_NEW', 'Neue Raumanfrage', '%user stellt neue Raumanfrage für %sem(%affected), gewünschter Raum: %res(%coaffected), %info', 0, 0),
('46bc7faabfc73864998b561b1011e3fe', 'RES_REQUEST_UPDATE', 'Geänderte Raumanfrage', '%user ändert Raumanfrage für %sem(%affected), gewünschter Raum: %res(%coaffected), %info', 0, 0),
('a0928e74639fd2a55f5d4d2a3c5a8e71', 'RES_REQUEST_DEL', 'Raumanfrage löschen', '%user löscht Raumanfrage für %sem(%affected).', 0, 0),
('a3856b6531e2f79d158b5ebfb998e5db', 'RES_ASSIGN_DEL_SEM', 'VA-Buchung löschen', '%user löscht Ressourcenbelegung für %res(%affected) in Veranstaltung %sem(%coaffected), %info.', 0, 0),
('17f0a527e9db7dec09687a70681559cf', 'RES_ASSIGN_DEL_SINGLE', 'Direktbuchung löschen', '%user löscht Direktbuchung für %res(%affected) (%info).', 0, 0),
('9179d3cf4e0353f9874bcde072d12b30', 'RES_REQUEST_DENY', 'Abgelehnte Raumanfrage', '%user lehnt Raumanfrage für %sem(%coaffected), Raum %sem(%affected) ab.', 0, 0),
('ff806b4b26f8bc8c3e65e29d14176cd9', 'RES_REQUEST_RESOLVE', 'Aufgelöste Raumanfrage', '%user löst Raumanfrage für %sem(%affected), Raum %res(%coaffected) auf.', 0, 0),
('248f54105b7102e5cbcc36e9439504fb', 'STUDYAREA_ADD', 'Studienbereich hinzufügen', '%user legt Studienbereich %studyarea(%affected) an.', 0, 0),
('9123d360316ba28ddb32c0ed1a0320f2', 'STUDYAREA_DELETE', 'Studienbereich löschen', '%user entfernt Studienbereich %studyarea(%affected).', 0, 0),
('897207a36c411d736947052219624b72', 'USER_CHANGE_PASSWORD', 'Nutzerpasswort geändert', '%user ändert/setzt das Passwort für %user(%affected)', 0, 0),
('9ed46a3ca3d4f43e17f91e314224dcae', 'SEM_CHANGE_CYCLE', 'Regelmäßige Zeit geändert', '%user hat in %sem(%affected) die regelmäßige Zeit %info geändert', 1, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `log_events`
--

DROP TABLE IF EXISTS `log_events`;
CREATE TABLE `log_events` (
  `event_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `action_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `affected_range_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `coaffected_range_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `info` text COLLATE latin1_general_ci,
  `dbg_info` text COLLATE latin1_general_ci,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`),
  KEY `action_id` (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `log_events`
--

INSERT INTO `log_events` (`event_id`, `user_id`, `action_id`, `affected_range_id`, `coaffected_range_id`, `info`, `dbg_info`, `mkdate`) VALUES
('54cd065a5af68a103a7cc450f235b192', '76ed43ef286fb55cf9e41beadb484a9f', 'f858b05c11f5faa2198a109a783087a8', 'c5ab3e6d39d8394837fb464c35bb61c5', NULL, NULL, NULL, 1342421964),
('050a17836060781283741977b6fa14b4', 'SYSTEM', '0ee290df95f0547caafa163c4d533991', 'c5ab3e6d39d8394837fb464c35bb61c5', NULL, NULL, 'admin_seminare_assi', 1342421964),
('9288ab2a2fe959c0977f98f225f46909', '76ed43ef286fb55cf9e41beadb484a9f', 'f858b05c11f5faa2198a109a783087a8', 'c5ab3e6d39d8394837fb464c35bb61c5', NULL, NULL, NULL, 1342421964),
('871bd5db7eedf09817f84475568370e6', 'SYSTEM', '0ee290df95f0547caafa163c4d533991', 'c5ab3e6d39d8394837fb464c35bb61c5', NULL, NULL, 'admin_seminare_assi', 1342421964),
('85fe7a9029fc3cfab1e73735fe195473', '76ed43ef286fb55cf9e41beadb484a9f', 'f858b05c11f5faa2198a109a783087a8', 'e7041099ea9f0745f6853d9ccea8793c', NULL, NULL, NULL, 1342422003),
('89880f4223f0f081625282f1c5fdb7ca', 'SYSTEM', '0ee290df95f0547caafa163c4d533991', 'e7041099ea9f0745f6853d9ccea8793c', NULL, NULL, 'admin_seminare_assi', 1342422003),
('9a55a893bbb4808e3e07556b6c53400f', '76ed43ef286fb55cf9e41beadb484a9f', 'a66c9e04e9c41bf5cc4d23fa509a8667', 'c5ab3e6d39d8394837fb464c35bb61c5', '1', NULL, NULL, 1342422109),
('3997088be6480abe32e2312fb489052d', '76ed43ef286fb55cf9e41beadb484a9f', 'f858b05c11f5faa2198a109a783087a8', '0d2df6a71f3317549a5f2f252863c62b', NULL, NULL, NULL, 1347366509),
('95477096c3cb0ffbf7904bb644efa0ac', 'SYSTEM', '0ee290df95f0547caafa163c4d533991', '0d2df6a71f3317549a5f2f252863c62b', NULL, NULL, 'admin_seminare_assi', 1347366509),
('b6eb92af23640ec5fa1898b3ef97e90c', '76ed43ef286fb55cf9e41beadb484a9f', 'f858b05c11f5faa2198a109a783087a8', '0d2df6a71f3317549a5f2f252863c62b', NULL, NULL, NULL, 1347366509),
('a427dc7b8dfe2ee401e8802b3fe46e5c', 'SYSTEM', '0ee290df95f0547caafa163c4d533991', '0d2df6a71f3317549a5f2f252863c62b', NULL, NULL, 'admin_seminare_assi', 1347366509),
('c2cadd9859795a04bf979454f55a019b', '76ed43ef286fb55cf9e41beadb484a9f', '89114dcd6f02dd7f94488a616c21a7c3', '0d2df6a71f3317549a5f2f252863c62b', '2', NULL, NULL, 1350489417),
('6f4622addb2883b9c467ead53feac789', '76ed43ef286fb55cf9e41beadb484a9f', '89114dcd6f02dd7f94488a616c21a7c3', '0d2df6a71f3317549a5f2f252863c62b', '1', NULL, NULL, 1350489417),
('59d766b238382f178bf180b81a0d73d8', '76ed43ef286fb55cf9e41beadb484a9f', 'a66c9e04e9c41bf5cc4d23fa509a8667', '0d2df6a71f3317549a5f2f252863c62b', '2', NULL, NULL, 1350489431),
('ca4bca0d7d76d68476a83d2ff01731e4', '76ed43ef286fb55cf9e41beadb484a9f', '89114dcd6f02dd7f94488a616c21a7c3', '0d2df6a71f3317549a5f2f252863c62b', '2', NULL, NULL, 1350489441),
('ad6ee8aeeb728fd8c8943078d7907bf4', '76ed43ef286fb55cf9e41beadb484a9f', 'a66c9e04e9c41bf5cc4d23fa509a8667', '0d2df6a71f3317549a5f2f252863c62b', '1', NULL, NULL, 1350489441),
('f5b07c54d6dd318b9c5edcc10527d210', '76ed43ef286fb55cf9e41beadb484a9f', 'a66c9e04e9c41bf5cc4d23fa509a8667', '0d2df6a71f3317549a5f2f252863c62b', '2', NULL, NULL, 1350489463),
('9360ff1a21c3dd62e0a83ef58315de9c', '76ed43ef286fb55cf9e41beadb484a9f', 'a92afa63584cc2a62d2dd2996727b2c5', 'cca72d353f2f35f1e3fc10b88d6aa390', NULL, NULL, NULL, 1354272745),
('2c1fe4cb801d3365be9b73eb9c9551d0', '76ed43ef286fb55cf9e41beadb484a9f', 'ca216ccdf753f59ba7fd621f7b22f7bd', 'cca72d353f2f35f1e3fc10b88d6aa390', NULL, 'Vorname:  -> Rasmus', NULL, 1354272745),
('57d1c9dc9495c8dbeab7fa5db9a8711d', '76ed43ef286fb55cf9e41beadb484a9f', 'ca216ccdf753f59ba7fd621f7b22f7bd', 'cca72d353f2f35f1e3fc10b88d6aa390', NULL, 'Nachname:  -> Fuhse', NULL, 1354272745),
('ad0cb5ece168a70af92c9ffd61ca1cc7', '76ed43ef286fb55cf9e41beadb484a9f', 'd18d750fb2c166e1c425976e8bca96e7', 'cca72d353f2f35f1e3fc10b88d6aa390', NULL, ' -> krassmus@gmail.com', NULL, 1354272745),
('0961b270750715779d3fc91f73f4c95f', '76ed43ef286fb55cf9e41beadb484a9f', 'e406e407501c8418f752e977182cd782', 'cca72d353f2f35f1e3fc10b88d6aa390', NULL, ' -> dozent', NULL, 1354272745),
('e5d430da8ef8a2c316b2a8ece41678db', '76ed43ef286fb55cf9e41beadb484a9f', 'cf8986a67e67ca273e15fd9230f6e872', 'cca72d353f2f35f1e3fc10b88d6aa390', NULL, 'title_front:  -> Dipl.-Math.', NULL, 1354272745),
('64f8822dd59964de21a3da088bcf6624', '76ed43ef286fb55cf9e41beadb484a9f', '63042706e5cd50924987b9515e1e6cae', '7a4f19a0a2c321ab2b8f7b798881af7c', 'cca72d353f2f35f1e3fc10b88d6aa390', 'dozent', NULL, 1354272745),
('b0b8fea80d27a5402216f19f48832c0e', '76ed43ef286fb55cf9e41beadb484a9f', 'a92afa63584cc2a62d2dd2996727b2c5', 'ac1981c0e8d159d8121508c488fad1cb', NULL, NULL, NULL, 1354272775),
('2f2adf7119a8c90fa12390b3c7ecb549', '76ed43ef286fb55cf9e41beadb484a9f', 'ca216ccdf753f59ba7fd621f7b22f7bd', 'ac1981c0e8d159d8121508c488fad1cb', NULL, 'Vorname:  -> André', NULL, 1354272775),
('021eade6cfb78a938951405449805dac', '76ed43ef286fb55cf9e41beadb484a9f', 'ca216ccdf753f59ba7fd621f7b22f7bd', 'ac1981c0e8d159d8121508c488fad1cb', NULL, 'Nachname:  -> Noack', NULL, 1354272775),
('3fa2a2d1ed50bec7ef1549729da88861', '76ed43ef286fb55cf9e41beadb484a9f', 'd18d750fb2c166e1c425976e8bca96e7', 'ac1981c0e8d159d8121508c488fad1cb', NULL, ' -> noack@data-quest.de', NULL, 1354272775),
('75bb9e22b18e45f5abbd559b72523c08', '76ed43ef286fb55cf9e41beadb484a9f', 'e406e407501c8418f752e977182cd782', 'ac1981c0e8d159d8121508c488fad1cb', NULL, ' -> dozent', NULL, 1354272775),
('ab35270a97d4124087d37354fb070b34', '76ed43ef286fb55cf9e41beadb484a9f', '63042706e5cd50924987b9515e1e6cae', '7a4f19a0a2c321ab2b8f7b798881af7c', 'ac1981c0e8d159d8121508c488fad1cb', 'dozent', NULL, 1354272775);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `media_cache`
--

DROP TABLE IF EXISTS `media_cache`;
CREATE TABLE `media_cache` (
  `id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `type` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `chdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expires` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `media_cache`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `message_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `chat_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `autor_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `message` text COLLATE latin1_general_ci NOT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `readed` tinyint(1) NOT NULL DEFAULT '0',
  `reading_confirmation` tinyint(1) NOT NULL DEFAULT '0',
  `priority` enum('normal','high') COLLATE latin1_general_ci NOT NULL DEFAULT 'normal',
  PRIMARY KEY (`message_id`),
  KEY `chat_id` (`chat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `message`
--

INSERT INTO `message` (`message_id`, `chat_id`, `autor_id`, `subject`, `message`, `mkdate`, `readed`, `reading_confirmation`, `priority`) VALUES
('2a8758f30f4b792af368e54870c0305f', NULL, '76ed43ef286fb55cf9e41beadb484a9f', '[Transferleistung]', 'nur ein Test', 1351155747, 0, 0, 'normal'),
('5a7d12a6967794101ab10482ff154794', NULL, '____%system%____', 'Systemnachricht: Eintragung in Veranstaltung', 'Sie wurden vom einem/einer DozentIn oder AdministratorIn als TeilnehmerIn in die Veranstaltung **Transferleistung** eingetragen.\n \n -- \nDiese Nachricht wurde automatisch vom Stud.IP-System generiert. Sie können darauf nicht antworten.', 1351155785, 0, 0, 'normal'),
('2c8117a84f06697d4587b38662b24a61', NULL, '____%system%____', 'Systemnachricht: Abonnement aufgehoben', 'Ihr Abonnement der Veranstaltung **Transferleistung** wurde von einem/einer VeranstaltungsleiterIn (DozentIn) oder AdministratorIn aufgehoben.\n \n -- \nDiese Nachricht wurde automatisch vom Stud.IP-System generiert. Sie können darauf nicht antworten.', 1351155842, 0, 0, 'normal');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `message_user`
--

DROP TABLE IF EXISTS `message_user`;
CREATE TABLE `message_user` (
  `user_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `message_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `readed` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `snd_rec` enum('rec','snd') COLLATE latin1_general_ci NOT NULL DEFAULT 'rec',
  `dont_delete` tinyint(1) NOT NULL DEFAULT '0',
  `folder` tinyint(4) NOT NULL DEFAULT '0',
  `confirmed_read` tinyint(1) NOT NULL DEFAULT '0',
  `answered` tinyint(1) NOT NULL DEFAULT '0',
  `mkdate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`message_id`,`snd_rec`,`user_id`),
  KEY `user_id` (`user_id`,`snd_rec`,`deleted`,`readed`,`mkdate`),
  KEY `user_id_2` (`user_id`,`snd_rec`,`deleted`,`folder`,`mkdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `message_user`
--

INSERT INTO `message_user` (`user_id`, `message_id`, `readed`, `deleted`, `snd_rec`, `dont_delete`, `folder`, `confirmed_read`, `answered`, `mkdate`) VALUES
('76ed43ef286fb55cf9e41beadb484a9f', '2a8758f30f4b792af368e54870c0305f', 0, 0, 'snd', 0, 0, 0, 0, 1351155747),
('205f3efb7997a0fc9755da2b535038da', '2a8758f30f4b792af368e54870c0305f', 0, 0, 'rec', 0, 0, 0, 0, 1351155747),
('____%system%____', '5a7d12a6967794101ab10482ff154794', 0, 1, 'snd', 0, 0, 0, 0, 1351155785),
('e7a0a84b161f3e8c09b4a0a2e8a58147', '5a7d12a6967794101ab10482ff154794', 1, 0, 'rec', 0, 0, 0, 0, 1351155785),
('____%system%____', '2c8117a84f06697d4587b38662b24a61', 0, 1, 'snd', 0, 0, 0, 0, 1351155842),
('e7a0a84b161f3e8c09b4a0a2e8a58147', '2c8117a84f06697d4587b38662b24a61', 1, 0, 'rec', 0, 0, 0, 0, 1351155842);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `news_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `topic` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `body` text COLLATE latin1_general_ci NOT NULL,
  `author` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT '0',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `expire` int(11) NOT NULL DEFAULT '0',
  `allow_comments` tinyint(1) NOT NULL DEFAULT '0',
  `chdate` int(10) unsigned NOT NULL DEFAULT '0',
  `chdate_uid` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`news_id`),
  KEY `date` (`date`),
  KEY `chdate` (`chdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `news`
--

INSERT INTO `news` (`news_id`, `topic`, `body`, `author`, `date`, `user_id`, `expire`, `allow_comments`, `chdate`, `chdate_uid`, `mkdate`) VALUES
('29f2932ce32be989022c6f43b866e744', 'Herzlich Willkommen!', 'Das Stud.IP-Team heisst sie herzlich willkommen. \r\nBitte schauen Sie sich ruhig um!\r\n\r\nWenn Sie das System selbst installiert haben und diese News sehen, haben Sie die Demonstrationsdaten in die Datenbank eingefügt. Wenn Sie produktiv mit dem System arbeiten wollen, sollten Sie diese Daten später wieder löschen, da die Passwörter der Accounts (vor allem des root-Accounts) öffentlich bekannt sind.', 'Root Studip', 1340615938, '76ed43ef286fb55cf9e41beadb484a9f', 14562502, 1, 1340615938, '', 1340615938);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news_range`
--

DROP TABLE IF EXISTS `news_range`;
CREATE TABLE `news_range` (
  `news_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`news_id`,`range_id`),
  KEY `range_id` (`range_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `news_range`
--

INSERT INTO `news_range` (`news_id`, `range_id`) VALUES
('29f2932ce32be989022c6f43b866e744', '76ed43ef286fb55cf9e41beadb484a9f'),
('29f2932ce32be989022c6f43b866e744', 'studip');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news_rss_range`
--

DROP TABLE IF EXISTS `news_rss_range`;
CREATE TABLE `news_rss_range` (
  `range_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `rss_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_type` enum('user','sem','inst','global') COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  PRIMARY KEY (`range_id`),
  KEY `rss_id` (`rss_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `news_rss_range`
--

INSERT INTO `news_rss_range` (`range_id`, `rss_id`, `range_type`) VALUES
('studip', '70cefd1e80398bb20ff599636546cdff', 'global');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `object_contentmodules`
--

DROP TABLE IF EXISTS `object_contentmodules`;
CREATE TABLE `object_contentmodules` (
  `object_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `module_id` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `system_type` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `module_type` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`module_id`,`system_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `object_contentmodules`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `object_rate`
--

DROP TABLE IF EXISTS `object_rate`;
CREATE TABLE `object_rate` (
  `object_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `rate` int(10) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  KEY `object_id` (`object_id`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `object_rate`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `object_user`
--

DROP TABLE IF EXISTS `object_user`;
CREATE TABLE `object_user` (
  `object_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `flag` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`user_id`,`flag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `object_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `object_user_visits`
--

DROP TABLE IF EXISTS `object_user_visits`;
CREATE TABLE `object_user_visits` (
  `object_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` enum('vote','documents','forum','literature','schedule','scm','sem','wiki','news','eval','inst','ilias_connect','elearning_interface','participants') COLLATE latin1_general_ci NOT NULL DEFAULT 'vote',
  `visitdate` int(20) NOT NULL DEFAULT '0',
  `last_visitdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`user_id`,`type`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `object_user_visits`
--

INSERT INTO `object_user_visits` (`object_id`, `user_id`, `type`, `visitdate`, `last_visitdate`) VALUES
('c5ab3e6d39d8394837fb464c35bb61c5', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1354722551, 1353330006),
('0d2df6a71f3317549a5f2f252863c62b', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1352905807, 1352905624),
('abc7afe1e67d030ad7eedeaabca89eb4', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1348057151, 0),
('d354ab793ea15cc88b9a74355d60ebeb', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1351592954, 1351592943),
('24e396bc55d5d46cc50f87c2a813ac9b', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1348062712, 0),
('d354ab793ea15cc88b9a74355d60ebeb', '7e81ec247c151c02ffd479511e24cc03', 'sem', 1352978200, 1352978133),
('d8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1353334033, 1353333998),
('d8cf16f630efea34ac9a20153f9577a7', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'sem', 1352907193, 1352900292),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'sem', 1352902902, 1352902896),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'sem', 1352995532, 1352995525),
('834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1352737146, 1350488715),
('0d2df6a71f3317549a5f2f252863c62b', '76ed43ef286fb55cf9e41beadb484a9f', 'participants', 1352905632, 1351156049),
('29f2932ce32be989022c6f43b866e744', '76ed43ef286fb55cf9e41beadb484a9f', 'news', 1354891932, 1352278408),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'literature', 1352902913, 1352901745),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'schedule', 1352902906, 1352902849),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'forum', 1352902897, 0),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'documents', 1352902903, 0),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'scm', 1352902910, 0),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'wiki', 1352902915, 0),
('7cb72dab1bf896a0b55c6aa7a70a3a86', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'sem', 1352902927, 0),
('d8cf16f630efea34ac9a20153f9577a7', '7e81ec247c151c02ffd479511e24cc03', 'sem', 1353682135, 1352990551),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'forum', 1352995526, 1352980739),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'participants', 1352995533, 1352980748),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'documents', 1352980752, 0),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'schedule', 1352980754, 0),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'scm', 1352980755, 0),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'literature', 1352980757, 0),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'wiki', 1352980760, 0),
('834499e2b8a2cd71637890e5de31cba3', '205f3efb7997a0fc9755da2b535038da', 'sem', 1352995705, 0),
('834499e2b8a2cd71637890e5de31cba3', '205f3efb7997a0fc9755da2b535038da', 'forum', 1352995708, 0),
('834499e2b8a2cd71637890e5de31cba3', '205f3efb7997a0fc9755da2b535038da', 'participants', 1352995710, 0),
('7d784fb5cb9a5b187bfda24fd0f613dd', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1354900004, 1354895866),
('7d784fb5cb9a5b187bfda24fd0f613dd', '76ed43ef286fb55cf9e41beadb484a9f', 'participants', 1354895872, 1354885905),
('713f4c09e20c17deb5efe4a0dba2cee7', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1354885919, 0),
('713f4c09e20c17deb5efe4a0dba2cee7', '76ed43ef286fb55cf9e41beadb484a9f', 'participants', 1354885922, 0),
('9598160de9b44d5d229eab2a0126cacc', '76ed43ef286fb55cf9e41beadb484a9f', 'sem', 1354891868, 0),
('9598160de9b44d5d229eab2a0126cacc', '76ed43ef286fb55cf9e41beadb484a9f', 'participants', 1354891871, 0),
('9598160de9b44d5d229eab2a0126cacc', '76ed43ef286fb55cf9e41beadb484a9f', 'wiki', 1354891874, 0),
('9598160de9b44d5d229eab2a0126cacc', '76ed43ef286fb55cf9e41beadb484a9f', 'forum', 1354891877, 0),
('9598160de9b44d5d229eab2a0126cacc', '76ed43ef286fb55cf9e41beadb484a9f', 'documents', 1354891894, 0),
('9598160de9b44d5d229eab2a0126cacc', '76ed43ef286fb55cf9e41beadb484a9f', 'schedule', 1354891898, 0),
('9598160de9b44d5d229eab2a0126cacc', '76ed43ef286fb55cf9e41beadb484a9f', 'scm', 1354891907, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `object_views`
--

DROP TABLE IF EXISTS `object_views`;
CREATE TABLE `object_views` (
  `object_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `views` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`),
  KEY `views` (`views`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `object_views`
--

INSERT INTO `object_views` (`object_id`, `views`, `chdate`) VALUES
('f859df66bb9a3f8ecd46a9895d4e47d2', 4, 1354899987),
('e7a0a84b161f3e8c09b4a0a2e8a58147', 2, 1351591637);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `plugins`
--

DROP TABLE IF EXISTS `plugins`;
CREATE TABLE `plugins` (
  `pluginid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pluginclassname` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pluginpath` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pluginname` varchar(45) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `plugintype` text COLLATE latin1_general_ci NOT NULL,
  `enabled` enum('yes','no') COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `navigationpos` int(10) unsigned NOT NULL DEFAULT '0',
  `dependentonid` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pluginid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `plugins`
--

INSERT INTO `plugins` (`pluginid`, `pluginclassname`, `pluginpath`, `pluginname`, `plugintype`, `enabled`, `navigationpos`, `dependentonid`) VALUES
(1, 'CampusConnect', 'data-quest/CampusConnect', 'CampusConnect', 'SystemPlugin,StandardPlugin', 'yes', 0, NULL),
(2, 'CampusConnectLink', 'data-quest/CampusConnect', 'CampusConnectLink', 'StandardPlugin', 'yes', 0, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `plugins_activated`
--

DROP TABLE IF EXISTS `plugins_activated`;
CREATE TABLE `plugins_activated` (
  `pluginid` int(10) unsigned NOT NULL DEFAULT '0',
  `poiid` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `state` enum('on','off') COLLATE latin1_general_ci NOT NULL DEFAULT 'on',
  PRIMARY KEY (`pluginid`,`poiid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `plugins_activated`
--

INSERT INTO `plugins_activated` (`pluginid`, `poiid`, `state`) VALUES
(1, 'semc5ab3e6d39d8394837fb464c35bb61c5', 'off'),
(2, 'sem0d2df6a71f3317549a5f2f252863c62b', 'off'),
(1, 'sem0d2df6a71f3317549a5f2f252863c62b', 'off');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `plugins_default_activations`
--

DROP TABLE IF EXISTS `plugins_default_activations`;
CREATE TABLE `plugins_default_activations` (
  `pluginid` int(10) unsigned NOT NULL DEFAULT '0',
  `institutid` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`pluginid`,`institutid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='default activations of standard plugins';

--
-- Daten für Tabelle `plugins_default_activations`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `px_topics`
--

DROP TABLE IF EXISTS `px_topics`;
CREATE TABLE `px_topics` (
  `topic_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `root_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `description` text COLLATE latin1_general_ci,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `author` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `author_host` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `anonymous` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topic_id`),
  KEY `root_id` (`root_id`),
  KEY `Seminar_id` (`Seminar_id`),
  KEY `parent_id` (`parent_id`),
  KEY `chdate` (`chdate`),
  KEY `mkdate` (`mkdate`),
  KEY `user_id` (`user_id`,`Seminar_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `px_topics`
--

INSERT INTO `px_topics` (`topic_id`, `parent_id`, `root_id`, `name`, `description`, `mkdate`, `chdate`, `author`, `author_host`, `Seminar_id`, `user_id`, `anonymous`) VALUES
('5260172c3d6f9d56d21b06bf4c278b52', '0', '5260172c3d6f9d56d21b06bf4c278b52', 'Allgemeine Diskussionen', 'Hier ist Raum für allgemeine Diskussionen', 1084723039, 1084723039, '', '134.76.62.67', 'ec2e364b28357106c0f8c282733dbe56', '76ed43ef286fb55cf9e41beadb484a9f', 0),
('b30ec732ee1c69a275b2d6adaae49cdc', '0', 'b30ec732ee1c69a275b2d6adaae49cdc', 'Allgemeine Diskussionen', 'Hier ist Raum für allgemeine Diskussionen', 1084723053, 1084723053, '', '134.76.62.67', '7a4f19a0a2c321ab2b8f7b798881af7c', '76ed43ef286fb55cf9e41beadb484a9f', 0),
('9f394dffd08043f13cc65ffff65bfa05', '0', '9f394dffd08043f13cc65ffff65bfa05', 'Allgemeine Diskussionen', 'Hier ist Raum für allgemeine Diskussionen', 1084723061, 1084723061, '', '134.76.62.67', '110ce78ffefaf1e5f167cd7019b728bf', '76ed43ef286fb55cf9e41beadb484a9f', 0),
('515b5485c3c72065df1c8980725e14ca', '0', '515b5485c3c72065df1c8980725e14ca', 'Allgemeine Diskussionen', '', 1176472544, 1176472551, 'Root Studip', '81.20.112.44', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', 0),
('9ae835581afb2d60559637d98b02b117', '0', '9ae835581afb2d60559637d98b02b117', 'Allgemeine Diskussionen', 'Hier ist Raum für allgemeine Diskussionen', 1347366509, 1347366509, 'Root Studip', '81.20.112.44', '0d2df6a71f3317549a5f2f252863c62b', '76ed43ef286fb55cf9e41beadb484a9f', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `range_tree`
--

DROP TABLE IF EXISTS `range_tree`;
CREATE TABLE `range_tree` (
  `item_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `level` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `studip_object` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `studip_object_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `parent_id` (`parent_id`),
  KEY `priority` (`priority`),
  KEY `studip_object_id` (`studip_object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `range_tree`
--

INSERT INTO `range_tree` (`item_id`, `parent_id`, `level`, `priority`, `name`, `studip_object`, `studip_object_id`) VALUES
('3f93863e3d37ba0df286a6e7e26974ef', 'root', 0, 0, 'Einrichtungen der Universität', '', ''),
('1323254564871354786157481484621', '3f93863e3d37ba0df286a6e7e26974ef', 1, 0, '', 'inst', '1535795b0d6ddecac6813f5f6ac47ef2'),
('ce6c87bbf759b4cfd6f92d0c5560da5c', '1323254564871354786157481484621', 0, 0, 'Test Einrichtung', 'inst', '2560f7c7674942a7dce8eeb238e15d93'),
('2f4f90ac9d8d832cc8c8a95910fde4eb', '1323254564871354786157481484621', 0, 1, 'Test Lehrstuhl', 'inst', '536249daa596905f433e1f73578019db'),
('5d032f70c255f3e57cf8aa85a429ad4e', '1323254564871354786157481484621', 0, 2, 'Test Abteilung', 'inst', 'f02e2b17bc0e99fc885da6ac4c2532dc'),
('a3d977a66f0010fa8e15c27dd71aff63', 'root', 0, 1, 'externe Bildungseinrichtungen', 'fak', 'ec2e364b28357106c0f8c282733dbe56'),
('e0ff0ead6a8c5191078ed787cd7c0c1f', 'a3d977a66f0010fa8e15c27dd71aff63', 0, 0, 'externe Einrichtung A', 'inst', '7a4f19a0a2c321ab2b8f7b798881af7c'),
('105b70b72dc1908ce2925e057c4a8daa', 'a3d977a66f0010fa8e15c27dd71aff63', 0, 1, 'externe Einrichtung B', 'inst', '110ce78ffefaf1e5f167cd7019b728bf');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_assign`
--

DROP TABLE IF EXISTS `resources_assign`;
CREATE TABLE `resources_assign` (
  `assign_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `resource_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `assign_user_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `user_free_name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `begin` int(20) NOT NULL DEFAULT '0',
  `end` int(20) NOT NULL DEFAULT '0',
  `repeat_end` int(20) DEFAULT NULL,
  `repeat_quantity` int(2) DEFAULT NULL,
  `repeat_interval` int(2) DEFAULT NULL,
  `repeat_month_of_year` int(2) DEFAULT NULL,
  `repeat_day_of_month` int(2) DEFAULT NULL,
  `repeat_week_of_month` int(2) DEFAULT NULL,
  `repeat_day_of_week` int(2) DEFAULT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `comment_internal` text COLLATE latin1_general_ci,
  PRIMARY KEY (`assign_id`),
  KEY `resource_id` (`resource_id`),
  KEY `assign_user_id` (`assign_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_assign`
--

INSERT INTO `resources_assign` (`assign_id`, `resource_id`, `assign_user_id`, `user_free_name`, `begin`, `end`, `repeat_end`, `repeat_quantity`, `repeat_interval`, `repeat_month_of_year`, `repeat_day_of_month`, `repeat_week_of_month`, `repeat_day_of_week`, `mkdate`, `chdate`, `comment_internal`) VALUES
('841cf8df24e1604a0127b8554a162bdb', '728f1578de643fb08b32b4b8afb2db77', 'cdb0b2f7c3977a78c780b03d3f189bc9', '', 1318838400, 1318845600, 1318845600, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('33ffeafdc17b32f76e6bea1dacd9bfe3', '728f1578de643fb08b32b4b8afb2db77', 'e41ef4b756e5d12c2fc41148fa234a10', '', 1319443200, 1319450400, 1319450400, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('2d782258ccab5dad9ebbe023382db2a2', '728f1578de643fb08b32b4b8afb2db77', 'a9997a4cb099f2af24d7f511dc50141b', '', 1320051600, 1320058800, 1320058800, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('977c332801d6e28b3f791decbb7520a0', '728f1578de643fb08b32b4b8afb2db77', 'eeeb9bf048703cedeb3b939608bd4404', '', 1320656400, 1320663600, 1320663600, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('048491827bb608a43884d8d8a7de714b', '728f1578de643fb08b32b4b8afb2db77', 'df52bb52be086a5e53131fa4cb4ce283', '', 1321261200, 1321268400, 1321268400, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('29ecd424a88312959e39e4fc21c902b1', '728f1578de643fb08b32b4b8afb2db77', '739c57d3acd8fb6aa04b58518b070260', '', 1321866000, 1321873200, 1321873200, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('cc45091e60abe49b945e961ca44b40c9', '728f1578de643fb08b32b4b8afb2db77', 'fdb2712dedb8a2aa1b06ede975688352', '', 1322470800, 1322478000, 1322478000, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('cba6ed2c0546af9f4df32ee02027f3b3', '728f1578de643fb08b32b4b8afb2db77', 'edc6d7bf127f8b18f70208f39194c3e9', '', 1323075600, 1323082800, 1323082800, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('2bb7f682a9afcf2be2b265a079e8d839', '728f1578de643fb08b32b4b8afb2db77', '56ff28275c6527a8132f9dabee3350a9', '', 1323680400, 1323687600, 1323687600, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('c2cbe476649e0e8e8d395bd0f4092518', '728f1578de643fb08b32b4b8afb2db77', 'ffe9e79ed927ca1a2133386c43ec7d3d', '', 1324285200, 1324292400, 1324292400, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('3509f07b437928481691c93b3e4ed907', '728f1578de643fb08b32b4b8afb2db77', '1944327eb9b4a904b9e9792685bbe995', '', 1326099600, 1326106800, 1326106800, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('23d296d0ca9970fca5355a2a0d860598', '728f1578de643fb08b32b4b8afb2db77', '5c7581d917d87ed05ee971ad3c5051bd', '', 1326704400, 1326711600, 1326711600, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('17686e2759b2e267d4ef41bc864659e1', '728f1578de643fb08b32b4b8afb2db77', 'd79c261e0e25ec52931b69c213439cfd', '', 1327309200, 1327316400, 1327316400, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('0ca675011623ec252677fbff1f4b8834', '728f1578de643fb08b32b4b8afb2db77', '0d5b5638eb568c5cd7c89ca90352c400', '', 1327914000, 1327921200, 1327921200, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('1c57630a85e2d1c29b1db6e3f2030962', '728f1578de643fb08b32b4b8afb2db77', '0e686bda235739042215c437f8324a3d', '', 1328518800, 1328526000, 1328526000, 0, 0, 0, 0, 0, 0, 1311416134, 1311416134, NULL),
('e876487ffdd1aafe4e41be1747b16a42', '51ad4b7100d3a8a1db61c7b099f052a6', '5dc85e7b934206c2e7bae0d139ec1a4e', '', 1319612400, 1319619600, 1319619600, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL),
('a1be21e24944b9bb113c449bf70ff2c1', '51ad4b7100d3a8a1db61c7b099f052a6', '7ac48037d6103c29e29abea65c9e6c85', '', 1320825600, 1320832800, 1320832800, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL),
('ea800b101391cd93ffee923822b92b73', '51ad4b7100d3a8a1db61c7b099f052a6', 'cc04c7bd4b0259b8968402d8ce85b4cc', '', 1322035200, 1322042400, 1322042400, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL),
('9cd4bcf9e173d114a35530767493f1ec', '51ad4b7100d3a8a1db61c7b099f052a6', '103a7c9a1a9433494f979dcd1c654742', '', 1323244800, 1323252000, 1323252000, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL),
('6e51a6529bbb79345d8edd2aee7951fd', '51ad4b7100d3a8a1db61c7b099f052a6', '914976ace65274dabe4a3812167fe37e', '', 1324454400, 1324461600, 1324461600, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL),
('ac928363eaac34e76e7240af19d960ee', '51ad4b7100d3a8a1db61c7b099f052a6', '26125eb9fa17efa3947f4c0b1a7a8600', '', 1325664000, 1325671200, 1325671200, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL),
('a94a3c96e9e33cf714bafd1fedb943f7', '51ad4b7100d3a8a1db61c7b099f052a6', '157f8605ad389c7b59d8437bcd7a5a54', '', 1326873600, 1326880800, 1326880800, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL),
('61badf74984a5a5fc072c826964b4bf8', '51ad4b7100d3a8a1db61c7b099f052a6', '2c9a2628f2ba40c3fef4542c871da912', '', 1328083200, 1328090400, 1328090400, 0, 0, 0, 0, 0, 0, 1311416161, 1311416161, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_categories`
--

DROP TABLE IF EXISTS `resources_categories`;
CREATE TABLE `resources_categories` (
  `category_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `system` tinyint(4) NOT NULL DEFAULT '0',
  `is_room` tinyint(4) NOT NULL DEFAULT '0',
  `iconnr` int(3) DEFAULT '1',
  PRIMARY KEY (`category_id`),
  KEY `is_room` (`is_room`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_categories`
--

INSERT INTO `resources_categories` (`category_id`, `name`, `description`, `system`, `is_room`, `iconnr`) VALUES
('3cbcc99c39476b8e2c8eef5381687461', 'Gebäude', '', 0, 0, 1),
('85d62e2a8a87a2924db8fc4ed3fde09d', 'Hörsaal', '', 0, 1, 1),
('f3351baeca8776d4ffe4b672f568cbed', 'Gerät', '', 0, 0, 1),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', 'Übungsraum', '', 0, 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_categories_properties`
--

DROP TABLE IF EXISTS `resources_categories_properties`;
CREATE TABLE `resources_categories_properties` (
  `category_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `property_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `requestable` tinyint(4) NOT NULL DEFAULT '0',
  `system` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`,`property_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_categories_properties`
--

INSERT INTO `resources_categories_properties` (`category_id`, `property_id`, `requestable`, `system`) VALUES
('3cbcc99c39476b8e2c8eef5381687461', 'c4f13691419a6c12d38ad83daa926c7c', 0, 0),
('85d62e2a8a87a2924db8fc4ed3fde09d', 'afb8675e2257c03098aa34b2893ba686', 1, 0),
('85d62e2a8a87a2924db8fc4ed3fde09d', '7c1a8f6001cfdcb9e9c33eeee0ef343d', 1, 0),
('3cbcc99c39476b8e2c8eef5381687461', 'b79b77f40706ed598f5403f953c1f791', 0, 0),
('85d62e2a8a87a2924db8fc4ed3fde09d', '1f8cef2b614382e36eaa4a29f6027edf', 1, 0),
('85d62e2a8a87a2924db8fc4ed3fde09d', '44fd30e8811d0d962582fa1a9c452bdd', 1, 0),
('85d62e2a8a87a2924db8fc4ed3fde09d', '613cfdf6aa1072e21a1edfcfb0445c69', 1, 0),
('85d62e2a8a87a2924db8fc4ed3fde09d', '28addfe18e86cc3587205734c8bc2372', 1, 0),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', '7c1a8f6001cfdcb9e9c33eeee0ef343d', 1, 0),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', 'afb8675e2257c03098aa34b2893ba686', 1, 0),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', 'b79b77f40706ed598f5403f953c1f791', 1, 0),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', '1f8cef2b614382e36eaa4a29f6027edf', 1, 0),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', '44fd30e8811d0d962582fa1a9c452bdd', 1, 0),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', '613cfdf6aa1072e21a1edfcfb0445c69', 1, 0),
('5a72dfe3f0c0295a8fe4e12c86d4c8f4', '28addfe18e86cc3587205734c8bc2372', 1, 0),
('85d62e2a8a87a2924db8fc4ed3fde09d', 'b79b77f40706ed598f5403f953c1f791', 1, 0),
('f3351baeca8776d4ffe4b672f568cbed', 'cb8140efbc2af5362b1159c65deeec9e', 0, 0),
('f3351baeca8776d4ffe4b672f568cbed', 'c4352a580051a81830ef5980941c9e06', 0, 0),
('f3351baeca8776d4ffe4b672f568cbed', '39c73942e1c1650fa20c7259be96b3f3', 0, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_locks`
--

DROP TABLE IF EXISTS `resources_locks`;
CREATE TABLE `resources_locks` (
  `lock_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lock_begin` int(20) unsigned DEFAULT NULL,
  `lock_end` int(20) unsigned DEFAULT NULL,
  `type` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`lock_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_locks`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_objects`
--

DROP TABLE IF EXISTS `resources_objects`;
CREATE TABLE `resources_objects` (
  `resource_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `root_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `category_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `owner_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `institut_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `level` int(4) DEFAULT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `lockable` tinyint(4) DEFAULT NULL,
  `multiple_assign` tinyint(4) DEFAULT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resource_id`),
  KEY `institut_id` (`institut_id`),
  KEY `root_id` (`root_id`),
  KEY `parent_id` (`parent_id`),
  KEY `category_id` (`category_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_objects`
--

INSERT INTO `resources_objects` (`resource_id`, `root_id`, `parent_id`, `category_id`, `owner_id`, `institut_id`, `level`, `name`, `description`, `lockable`, `multiple_assign`, `mkdate`, `chdate`) VALUES
('0ff09e4f5a729981e978d970f9d970cb', '0ff09e4f5a729981e978d970f9d970cb', '0', '', '76ed43ef286fb55cf9e41beadb484a9f', '', 0, 'Gebäude', '', 0, 0, 1084640001, 1084640009),
('f37cbb74e9c9a8a0539bac1f3d6c1e96', 'f37cbb74e9c9a8a0539bac1f3d6c1e96', '0', '', '76ed43ef286fb55cf9e41beadb484a9f', '', 0, 'Geräte', 'Dieses Objekt kennzeichnet eine Hierachie und kann jederzeit in eine Ressource umgewandelt werden', 0, 0, 1084640011, 1084640036),
('8a57860ca2be4cc3a77c06c1d346ea57', '0ff09e4f5a729981e978d970f9d970cb', '0ff09e4f5a729981e978d970f9d970cb', '3cbcc99c39476b8e2c8eef5381687461', '76ed43ef286fb55cf9e41beadb484a9f', '', 1, 'Hörsaalgebäude', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 1, 1084640042, 1084640452),
('6350c6ae2ec6fd8bd852d505789d0666', '0ff09e4f5a729981e978d970f9d970cb', '0ff09e4f5a729981e978d970f9d970cb', '3cbcc99c39476b8e2c8eef5381687461', '76ed43ef286fb55cf9e41beadb484a9f', '', 1, 'Übungsgebäude', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 1, 1084640386, 1084640429),
('728f1578de643fb08b32b4b8afb2db77', '0ff09e4f5a729981e978d970f9d970cb', '8a57860ca2be4cc3a77c06c1d346ea57', '85d62e2a8a87a2924db8fc4ed3fde09d', '76ed43ef286fb55cf9e41beadb484a9f', '', 2, 'Hörsaal 1', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640456, 1084640468),
('b17c4ea6e053f2fffba8a5517fc277b3', '0ff09e4f5a729981e978d970f9d970cb', '8a57860ca2be4cc3a77c06c1d346ea57', '85d62e2a8a87a2924db8fc4ed3fde09d', '76ed43ef286fb55cf9e41beadb484a9f', '', 2, 'Hörsaal 2', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640520, 1084640528),
('2f98bf64830043fd98a39fbbe2068678', '0ff09e4f5a729981e978d970f9d970cb', '8a57860ca2be4cc3a77c06c1d346ea57', '85d62e2a8a87a2924db8fc4ed3fde09d', '76ed43ef286fb55cf9e41beadb484a9f', '', 2, 'Hörsaal 3', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640542, 1084640555),
('51ad4b7100d3a8a1db61c7b099f052a6', '0ff09e4f5a729981e978d970f9d970cb', '6350c6ae2ec6fd8bd852d505789d0666', '5a72dfe3f0c0295a8fe4e12c86d4c8f4', '76ed43ef286fb55cf9e41beadb484a9f', '', 2, 'Seminarraum 1', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640567, 1084640578),
('a8c03520e8ad9dc90fb2d161ffca7d7b', '0ff09e4f5a729981e978d970f9d970cb', '6350c6ae2ec6fd8bd852d505789d0666', '5a72dfe3f0c0295a8fe4e12c86d4c8f4', '76ed43ef286fb55cf9e41beadb484a9f', '', 2, 'Seminarraum 2', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640590, 1084640599),
('5ead77812be3b601e2f08ed5da4c5630', '0ff09e4f5a729981e978d970f9d970cb', '6350c6ae2ec6fd8bd852d505789d0666', '5a72dfe3f0c0295a8fe4e12c86d4c8f4', '76ed43ef286fb55cf9e41beadb484a9f', '', 2, 'Seminarraum 3', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640611, 1084723704),
('52b435cbdd021bcc5cd78835de2b4f57', 'f37cbb74e9c9a8a0539bac1f3d6c1e96', 'f37cbb74e9c9a8a0539bac1f3d6c1e96', 'f3351baeca8776d4ffe4b672f568cbed', '76ed43ef286fb55cf9e41beadb484a9f', '', 1, 'Beamer', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640739, 1084640748),
('ffacb5f74be406a524a380f1c135ee02', 'f37cbb74e9c9a8a0539bac1f3d6c1e96', 'f37cbb74e9c9a8a0539bac1f3d6c1e96', 'f3351baeca8776d4ffe4b672f568cbed', '76ed43ef286fb55cf9e41beadb484a9f', '', 1, 'Tageslichtprojektor', 'Dieses Objekt wurde neu erstellt. Es wurden noch keine Eigenschaften zugewiesen.', 0, 0, 1084640761, 1084640778);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_objects_properties`
--

DROP TABLE IF EXISTS `resources_objects_properties`;
CREATE TABLE `resources_objects_properties` (
  `resource_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `property_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `state` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`resource_id`,`property_id`),
  KEY `property_id` (`property_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_objects_properties`
--

INSERT INTO `resources_objects_properties` (`resource_id`, `property_id`, `state`) VALUES
('6350c6ae2ec6fd8bd852d505789d0666', 'c4f13691419a6c12d38ad83daa926c7c', 'Liebigstr. 1'),
('6350c6ae2ec6fd8bd852d505789d0666', 'b79b77f40706ed598f5403f953c1f791', 'on'),
('8a57860ca2be4cc3a77c06c1d346ea57', 'c4f13691419a6c12d38ad83daa926c7c', 'Universitätsstr. 1'),
('8a57860ca2be4cc3a77c06c1d346ea57', 'b79b77f40706ed598f5403f953c1f791', 'on'),
('728f1578de643fb08b32b4b8afb2db77', '44fd30e8811d0d962582fa1a9c452bdd', '500'),
('728f1578de643fb08b32b4b8afb2db77', '7c1a8f6001cfdcb9e9c33eeee0ef343d', 'on'),
('728f1578de643fb08b32b4b8afb2db77', 'b79b77f40706ed598f5403f953c1f791', 'on'),
('728f1578de643fb08b32b4b8afb2db77', '613cfdf6aa1072e21a1edfcfb0445c69', 'on'),
('728f1578de643fb08b32b4b8afb2db77', 'afb8675e2257c03098aa34b2893ba686', 'on'),
('728f1578de643fb08b32b4b8afb2db77', '1f8cef2b614382e36eaa4a29f6027edf', 'on'),
('728f1578de643fb08b32b4b8afb2db77', '28addfe18e86cc3587205734c8bc2372', 'on'),
('b17c4ea6e053f2fffba8a5517fc277b3', '44fd30e8811d0d962582fa1a9c452bdd', '150'),
('b17c4ea6e053f2fffba8a5517fc277b3', '7c1a8f6001cfdcb9e9c33eeee0ef343d', 'on'),
('b17c4ea6e053f2fffba8a5517fc277b3', 'b79b77f40706ed598f5403f953c1f791', 'on'),
('b17c4ea6e053f2fffba8a5517fc277b3', '28addfe18e86cc3587205734c8bc2372', ''),
('2f98bf64830043fd98a39fbbe2068678', '44fd30e8811d0d962582fa1a9c452bdd', '25'),
('2f98bf64830043fd98a39fbbe2068678', 'b79b77f40706ed598f5403f953c1f791', 'on'),
('2f98bf64830043fd98a39fbbe2068678', '613cfdf6aa1072e21a1edfcfb0445c69', 'on'),
('2f98bf64830043fd98a39fbbe2068678', '28addfe18e86cc3587205734c8bc2372', 'on'),
('51ad4b7100d3a8a1db61c7b099f052a6', '44fd30e8811d0d962582fa1a9c452bdd', '25'),
('51ad4b7100d3a8a1db61c7b099f052a6', '613cfdf6aa1072e21a1edfcfb0445c69', 'on'),
('51ad4b7100d3a8a1db61c7b099f052a6', 'afb8675e2257c03098aa34b2893ba686', 'on'),
('51ad4b7100d3a8a1db61c7b099f052a6', '28addfe18e86cc3587205734c8bc2372', 'on'),
('a8c03520e8ad9dc90fb2d161ffca7d7b', '44fd30e8811d0d962582fa1a9c452bdd', '30'),
('a8c03520e8ad9dc90fb2d161ffca7d7b', '7c1a8f6001cfdcb9e9c33eeee0ef343d', 'on'),
('a8c03520e8ad9dc90fb2d161ffca7d7b', 'b79b77f40706ed598f5403f953c1f791', 'on'),
('a8c03520e8ad9dc90fb2d161ffca7d7b', '613cfdf6aa1072e21a1edfcfb0445c69', 'on'),
('a8c03520e8ad9dc90fb2d161ffca7d7b', 'afb8675e2257c03098aa34b2893ba686', 'on'),
('a8c03520e8ad9dc90fb2d161ffca7d7b', '28addfe18e86cc3587205734c8bc2372', 'on'),
('5ead77812be3b601e2f08ed5da4c5630', '44fd30e8811d0d962582fa1a9c452bdd', '15'),
('5ead77812be3b601e2f08ed5da4c5630', 'afb8675e2257c03098aa34b2893ba686', 'on'),
('5ead77812be3b601e2f08ed5da4c5630', '1f8cef2b614382e36eaa4a29f6027edf', 'on'),
('52b435cbdd021bcc5cd78835de2b4f57', 'c4352a580051a81830ef5980941c9e06', '123456789'),
('52b435cbdd021bcc5cd78835de2b4f57', 'cb8140efbc2af5362b1159c65deeec9e', 'Sony'),
('52b435cbdd021bcc5cd78835de2b4f57', '39c73942e1c1650fa20c7259be96b3f3', '123132dffd5'),
('ffacb5f74be406a524a380f1c135ee02', 'c4352a580051a81830ef5980941c9e06', '225566'),
('ffacb5f74be406a524a380f1c135ee02', 'cb8140efbc2af5362b1159c65deeec9e', 'Telefunken'),
('ffacb5f74be406a524a380f1c135ee02', '39c73942e1c1650fa20c7259be96b3f3', 'wwqw'),
('5ead77812be3b601e2f08ed5da4c5630', '28addfe18e86cc3587205734c8bc2372', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_properties`
--

DROP TABLE IF EXISTS `resources_properties`;
CREATE TABLE `resources_properties` (
  `property_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `type` set('bool','text','num','select') COLLATE latin1_general_ci NOT NULL DEFAULT 'bool',
  `options` text COLLATE latin1_general_ci NOT NULL,
  `system` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`property_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_properties`
--

INSERT INTO `resources_properties` (`property_id`, `name`, `description`, `type`, `options`, `system`) VALUES
('44fd30e8811d0d962582fa1a9c452bdd', 'Sitzplätze', '', 'num', '', 2),
('c4f13691419a6c12d38ad83daa926c7c', 'Adresse', '', 'text', '', 0),
('7c1a8f6001cfdcb9e9c33eeee0ef343d', 'Beamer', '', 'bool', 'vorhanden', 0),
('b79b77f40706ed598f5403f953c1f791', 'behindertengerecht', '', 'bool', 'vorhanden', 0),
('613cfdf6aa1072e21a1edfcfb0445c69', 'Tageslichtprojektor', '', 'bool', 'vorhanden', 0),
('afb8675e2257c03098aa34b2893ba686', 'Dozentenrechner', '', 'bool', 'vorhanden', 0),
('1f8cef2b614382e36eaa4a29f6027edf', 'Audio-Anlage', '', 'bool', 'vorhanden', 0),
('c4352a580051a81830ef5980941c9e06', 'Seriennummer', '', 'num', '', 0),
('cb8140efbc2af5362b1159c65deeec9e', 'Hersteller', '', 'select', 'Sony;Philips;Technics;Telefunken;anderer', 0),
('39c73942e1c1650fa20c7259be96b3f3', 'Inventarnummer', '', 'num', '', 0),
('28addfe18e86cc3587205734c8bc2372', 'Verdunklung', '', 'bool', 'vorhanden', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_requests`
--

DROP TABLE IF EXISTS `resources_requests`;
CREATE TABLE `resources_requests` (
  `request_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `termin_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `metadate_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `resource_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `category_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `comment` text COLLATE latin1_general_ci,
  `reply_comment` text COLLATE latin1_general_ci,
  `closed` tinyint(3) unsigned DEFAULT NULL,
  `mkdate` int(20) unsigned DEFAULT NULL,
  `chdate` int(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `termin_id` (`termin_id`),
  KEY `seminar_id` (`seminar_id`),
  KEY `user_id` (`user_id`),
  KEY `resource_id` (`resource_id`),
  KEY `category_id` (`category_id`),
  KEY `closed` (`closed`,`request_id`,`resource_id`),
  KEY `metadate_id` (`metadate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_requests`
--

INSERT INTO `resources_requests` (`request_id`, `seminar_id`, `termin_id`, `metadate_id`, `user_id`, `resource_id`, `category_id`, `comment`, `reply_comment`, `closed`, `mkdate`, `chdate`) VALUES
('49841e651e23fe3cb41541381d1117d6', '834499e2b8a2cd71637890e5de31cba3', '67f1c5cc5a38779c1f09ab60699452d7', '', '76ed43ef286fb55cf9e41beadb484a9f', '', '5a72dfe3f0c0295a8fe4e12c86d4c8f4', '', NULL, 0, 1326810659, 1326810659);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_requests_properties`
--

DROP TABLE IF EXISTS `resources_requests_properties`;
CREATE TABLE `resources_requests_properties` (
  `request_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `property_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `state` text COLLATE latin1_general_ci,
  `mkdate` int(20) unsigned DEFAULT NULL,
  `chdate` int(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`request_id`,`property_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_requests_properties`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_temporary_events`
--

DROP TABLE IF EXISTS `resources_temporary_events`;
CREATE TABLE `resources_temporary_events` (
  `event_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `resource_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `assign_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `termin_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `begin` int(20) NOT NULL DEFAULT '0',
  `end` int(20) NOT NULL DEFAULT '0',
  `type` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`),
  KEY `resource_id` (`resource_id`),
  KEY `assign_object_id` (`assign_id`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_temporary_events`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `resources_user_resources`
--

DROP TABLE IF EXISTS `resources_user_resources`;
CREATE TABLE `resources_user_resources` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `resource_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `perms` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`,`resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `resources_user_resources`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `roleid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rolename` varchar(80) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `system` enum('y','n') COLLATE latin1_general_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`roleid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `roles`
--

INSERT INTO `roles` (`roleid`, `rolename`, `system`) VALUES
(1, 'Root-Administrator(in)', 'y'),
(2, 'Administrator(in)', 'y'),
(3, 'Mitarbeiter(in)', 'y'),
(4, 'Lehrende(r)', 'y'),
(5, 'Studierende(r)', 'y'),
(6, 'Tutor(in)', 'y'),
(7, 'Nobody', 'y');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `roles_plugins`
--

DROP TABLE IF EXISTS `roles_plugins`;
CREATE TABLE `roles_plugins` (
  `roleid` int(10) unsigned NOT NULL DEFAULT '0',
  `pluginid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleid`,`pluginid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `roles_plugins`
--

INSERT INTO `roles_plugins` (`roleid`, `pluginid`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `roles_studipperms`
--

DROP TABLE IF EXISTS `roles_studipperms`;
CREATE TABLE `roles_studipperms` (
  `roleid` int(10) unsigned NOT NULL DEFAULT '0',
  `permname` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`roleid`,`permname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `roles_studipperms`
--

INSERT INTO `roles_studipperms` (`roleid`, `permname`) VALUES
(1, 'root'),
(2, 'admin'),
(3, 'admin'),
(3, 'root'),
(4, 'dozent'),
(5, 'autor'),
(5, 'tutor'),
(6, 'tutor');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `roles_user`
--

DROP TABLE IF EXISTS `roles_user`;
CREATE TABLE `roles_user` (
  `roleid` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`roleid`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `roles_user`
--

INSERT INTO `roles_user` (`roleid`, `userid`) VALUES
(7, 'nobody');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rss_feeds`
--

DROP TABLE IF EXISTS `rss_feeds`;
CREATE TABLE `rss_feeds` (
  `feed_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `url` text COLLATE latin1_general_ci NOT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL DEFAULT '0',
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `fetch_title` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`feed_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `rss_feeds`
--

INSERT INTO `rss_feeds` (`feed_id`, `user_id`, `name`, `url`, `mkdate`, `chdate`, `priority`, `hidden`, `fetch_title`) VALUES
('486d7fe04aa150a05c259b5ce95bcbbb', '76ed43ef286fb55cf9e41beadb484a9f', 'Stud.IP-Projekt (Stud.IP - Entwicklungsserver der Stud.IP Core Group)', 'http://develop.studip.de/studip/rss.php?id=51fdeef0efc6e3dd72d29eeb0cac2a16', 1156518361, 1240431662, 0, 0, 1),
('7fbdfba36eab17be85d35fbb21a2423f', '205f3efb7997a0fc9755da2b535038da', 'Stud.IP-Blog', 'http://blog.studip.de/feed', 1194629881, 1194629896, 0, 0, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schedule`
--

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` smallint(6) NOT NULL COMMENT 'start hour and minutes',
  `end` smallint(6) NOT NULL COMMENT 'end hour and minutes',
  `day` tinyint(4) NOT NULL COMMENT 'day of week, 0-6',
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `content` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `color` varchar(7) COLLATE latin1_general_ci NOT NULL COMMENT 'color, rgb in hex',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `schedule`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schedule_seminare`
--

DROP TABLE IF EXISTS `schedule_seminare`;
CREATE TABLE `schedule_seminare` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `metadate_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `color` varchar(7) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'color, rgb in hex',
  PRIMARY KEY (`user_id`,`seminar_id`,`metadate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `schedule_seminare`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schema_version`
--

DROP TABLE IF EXISTS `schema_version`;
CREATE TABLE `schema_version` (
  `domain` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`domain`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `schema_version`
--

INSERT INTO `schema_version` (`domain`, `version`) VALUES
('studip', 93);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `scm`
--

DROP TABLE IF EXISTS `scm`;
CREATE TABLE `scm` (
  `scm_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `tab_name` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'Info',
  `content` text COLLATE latin1_general_ci,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`scm_id`),
  KEY `chdate` (`chdate`),
  KEY `range_id` (`range_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `scm`
--

INSERT INTO `scm` (`scm_id`, `range_id`, `user_id`, `tab_name`, `content`, `mkdate`, `chdate`) VALUES
('63863907e672f85e804de69a04d947c1', '834499e2b8a2cd71637890e5de31cba3', '205f3efb7997a0fc9755da2b535038da', 'Informationen', 'Wenn sie sich für ein Referatsthema anmelden möchten, ordnen Sie sich bitte selbst einer Referatsgruppe zu.\r\n\r\nSie finden diese Gruppen unter\r\n\r\n%%TeilnehmerInnen%%\r\n\r\nund dann \r\n\r\n%%Funktionen / Gruppen%%', 1194628681, 1194628711),
('1e6c94cdd7033ea745467df9fdfc5083', '834499e2b8a2cd71637890e5de31cba3', '205f3efb7997a0fc9755da2b535038da', 'Pfefferminz', 'Die Pfefferminze (Mentha x piperita) ist eine Heil- und beliebte Gewürzpflanze aus der Gattung der Minzen. Es ist eine Kreuzung zwischen M. aquatica x (und) M. spicata. 2004 wurde sie zur Arzneipflanze des Jahres gewählt.', 1194629051, 1194629136),
('ff6377bcdd342f248ba1fdb8fb8bf295', '0d2df6a71f3317549a5f2f252863c62b', '76ed43ef286fb55cf9e41beadb484a9f', 'Informationen', '', 1347366509, 1347366509);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `semester_data`
--

DROP TABLE IF EXISTS `semester_data`;
CREATE TABLE `semester_data` (
  `semester_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `semester_token` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `beginn` int(20) unsigned DEFAULT NULL,
  `ende` int(20) unsigned DEFAULT NULL,
  `vorles_beginn` int(20) unsigned DEFAULT NULL,
  `vorles_ende` int(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`semester_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `semester_data`
--

INSERT INTO `semester_data` (`semester_id`, `name`, `description`, `semester_token`, `beginn`, `ende`, `vorles_beginn`, `vorles_ende`) VALUES
('f2b4fdf5ac59a9cb57dd73c4d3bbb651', 'SS 2012', '', '', 1333231200, 1349042399, 1334527200, 1342821599),
('eb828ebb81bb946fac4108521a3b4697', 'WS 2011/12', '', '', 1317420000, 1333231199, 1318888800, 1329087599),
('a7845a9ceafd16335f276c6d88a72a90', 'WS 2012/13', '', '', 1351724400, 1364767199, 1352329200, 1359759599);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `semester_holiday`
--

DROP TABLE IF EXISTS `semester_holiday`;
CREATE TABLE `semester_holiday` (
  `holiday_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `semester_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `beginn` int(20) unsigned DEFAULT NULL,
  `ende` int(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`holiday_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `semester_holiday`
--

INSERT INTO `semester_holiday` (`holiday_id`, `semester_id`, `name`, `description`, `beginn`, `ende`) VALUES
('75a24d5f6f0c4f633d5293221629b9a6', '1', 'Weihnachtsferien 2011/2012', '', 1324594800, 1325631599);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `seminare`
--

DROP TABLE IF EXISTS `seminare`;
CREATE TABLE `seminare` (
  `Seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `VeranstaltungsNummer` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Institut_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `Name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Untertitel` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `status` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `Beschreibung` text COLLATE latin1_general_ci NOT NULL,
  `Ort` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Sonstiges` text COLLATE latin1_general_ci,
  `Passwort` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `Lesezugriff` tinyint(4) NOT NULL DEFAULT '0',
  `Schreibzugriff` tinyint(4) NOT NULL DEFAULT '0',
  `start_time` int(20) DEFAULT '0',
  `duration_time` int(20) DEFAULT NULL,
  `art` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `teilnehmer` text COLLATE latin1_general_ci,
  `vorrausetzungen` text COLLATE latin1_general_ci,
  `lernorga` text COLLATE latin1_general_ci,
  `leistungsnachweis` text COLLATE latin1_general_ci,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `ects` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `admission_endtime` int(20) DEFAULT NULL,
  `admission_turnout` int(5) DEFAULT NULL,
  `admission_binding` tinyint(4) DEFAULT NULL,
  `admission_type` int(3) NOT NULL DEFAULT '0',
  `admission_selection_take_place` tinyint(4) DEFAULT '0',
  `admission_group` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `admission_prelim` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `admission_prelim_txt` text COLLATE latin1_general_ci,
  `admission_starttime` int(20) NOT NULL DEFAULT '-1',
  `admission_endtime_sem` int(20) NOT NULL DEFAULT '-1',
  `admission_disable_waitlist` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `admission_enable_quota` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `showscore` tinyint(3) DEFAULT '0',
  `modules` int(10) unsigned DEFAULT NULL,
  `aux_lock_rule` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `lock_rule` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`Seminar_id`),
  KEY `Institut_id` (`Institut_id`),
  KEY `visible` (`visible`),
  KEY `status` (`status`,`Seminar_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `seminare`
--

INSERT INTO `seminare` (`Seminar_id`, `VeranstaltungsNummer`, `Institut_id`, `Name`, `Untertitel`, `status`, `Beschreibung`, `Ort`, `Sonstiges`, `Passwort`, `Lesezugriff`, `Schreibzugriff`, `start_time`, `duration_time`, `art`, `teilnehmer`, `vorrausetzungen`, `lernorga`, `leistungsnachweis`, `mkdate`, `chdate`, `ects`, `admission_endtime`, `admission_turnout`, `admission_binding`, `admission_type`, `admission_selection_take_place`, `admission_group`, `admission_prelim`, `admission_prelim_txt`, `admission_starttime`, `admission_endtime_sem`, `admission_disable_waitlist`, `admission_enable_quota`, `visible`, `showscore`, `modules`, `aux_lock_rule`, `lock_rule`) VALUES
('834499e2b8a2cd71637890e5de31cba3', '12345', '2560f7c7674942a7dce8eeb238e15d93', 'Test Lehrveranstaltung', 'eine normale Lehrveranstaltung', 1, '', '', '', '', 1, 1, 1317420000, 0, '', 'für alle Studierenden', 'abgeschlossenes Grundstudium', 'Referate in Gruppenarbeit', 'Klausur', 1240429345, 1311416105, '4', -1, 0, 0, 0, 0, '', 0, '', -1, -1, 0, 0, 1, 0, 20911, 'd34f75dbb9936ba300086e096b718242', NULL),
('7cb72dab1bf896a0b55c6aa7a70a3a86', '', 'ec2e364b28357106c0f8c282733dbe56', 'Test Studiengruppe', '', 99, 'Studiengruppen sind eine einfache Möglichkeit, mit KommilitonInnen, KollegInnen und anderen zusammenzuarbeiten. ', '', '', '', 1, 1, 1254348000, -1, '', '', '', '', '', 1268739824, 1268739824, '', -1, 0, NULL, 0, 0, NULL, 0, '', -1, -1, 0, 0, 1, 0, 395, NULL, NULL),
('c5ab3e6d39d8394837fb464c35bb61c5', '', 'ec2e364b28357106c0f8c282733dbe56', 'Externe Testveranstaltung', '', 29, '', '', '', NULL, 1, 1, 1333231200, 0, '', '', '', '', '', 1342421964, 1342421964, '', -1, 0, NULL, 0, 0, NULL, 0, '', -1, -1, 0, 0, 1, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `seminar_cycle_dates`
--

DROP TABLE IF EXISTS `seminar_cycle_dates`;
CREATE TABLE `seminar_cycle_dates` (
  `metadate_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `weekday` tinyint(3) unsigned NOT NULL,
  `description` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sws` decimal(2,1) NOT NULL DEFAULT '0.0',
  `cycle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `week_offset` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sorter` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mkdate` int(10) unsigned NOT NULL,
  `chdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`metadate_id`),
  KEY `seminar_id` (`seminar_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `seminar_cycle_dates`
--

INSERT INTO `seminar_cycle_dates` (`metadate_id`, `seminar_id`, `start_time`, `end_time`, `weekday`, `description`, `sws`, `cycle`, `week_offset`, `sorter`, `mkdate`, `chdate`) VALUES
('6e8564a271f9abd46a8f8e69acc7b89a', '834499e2b8a2cd71637890e5de31cba3', '10:00:00', '12:00:00', 1, 'Vorlesung', 0.0, 0, 0, 0, 1240429345, 1268739499),
('c6f297af47815b47d027a4403f9f67d0', '834499e2b8a2cd71637890e5de31cba3', '09:00:00', '11:00:00', 3, 'Übung', 0.0, 1, 1, 0, 1240429345, 1293119933);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `seminar_inst`
--

DROP TABLE IF EXISTS `seminar_inst`;
CREATE TABLE `seminar_inst` (
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `institut_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`seminar_id`,`institut_id`),
  KEY `institut_id` (`institut_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `seminar_inst`
--

INSERT INTO `seminar_inst` (`seminar_id`, `institut_id`) VALUES
('0d2df6a71f3317549a5f2f252863c62b', 'ec2e364b28357106c0f8c282733dbe56');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `seminar_sem_tree`
--

DROP TABLE IF EXISTS `seminar_sem_tree`;
CREATE TABLE `seminar_sem_tree` (
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sem_tree_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`seminar_id`,`sem_tree_id`),
  KEY `sem_tree_id` (`sem_tree_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `seminar_sem_tree`
--

INSERT INTO `seminar_sem_tree` (`seminar_id`, `sem_tree_id`) VALUES
('033aa1216de490d8c159cc7685c1545e', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('094611849abeb6802d2a6b9c09487fb7', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('09897cc623ad9343c706abbe959b352a', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('0be91274906754798389ce3b69a1c31a', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('0c9956f5cd0613da4d835e3ced9e17f2', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('0d2df6a71f3317549a5f2f252863c62b', '5b73e28644a3e259a6e0bc1e1499773c'),
('155cd8a11308f9edbea5b24c67baf322', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('183b8475309677846cd188474e801e44', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('233bc0c91de3aa95e34e6677dad87767', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('2fcc589419cf3a000503710128b53775', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('3249236c663b1c1d5b4718213d347fd1', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('3c631fe341c3d940b0e6fb2562c820d1', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('50745de7df3ad70d16f936db455e8723', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('67b21c54564a47018e7c2a85d32d9176', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('6d8bb465719151cc59f8284852446a22', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('6f94806751397fa628ab68895bac21e4', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('713f4c09e20c17deb5efe4a0dba2cee7', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('7c1cd2bd296ca642340c9533267fa5f1', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('7d784fb5cb9a5b187bfda24fd0f613dd', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('834499e2b8a2cd71637890e5de31cba3', '3d39528c1d560441fd4a8cb0b7717285'),
('834499e2b8a2cd71637890e5de31cba3', '5c41d2b4a5a8338e069dda987a624b74'),
('834499e2b8a2cd71637890e5de31cba3', 'dd7fff9151e85e7130cdb684edf0c370'),
('8771b22a7b29f451eebe4562906716fc', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('91c8337832f6441acc9cb329eaed894e', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('9598160de9b44d5d229eab2a0126cacc', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('a304c4ab0fc13fcb228561b7c4e1a198', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('a530b1c774210894b9e37a32e9152a5e', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('a8c0bf6f03107b71949c5cab556ee9e2', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('b03872c132ecbbfef7a7b19f5e1960ff', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('b9bbd675096a99de10e8a17e3148ee3a', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('c5ab3e6d39d8394837fb464c35bb61c5', '5c41d2b4a5a8338e069dda987a624b74'),
('d8cf16f630efea34ac9a20153f9577a7', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('e61b86bf81f6b1be356c347cc176e254', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('ebc30947f59bb2365b49e280ebbaa755', 'f0f778dffd827d3f64b0fd3cb0eaf90b'),
('f2ab41508e5e83490619ed3d1e560dae', '439618ae57d8c10dcaabcf7e21bcc1d9'),
('f6378bb616e3f1c51a660d5f99e0759c', 'f0f778dffd827d3f64b0fd3cb0eaf90b');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `seminar_user`
--

DROP TABLE IF EXISTS `seminar_user`;
CREATE TABLE `seminar_user` (
  `Seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `status` enum('user','autor','tutor','dozent') COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `position` int(11) NOT NULL DEFAULT '0',
  `gruppe` tinyint(4) NOT NULL DEFAULT '0',
  `admission_studiengang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `notification` int(10) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `comment` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `visible` enum('yes','no','unknown') COLLATE latin1_general_ci NOT NULL DEFAULT 'unknown',
  `label` varchar(128) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `bind_calendar` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`Seminar_id`,`user_id`),
  KEY `status` (`status`,`Seminar_id`),
  KEY `user_id` (`user_id`,`status`),
  KEY `Seminar_id` (`Seminar_id`,`admission_studiengang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `seminar_user`
--

INSERT INTO `seminar_user` (`Seminar_id`, `user_id`, `status`, `position`, `gruppe`, `admission_studiengang_id`, `notification`, `mkdate`, `comment`, `visible`, `label`, `bind_calendar`) VALUES
('834499e2b8a2cd71637890e5de31cba3', '205f3efb7997a0fc9755da2b535038da', 'dozent', 0, 2, '', 0, 1156516698, '', 'yes', '', 1),
('834499e2b8a2cd71637890e5de31cba3', '7e81ec247c151c02ffd479511e24cc03', 'tutor', 0, 2, '', 0, 1156516698, '', 'yes', '', 1),
('834499e2b8a2cd71637890e5de31cba3', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'autor', 0, 2, '', 0, 1156516698, '', 'yes', '', 1),
('7cb72dab1bf896a0b55c6aa7a70a3a86', 'e7a0a84b161f3e8c09b4a0a2e8a58147', 'dozent', 0, 8, '', 0, 0, '', 'unknown', '', 1),
('c5ab3e6d39d8394837fb464c35bb61c5', '205f3efb7997a0fc9755da2b535038da', 'dozent', 0, 4, '', 0, 1342421964, '', 'yes', '', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `seminar_userdomains`
--

DROP TABLE IF EXISTS `seminar_userdomains`;
CREATE TABLE `seminar_userdomains` (
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `userdomain_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`seminar_id`,`userdomain_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `seminar_userdomains`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sem_classes`
--

DROP TABLE IF EXISTS `sem_classes`;
CREATE TABLE `sem_classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `compact_mode` tinyint(4) NOT NULL,
  `workgroup_mode` tinyint(4) NOT NULL,
  `only_inst_user` tinyint(4) NOT NULL,
  `turnus_default` int(11) NOT NULL,
  `default_read_level` int(11) NOT NULL,
  `default_write_level` int(11) NOT NULL,
  `bereiche` tinyint(4) NOT NULL,
  `show_browse` tinyint(4) NOT NULL,
  `write_access_nobody` tinyint(4) NOT NULL,
  `topic_create_autor` tinyint(4) NOT NULL,
  `visible` tinyint(4) NOT NULL,
  `course_creation_forbidden` tinyint(4) NOT NULL,
  `overview` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `forum` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `admin` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `documents` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `schedule` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `participants` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `literature` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `chat` tinyint(4) NOT NULL,
  `scm` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `wiki` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `resources` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `calendar` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `elearning_interface` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `modules` text COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `create_description` text COLLATE latin1_general_ci NOT NULL,
  `studygroup_mode` tinyint(4) NOT NULL,
  `title_dozent` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `title_dozent_plural` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `title_tutor` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `title_tutor_plural` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `title_autor` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `title_autor_plural` varchar(64) COLLATE latin1_general_ci DEFAULT NULL,
  `mkdate` bigint(20) NOT NULL,
  `chdate` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=100 ;

--
-- Daten für Tabelle `sem_classes`
--

INSERT INTO `sem_classes` (`id`, `name`, `compact_mode`, `workgroup_mode`, `only_inst_user`, `turnus_default`, `default_read_level`, `default_write_level`, `bereiche`, `show_browse`, `write_access_nobody`, `topic_create_autor`, `visible`, `course_creation_forbidden`, `overview`, `forum`, `admin`, `documents`, `schedule`, `participants`, `literature`, `chat`, `scm`, `wiki`, `resources`, `calendar`, `elearning_interface`, `modules`, `description`, `create_description`, `studygroup_mode`, `title_dozent`, `title_dozent_plural`, `title_tutor`, `title_tutor_plural`, `title_autor`, `title_autor_plural`, `mkdate`, `chdate`) VALUES
(99, 'Studiengruppen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 'CoreOverview', 'CoreForum', 'CoreStudygroupAdmin', 'CoreDocuments', NULL, 'CoreStudygroupParticipants', 'CoreLiterature', 0, NULL, 'CoreWiki', NULL, NULL, NULL, '{"CoreOverview":{"activated":1,"sticky":1},"CoreStudygroupAdmin":{"activated":1,"sticky":1},"CoreStudygroupParticipants":{"activated":1,"sticky":1},"scm":{"activated":0,"sticky":1},"SurvivalTrainingPlugin":{"activated":0,"sticky":1},"Blubber":{"activated":0,"sticky":1}}', '', '', 1, 'GruppengründerIn', 'GruppengründerInnen', 'ModeratorIn', 'ModeratorInnen', 'Mitglied', 'Mitglieder', 1340189522, 1340189522),
(1, 'Lehre', 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 'CoreOverview', 'CoreForum', 'CoreAdmin', 'CoreDocuments', 'CoreSchedule', 'CoreParticipants', 'CoreLiterature', 1, 'CoreScm', 'CoreWiki', NULL, NULL, NULL, '{"CoreOverview":{"activated":"1","sticky":"1"},"CoreAdmin":{"activated":"1","sticky":"1"},"CoreForum":{"activated":"1","sticky":"0"},"CoreDocuments":{"activated":"1","sticky":"0"},"CoreParticipants":{"activated":"1","sticky":"0"},"CoreSchedule":{"activated":"1","sticky":"0"},"CoreLiterature":{"activated":"1","sticky":"0"},"CoreScm":{"activated":"1","sticky":"0"},"CoreWiki":{"activated":"1","sticky":"0"},"CampusConnect":{"activated":"0","sticky":"1"},"CampusConnectLink":{"activated":"0","sticky":"1"},"CoreStudygroupAdmin":{"activated":"0","sticky":"1"},"CoreStudygroupParticipants":{"activated":"0","sticky":"1"},"CoreResources":{"activated":"0","sticky":"1"},"CoreCalendar":{"activated":"0","sticky":"1"},"CoreElearningInterface":{"activated":"0","sticky":"1"},"Blubber":{"activated":"0","sticky":"1"}}', 'Hier finden Sie alle in Stud.IP registrierten Lehrveranstaltungen', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1340189522, 1352995643),
(2, 'Forschung', 1, 1, 1, 2, 2, 2, 1, 1, 0, 1, 1, 0, 'CoreOverview', 'CoreForum', 'CoreAdmin', 'CoreDocuments', 'CoreSchedule', 'CoreParticipants', 'CoreLiterature', 1, 'CoreScm', 'CoreWiki', NULL, NULL, NULL, '{"CoreOverview":{"activated":"1","sticky":"1"},"CoreAdmin":{"activated":"1","sticky":"1"},"CoreForum":{"activated":"1","sticky":"0"},"CoreDocuments":{"activated":"1","sticky":"0"},"CoreParticipants":{"activated":"1","sticky":"0"},"CoreSchedule":{"activated":"1","sticky":"0"},"CoreLiterature":{"activated":"1","sticky":"0"},"CoreScm":{"activated":"1","sticky":"0"},"CoreWiki":{"activated":"1","sticky":"0"},"CampusConnect":{"activated":"0","sticky":"1"},"CampusConnectLink":{"activated":"0","sticky":"1"},"CoreStudygroupAdmin":{"activated":"0","sticky":"1"},"CoreStudygroupParticipants":{"activated":"0","sticky":"1"},"CoreResources":{"activated":"0","sticky":"1"},"CoreCalendar":{"activated":"0","sticky":"1"},"CoreElearningInterface":{"activated":"0","sticky":"1"}}', 'Hier finden Sie virtuelle Veranstaltungen zum Thema Forschung an der Universit&auml;t', '', 0, 'Papst', 'Päpste', 'Kardinal', 'Kardinäle', 'Scherge', 'Schergen', 1340189522, 1352995679),
(3, 'Organisation', 1, 1, 0, -1, 2, 2, 1, 1, 1, 1, 1, 0, 'CoreOverview', 'CoreForum', 'CoreAdmin', 'CoreDocuments', 'CoreSchedule', 'CoreParticipants', 'CoreLiterature', 1, 'CoreScm', 'CoreWiki', NULL, NULL, NULL, '{"CoreOverview":{"activated":1,"sticky":1},"CoreAdmin":{"activated":1,"sticky":1}}', 'Hier finden Sie virtuelle Veranstaltungen zu verschiedenen Gremien an der Universit&auml;t', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1340189522, 1340189522),
(4, 'Community', 1, 0, 0, -1, 0, 0, 1, 0, 1, 0, 1, 0, 'CoreOverview', 'CoreForum', 'CoreAdmin', 'CoreDocuments', 'CoreSchedule', 'CoreParticipants', 'CoreLiterature', 1, 'CoreScm', 'CoreWiki', NULL, NULL, NULL, '{"CoreOverview":{"activated":1,"sticky":1},"CoreAdmin":{"activated":1,"sticky":1}}', 'Hier finden Sie virtuelle Veranstaltungen zu unterschiedlichen Themen', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1340189522, 1340189522),
(5, 'Arbeitsgruppen', 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 'CoreOverview', 'CoreForum', 'CoreAdmin', 'CoreDocuments', 'CoreSchedule', 'CoreParticipants', 'CoreLiterature', 1, 'CoreScm', 'CoreWiki', NULL, NULL, NULL, '{"CoreOverview":{"activated":1,"sticky":1},"CoreAdmin":{"activated":1,"sticky":1}}', 'Hier finden Sie verschiedene Arbeitsgruppen an der Stud.IP Trunk', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1340189522, 1340189522),
(6, 'importierte Kurse', 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 'CampusConnect', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, '{"CampusConnect":{"activated":"1","sticky":"1"},"CampusConnectLink":{"activated":"1","sticky":"1"},"CoreOverview":{"activated":"0","sticky":"1"},"CoreAdmin":{"activated":"0","sticky":"1"},"CoreForum":{"activated":"0","sticky":"1"},"CoreStudygroupAdmin":{"activated":"0","sticky":"1"},"CoreDocuments":{"activated":"0","sticky":"1"},"CoreSchedule":{"activated":"0","sticky":"1"},"CoreParticipants":{"activated":"0","sticky":"1"},"CoreStudygroupParticipants":{"activated":"0","sticky":"1"},"CoreLiterature":{"activated":"0","sticky":"1"},"CoreScm":{"activated":"0","sticky":"1"},"CoreWiki":{"activated":"0","sticky":"1"},"CoreResources":{"activated":"0","sticky":"1"},"CoreCalendar":{"activated":"0","sticky":"1"},"CoreElearningInterface":{"activated":"0","sticky":"1"}}', 'Hier finden Sie importierte Kurse', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1340189522, 1351592507);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sem_tree`
--

DROP TABLE IF EXISTS `sem_tree`;
CREATE TABLE `sem_tree` (
  `sem_tree_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `priority` tinyint(4) NOT NULL DEFAULT '0',
  `info` text COLLATE latin1_general_ci NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `studip_object_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`sem_tree_id`),
  KEY `parent_id` (`parent_id`),
  KEY `priority` (`priority`),
  KEY `studip_object_id` (`studip_object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `sem_tree`
--

INSERT INTO `sem_tree` (`sem_tree_id`, `parent_id`, `priority`, `info`, `name`, `studip_object_id`, `type`) VALUES
('5b73e28644a3e259a6e0bc1e1499773c', 'root', 1, '', '', '1535795b0d6ddecac6813f5f6ac47ef2', 0),
('439618ae57d8c10dcaabcf7e21bcc1d9', '5b73e28644a3e259a6e0bc1e1499773c', 0, '', 'Test Studienbereich A', NULL, 0),
('5c41d2b4a5a8338e069dda987a624b74', '5b73e28644a3e259a6e0bc1e1499773c', 1, '', 'Test Studienbereich B', NULL, 0),
('3d39528c1d560441fd4a8cb0b7717285', '439618ae57d8c10dcaabcf7e21bcc1d9', 0, '', 'Test Studienbereich A-1', NULL, 0),
('dd7fff9151e85e7130cdb684edf0c370', '439618ae57d8c10dcaabcf7e21bcc1d9', 1, '', 'Test Studienbereich A-2', NULL, 0),
('01c8b1d188be40c5ac64b54a01aae294', '5b73e28644a3e259a6e0bc1e1499773c', 2, '', 'Test Studienbereich C', NULL, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sem_types`
--

DROP TABLE IF EXISTS `sem_types`;
CREATE TABLE `sem_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `class` int(11) NOT NULL,
  `mkdate` bigint(20) NOT NULL,
  `chdate` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=100 ;

--
-- Daten für Tabelle `sem_types`
--

INSERT INTO `sem_types` (`id`, `name`, `class`, `mkdate`, `chdate`) VALUES
(1, 'Vorlesung', 1, 1340189522, 1340189522),
(2, 'Grundstudium', 1, 1340189522, 1340189522),
(3, 'Hauptstudium', 1, 1340189522, 1340189522),
(4, 'Seminar', 1, 1340189522, 1340189522),
(5, 'Praxisveranstaltung', 1, 1340189522, 1340189522),
(6, 'Kolloquium', 1, 1340189522, 1340189522),
(7, 'Forschungsgruppe', 1, 1340189522, 1340189522),
(8, 'Arbeitsgruppe', 5, 1340189522, 1340189522),
(9, 'sonstige', 1, 1340189522, 1340189522),
(10, 'Forschungsgruppe', 2, 1340189522, 1340189522),
(11, 'sonstige', 2, 1340189522, 1340189522),
(12, 'Gremiumsveranstaltung', 3, 1340189522, 1340189522),
(13, 'sonstige', 3, 1340189522, 1340189522),
(14, 'Community-Forum', 4, 1340189522, 1340189522),
(15, 'sonstige', 4, 1340189522, 1340189522),
(16, 'Praktikum', 1, 1340189522, 1340189522),
(19, 'Sprachkurs', 1, 1340189522, 1340189522),
(20, 'Fachdidaktik', 1, 1340189522, 1340189522),
(21, 'Übung', 1, 1340189522, 1340189522),
(22, 'Proseminar', 1, 1340189522, 1340189522),
(23, 'Oberseminar', 1, 1340189522, 1340189522),
(24, 'Arbeitsgemeinschaft', 1, 1340189522, 1340189522),
(25, 'Vorlesung', 6, 1340189522, 1340189522),
(26, 'Grundstudium', 6, 1340189522, 1340189522),
(27, 'Hauptstudium', 6, 1340189522, 1340189522),
(28, 'Seminar', 6, 1340189522, 1340189522),
(29, 'Praxisveranstaltung', 6, 1340189522, 1340189522),
(30, 'Kolloquium', 6, 1340189522, 1340189522),
(31, 'Forschungsgruppe', 6, 1340189522, 1340189522),
(99, 'Studiengruppe', 99, 1340189522, 1340189522);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `session_data`
--

DROP TABLE IF EXISTS `session_data`;
CREATE TABLE `session_data` (
  `sid` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `val` mediumtext COLLATE latin1_general_ci NOT NULL,
  `changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sid`),
  KEY `changed` (`changed`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `session_data`
--

INSERT INTO `session_data` (`sid`, `val`, `changed`) VALUES
('7eaf346459082b1077355b0dccde9a6e', 'auth|O:20:"Seminar_Default_Auth":2:{s:4:"auth";a:9:{s:3:"uid";s:32:"76ed43ef286fb55cf9e41beadb484a9f";s:4:"perm";s:4:"root";s:3:"exp";i:1355230924;s:7:"refresh";i:1355219462;s:5:"uname";s:11:"root@studip";s:7:"jscript";b:1;s:11:"auth_plugin";N;s:4:"xres";i:1280;s:4:"yres";i:1024;}s:9:"classname";s:20:"Seminar_Default_Auth";}forced_language|N;_language|s:5:"de_DE";SessionStart|i:1355219462;object_cache|a:0:{}_default_sem|s:32:"a7845a9ceafd16335f276c6d88a72a90";raumzeitFilter|s:0:"";security_token|s:44:"0Q2A+jpzKXMlB5K6TjTe2wFwwYqIikNv+hCupYhVL0Q=";QuickSearches|a:2:{s:32:"4bd38e19b87d8ff6d31555a367f0c8b3";a:3:{s:6:"object";s:386:"O:13:"SeminarSearch":2:{s:21:"\0SeminarSearch\0styles";a:3:{s:4:"name";s:4:"Name";s:11:"number-name";s:48:"TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name))";s:20:"number-name-lecturer";s:147:"CONCAT_WS('' '', TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name)), CONCAT(''('', GROUP_CONCAT(Nachname ORDER BY position,Nachname SEPARATOR '', ''),'')''))";}s:26:"\0SeminarSearch\0resultstyle";s:4:"name";}";s:11:"includePath";s:73:"/home/fuhse/campusconnect/lib/classes/searchtypes/SeminarSearch.class.php";s:4:"time";i:1355230924;}s:32:"3b03b1869c00161aaad5eba118544c92";a:3:{s:6:"object";s:511:"O:14:"StandardSearch":4:{s:22:"\0StandardSearch\0search";s:7:"user_id";s:6:"\0*\0sql";s:367:"SELECT DISTINCT auth_user_md5.user_id, CONCAT(auth_user_md5.Vorname, " ", auth_user_md5.Nachname, " (", auth_user_md5.username,")") FROM auth_user_md5 LEFT JOIN user_info ON (user_info.user_id = auth_user_md5.user_id) WHERE (CONCAT(auth_user_md5.Vorname, " ", auth_user_md5.Nachname) LIKE :input OR auth_user_md5.username LIKE :input) AND 1 ORDER BY Vorname, Nachname";s:13:"\0*\0avatarLike";s:7:"user_id";s:8:"\0*\0title";N;}";s:11:"includePath";s:74:"/home/fuhse/campusconnect/lib/classes/searchtypes/StandardSearch.class.php";s:4:"time";i:1355230855;}}vote_HTTP_REFERER_1|s:62:"http://server2.data-quest.de/campusconnect/index.php?again=yes";vote_HTTP_REFERER_2|N;trails_flash|O:12:"Trails_Flash":2:{s:5:"flash";a:0:{}s:4:"used";a:0:{}}', '2012-12-11 14:02:04'),
('d76a5f7aaa17e8b93a2685f2c9d851b4', 'auth|O:20:"Seminar_Default_Auth":2:{s:4:"auth";a:4:{s:3:"uid";s:6:"nobody";s:4:"perm";s:0:"";s:3:"exp";i:2147483647;s:7:"refresh";i:2147483647;}s:9:"classname";s:20:"Seminar_Default_Auth";}SessionStart|i:1355392929;object_cache|a:0:{}_language|s:5:"de_DE";raumzeitFilter|s:0:"";', '2012-12-13 11:02:09'),
('28bc6c40adf69a327e04504866361909', 'auth|O:20:"Seminar_Default_Auth":2:{s:4:"auth";a:9:{s:3:"uid";s:32:"76ed43ef286fb55cf9e41beadb484a9f";s:4:"perm";s:4:"root";s:3:"exp";i:1355393449;s:7:"refresh";i:1355393312;s:5:"uname";s:11:"root@studip";s:7:"jscript";b:1;s:11:"auth_plugin";N;s:4:"xres";i:1024;s:4:"yres";i:768;}s:9:"classname";s:20:"Seminar_Default_Auth";}forced_language|N;_language|s:5:"en_GB";SessionStart|i:1355393312;object_cache|a:0:{}_default_sem|s:32:"a7845a9ceafd16335f276c6d88a72a90";raumzeitFilter|s:0:"";security_token|s:44:"br0PmCGzM5vS3JmLY+KPJbzyWERBdkYtLraD0xq5pUI=";QuickSearches|a:2:{s:32:"4bd38e19b87d8ff6d31555a367f0c8b3";a:3:{s:6:"object";s:386:"O:13:"SeminarSearch":2:{s:21:"\0SeminarSearch\0styles";a:3:{s:4:"name";s:4:"Name";s:11:"number-name";s:48:"TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name))";s:20:"number-name-lecturer";s:147:"CONCAT_WS('' '', TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name)), CONCAT(''('', GROUP_CONCAT(Nachname ORDER BY position,Nachname SEPARATOR '', ''),'')''))";}s:26:"\0SeminarSearch\0resultstyle";s:4:"name";}";s:11:"includePath";s:73:"/home/fuhse/campusconnect/lib/classes/searchtypes/SeminarSearch.class.php";s:4:"time";i:1355393450;}s:32:"3b03b1869c00161aaad5eba118544c92";a:3:{s:6:"object";s:511:"O:14:"StandardSearch":4:{s:22:"\0StandardSearch\0search";s:7:"user_id";s:6:"\0*\0sql";s:367:"SELECT DISTINCT auth_user_md5.user_id, CONCAT(auth_user_md5.Vorname, " ", auth_user_md5.Nachname, " (", auth_user_md5.username,")") FROM auth_user_md5 LEFT JOIN user_info ON (user_info.user_id = auth_user_md5.user_id) WHERE (CONCAT(auth_user_md5.Vorname, " ", auth_user_md5.Nachname) LIKE :input OR auth_user_md5.username LIKE :input) AND 1 ORDER BY Vorname, Nachname";s:13:"\0*\0avatarLike";s:7:"user_id";s:8:"\0*\0title";N;}";s:11:"includePath";s:74:"/home/fuhse/campusconnect/lib/classes/searchtypes/StandardSearch.class.php";s:4:"time";i:1355393317;}}vote_HTTP_REFERER_1|s:62:"http://server2.data-quest.de/campusconnect/index.php?again=yes";vote_HTTP_REFERER_2|N;trails_flash|O:12:"Trails_Flash":2:{s:5:"flash";a:0:{}s:4:"used";a:0:{}}links_admin_data|a:4:{s:10:"select_old";b:1;s:8:"srch_sem";R:17;s:6:"sortby";s:20:"VeranstaltungsNummer";s:6:"topkat";s:3:"sem";}sem_create_data|s:0:"";admin_dates_data|s:0:"";', '2012-12-13 11:10:50'),
('c60c60c052118db5c718f8c8f89f2323', 'auth|O:20:"Seminar_Default_Auth":2:{s:4:"auth";a:9:{s:3:"uid";s:32:"76ed43ef286fb55cf9e41beadb484a9f";s:4:"perm";s:4:"root";s:3:"exp";i:1355410783;s:7:"refresh";i:1355410134;s:5:"uname";s:11:"root@studip";s:7:"jscript";b:1;s:11:"auth_plugin";N;s:4:"xres";i:1280;s:4:"yres";i:1024;}s:9:"classname";s:20:"Seminar_Default_Auth";}forced_language|N;_language|s:5:"de_DE";SessionStart|i:1355410134;object_cache|a:0:{}_default_sem|s:32:"a7845a9ceafd16335f276c6d88a72a90";raumzeitFilter|s:0:"";security_token|s:44:"hoGzeaH6a96Yt7Qtvsz8IhI1jQCswk2KrlvZJsPz/ow=";QuickSearches|a:2:{s:32:"4bd38e19b87d8ff6d31555a367f0c8b3";a:3:{s:6:"object";s:386:"O:13:"SeminarSearch":2:{s:21:"\0SeminarSearch\0styles";a:3:{s:4:"name";s:4:"Name";s:11:"number-name";s:48:"TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name))";s:20:"number-name-lecturer";s:147:"CONCAT_WS('' '', TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name)), CONCAT(''('', GROUP_CONCAT(Nachname ORDER BY position,Nachname SEPARATOR '', ''),'')''))";}s:26:"\0SeminarSearch\0resultstyle";s:4:"name";}";s:11:"includePath";s:73:"/home/fuhse/campusconnect/lib/classes/searchtypes/SeminarSearch.class.php";s:4:"time";i:1355410778;}s:32:"3b03b1869c00161aaad5eba118544c92";a:3:{s:6:"object";s:511:"O:14:"StandardSearch":4:{s:22:"\0StandardSearch\0search";s:7:"user_id";s:6:"\0*\0sql";s:367:"SELECT DISTINCT auth_user_md5.user_id, CONCAT(auth_user_md5.Vorname, " ", auth_user_md5.Nachname, " (", auth_user_md5.username,")") FROM auth_user_md5 LEFT JOIN user_info ON (user_info.user_id = auth_user_md5.user_id) WHERE (CONCAT(auth_user_md5.Vorname, " ", auth_user_md5.Nachname) LIKE :input OR auth_user_md5.username LIKE :input) AND 1 ORDER BY Vorname, Nachname";s:13:"\0*\0avatarLike";s:7:"user_id";s:8:"\0*\0title";N;}";s:11:"includePath";s:74:"/home/fuhse/campusconnect/lib/classes/searchtypes/StandardSearch.class.php";s:4:"time";i:1355410764;}}vote_HTTP_REFERER_1|s:43:"http://server2.data-quest.de/campusconnect/";vote_HTTP_REFERER_2|s:62:"http://server2.data-quest.de/campusconnect/index.php?again=yes";trails_flash|O:12:"Trails_Flash":2:{s:5:"flash";a:0:{}s:4:"used";a:0:{}}', '2012-12-13 15:59:43'),
('3b0282675baa60ded8bd0a3ef1270b1d', 'auth|O:20:"Seminar_Default_Auth":2:{s:4:"auth";a:9:{s:3:"uid";s:32:"76ed43ef286fb55cf9e41beadb484a9f";s:4:"perm";s:4:"root";s:3:"exp";i:1355310097;s:7:"refresh";i:1355303884;s:5:"uname";s:11:"root@studip";s:7:"jscript";b:1;s:11:"auth_plugin";N;s:4:"xres";i:1920;s:4:"yres";i:1080;}s:9:"classname";s:20:"Seminar_Default_Auth";}forced_language|N;_language|s:5:"de_DE";SessionStart|i:1355303884;object_cache|a:0:{}_default_sem|s:32:"a7845a9ceafd16335f276c6d88a72a90";raumzeitFilter|s:0:"";security_token|s:44:"mqUYQ/8ogaZAxmsqW5eH3Ku5nm3deG/PFvObFFytR4s=";QuickSearches|a:2:{s:32:"4bd38e19b87d8ff6d31555a367f0c8b3";a:3:{s:6:"object";s:386:"O:13:"SeminarSearch":2:{s:21:"\0SeminarSearch\0styles";a:3:{s:4:"name";s:4:"Name";s:11:"number-name";s:48:"TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name))";s:20:"number-name-lecturer";s:147:"CONCAT_WS('' '', TRIM(CONCAT_WS('' '', VeranstaltungsNummer, Name)), CONCAT(''('', GROUP_CONCAT(Nachname ORDER BY position,Nachname SEPARATOR '', ''),'')''))";}s:26:"\0SeminarSearch\0resultstyle";s:4:"name";}";s:11:"includePath";s:73:"/home/fuhse/campusconnect/lib/classes/searchtypes/SeminarSearch.class.php";s:4:"time";i:1355310037;}s:32:"9a918a6772140129da2ce080da3a557b";a:3:{s:6:"object";s:287:"O:13:"SemTreeSearch":3:{s:6:"\0*\0sql";s:190:"SELECT sem_tree_id, name FROM sem_tree WHERE name LIKE :input AND sem_tree_id NOT IN (SELECT DISTINCT mapped_sem_tree_id FROM campus_connect_tree_items WHERE mapped_sem_tree_id IS NOT NULL) ";s:13:"\0*\0avatarLike";s:0:"";s:8:"\0*\0title";s:0:"";}";s:11:"includePath";s:102:"/home/fuhse/campusconnect/public/plugins_packages/data-quest/CampusConnect/lib/SemTreeSearch.class.php";s:4:"time";i:1355303931;}}vote_HTTP_REFERER_1|s:62:"http://server2.data-quest.de/campusconnect/index.php?again=yes";vote_HTTP_REFERER_2|N;resources_data|s:92:"a:3:{s:4:"view";s:9:"resources";s:12:"search_array";s:0:"";s:20:"schedule_week_offset";i:0;}";links_admin_data|a:4:{s:10:"select_old";b:1;s:8:"srch_sem";R:17;s:6:"sortby";s:20:"VeranstaltungsNummer";s:6:"topkat";s:3:"sem";}sem_create_data|s:0:"";admin_dates_data|s:0:"";trails_flash|O:12:"Trails_Flash":2:{s:5:"flash";a:0:{}s:4:"used";a:0:{}}', '2012-12-12 12:01:37');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `siteinfo_details`
--

DROP TABLE IF EXISTS `siteinfo_details`;
CREATE TABLE `siteinfo_details` (
  `detail_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `rubric_id` smallint(5) unsigned NOT NULL,
  `position` tinyint(3) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `content` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`detail_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `siteinfo_details`
--

INSERT INTO `siteinfo_details` (`detail_id`, `rubric_id`, `position`, `name`, `content`) VALUES
(1, 1, NULL, '[lang=de]Ansprechpartner[/lang][lang=en]Contact[/lang]', '[style=float: right]\n[img]http://www.studip.de/images/studipanim.gif\n**Version:** (:version:)\n[/style]\n[lang=de]Für diese Stud.IP-Installation ((:uniname:)) sind folgende Administratoren zuständig:[/lang]\n[lang=en]The following administrators are responsible for this Stud.IP installation ((:uniname:)):[/lang]\n(:rootlist:)\n[lang=de]allgemeine Anfragen wie Passwort-Anforderungen u.a. richten Sie bitte an:[/lang]\n[lang=en]General queries e.g., password queries, please contact:[/lang]\n(:unicontact:)\n[lang=de]Folgende Einrichtungen sind beteiligt:\n(Genannt werden die jeweiligen Administratoren der Einrichtungen für entsprechende Anfragen)[/lang]\n[lang=en]The following institutes participate:\n(Named are the institutes administrators responsible for the corresponding query areas)[/lang]\n(:adminlist:)'),
(2, 1, NULL, '[lang=de]Entwickler[/lang][lang=en]Developer[/lang]', '[style=float: right]\n[img]http://www.studip.de/images/studipanim.gif\n**Version:** (:version:)\n[/style]\n[lang=de]Stud.IP ist ein Open Source Projekt zur Unterstützung von Präsenzlehre an Universitäten, Hochschulen und anderen Bildungseinrichtungen. Das System entstand am Zentrum für interdisziplinäre Medienwissenschaft (ZiM) der Georg-August-Universität Göttingen unter Mitwirkung der Suchi & Berg GmbH (data-quest) , Göttingen. Heute erfolgt die Weiterentwicklung von Stud.IP verteilt an vielen Standorten (Göttingen, Osnabrück, Oldenburg, Bremen, Hannover, Jena und weiteren). Die Koordination der Entwicklung erfolgt durch die Stud.IP-CoreGroup.\nStud.IP steht unter der GNU General Public License, Version 2.\n\nWeitere Informationen finden sie auf [**www.studip.de**]http://www.studip.de , [**develop.studip.de**]http://develop.studip.de und [**blog.studip.de**]http://blog.studip.de.[/lang]\n\n[lang=en]Stud.IP is an opensource project for supporting attendance courses offered by universities, institutions of higher education and other educational institutions. The system was established at the Zentrum für interdisziplinäre Medienwissenschaft (ZiM) in the Georg-August-Universität Göttingen in cooperation with Suchi & Berg GmbH (data-quest) , Göttingen. At the present further developing takes place at various locations (among others Göttingen, Osnabrück, Oldenburg, Bremen, Hannover, Jena) under coordination through the Stud.IP-CoreGroup.\n\nStud.IP is covered by the GNU General Public Licence, version 2.\n\nFurther information can be found under [**www.studip.de**]http://www.studip.de , [**develop.studip.de**]http://develop.studip.de and [**blog.studip.de**]http://blog.studip.de.[/lang]\n\n(:coregroup:)\n[lang=de]Sie erreichen uns auch über folgende **Mailinglisten**:\n\n**Nutzer-Anfragen**, E-Mail: studip-users@lists.sourceforge.net: Fragen, Anregungen und Vorschläge an die Entwickler - bitte __keine__ Passwort Anfragen!\n**News-Mailingsliste**, E-Mail: studip-news@lists.sourceforge.net: News rund um Stud.IP (Eintragung notwendig)\n\nWir laden alle Entwickler, Betreiber und Nutzer von Stud.IP ein, sich auf dem Developer-Server http://develop.studip.de an den Diskussionen rund um die Weiterentwicklung und Nutzung der Plattform zu beteiligen.[/lang]\n[lang=en]You can contact us via the following **mailing lists**:\n\n**User enquiries**, E-Mail: studip-users@lists.sourceforge.net: Questions, suggestions and recommendations to the developers - __please no password queries__!\n\n**News mailing list**, E-Mail: studip-news@lists.sourceforge.net: News about Stud.IP (registration necessary)\n\nWe invite all developers, administrators and users of Stud.IP to join the discussions on further developing and using the platform available at the developer server http://develop.studip.de[/lang]'),
(3, 2, NULL, '[lang=de]Technik[/lang][lang=en]Technology[/lang]', '[style=float: right]\n[img]http://www.studip.de/images/studipanim.gif\n**Version:** (:version:)\n[/style]\n[lang=de]Stud IP ist ein Open-Source Projekt und steht unter der GNU General Public License. Sämtliche zum Betrieb notwendigen Dateien können unter http://sourceforge.net/projects/studip/ heruntergeladen werden.\nDie technische Grundlage bietet ein LINUX-System mit Apache Webserver sowie eine MySQL Datenbank, die über PHP gesteuert wird.\nIm System findet ein 6-stufiges Rechtesystem Verwendung, das individuell auf verschiedenen Ebenen wirkt - etwa in Veranstaltungen, Einrichtungen, Fakultäten oder systemweit.\nSeminare oder Arbeitsgruppen können mit Passwörtern geschützt werden - die Verschlüsselung erfolgt mit einem MD5 one-way-hash.\nDas System ist zu 100% über das Internet administrierbar, es sind keine zusätzlichen Werkzeuge nötig. Ein Webbrowser der 5. Generation wird empfohlen.\nDas System wird ständig weiterentwickelt und an die Wünsche unserer Nutzer angepasst - [sagen Sie uns Ihre Meinung!]studip-users@lists.sourceforge.net[/lang]\n[lang=en]Stud.IP is an Open Source Project and is covered by the Gnu General Public License (GPL). All files necessary for operation can be downloaded from http://sourceforge.net/projects/studip/ .\nThe technical basis can be provided by a LINUX system with Apache Webserver and a MySQL database, which is then controlled by PHP.\nThe system features a authorisation system with six ranks, that affects individually different levels - in courses, institutes,faculties or system wide.\nSeminars or work groups can be secured with passwords - the encryption of which uses a MD5 one-way-hash.\nThe system is capable of being administrated 100% over the internet - no additional tools are necessary. A 5th generation web browser is recommended.\nThe system is continually being developed and customised to the wishes of our users - [Tell us your opinion!]studip-users@lists.sourceforge.net[/lang]'),
(4, 2, NULL, '[lang=de]Statistik[/lang][lang=en]Statistics[/lang]', '[lang=de]!!Top-Listen aller Veranstaltungen[/lang][lang=en]!!Top list of all courses[/lang]\n[style=float: right]\n[lang=de]!!Statistik[/lang][lang=en]!!statistics[/lang]\n(:indicator seminar_all:)\n(:indicator seminar_archived:)\n(:indicator institute_firstlevel_all:)\n(:indicator institute_secondlevel_all:)\n(:indicator user_admin:)\n(:indicator user_dozent:)\n(:indicator user_tutor:)\n(:indicator user_autor:)\n(:indicator posting:)\n(:indicator document:)\n(:indicator link:)\n(:indicator litlist:)\n(:indicator termin:)\n(:indicator news:)\n(:indicator guestbook:)\n(:indicator vote:)\n(:indicator test:)\n(:indicator evaluation:)\n(:indicator wiki_pages:)\n(:indicator lernmodul:)\n(:indicator resource:)\n[/style]\n(:toplist mostparticipants:)\n(:toplist recentlycreated:)\n(:toplist mostdocuments:)\n(:toplist mostpostings:)\n(:toplist mostvisitedhomepages:)'),
(5, 2, NULL, 'History', '(:history:)'),
(6, 2, NULL, 'Stud.IP-Blog', '[lang=de]Das Blog der Stud.IP-Entwickler finden Sie auf:[/lang]\n[lang=en]The Stud.IP-Developer-Blog can be found under:[/lang]\nhttp://blog.studip.de');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `siteinfo_rubrics`
--

DROP TABLE IF EXISTS `siteinfo_rubrics`;
CREATE TABLE `siteinfo_rubrics` (
  `rubric_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `position` tinyint(3) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`rubric_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `siteinfo_rubrics`
--

INSERT INTO `siteinfo_rubrics` (`rubric_id`, `position`, `name`) VALUES
(1, NULL, '[lang=de]Kontakt[/lang][lang=en]Contact[/lang]'),
(2, NULL, '[lang=de]Über Stud.IP[/lang][lang=en]About Stud.IP[/lang]');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `smiley`
--

DROP TABLE IF EXISTS `smiley`;
CREATE TABLE `smiley` (
  `smiley_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `smiley_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `smiley_width` int(11) NOT NULL DEFAULT '0',
  `smiley_height` int(11) NOT NULL DEFAULT '0',
  `short_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `smiley_counter` int(11) unsigned NOT NULL DEFAULT '0',
  `short_counter` int(11) unsigned NOT NULL DEFAULT '0',
  `fav_counter` int(11) unsigned NOT NULL DEFAULT '0',
  `mkdate` int(10) unsigned DEFAULT NULL,
  `chdate` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`smiley_id`),
  UNIQUE KEY `name` (`smiley_name`),
  KEY `short` (`short_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `smiley`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `statusgruppen`
--

DROP TABLE IF EXISTS `statusgruppen`;
CREATE TABLE `statusgruppen` (
  `statusgruppe_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `position` int(20) NOT NULL DEFAULT '0',
  `size` int(20) NOT NULL DEFAULT '0',
  `selfassign` tinyint(4) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `calendar_group` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`statusgruppe_id`),
  KEY `range_id` (`range_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `statusgruppen`
--

INSERT INTO `statusgruppen` (`statusgruppe_id`, `name`, `range_id`, `position`, `size`, `selfassign`, `mkdate`, `chdate`, `calendar_group`) VALUES
('86498c641ccf4f4d4e02f4961ccc3829', 'Lehrbeauftragte', '2560f7c7674942a7dce8eeb238e15d93', 3, 0, 0, 1156516698, 1156516698, 0),
('600403561c21a50ae8b4d41655bd2191', 'HochschullehrerIn', '2560f7c7674942a7dce8eeb238e15d93', 4, 0, 0, 1156516698, 1156516698, 0),
('efb56e092f33cb78a8766676042dc1c5', 'wiss. MitarbeiterIn', '2560f7c7674942a7dce8eeb238e15d93', 2, 0, 0, 1156516698, 1156516698, 0),
('5d40b1fc0434e6589d7341a3ee742baf', 'DirektorIn', '2560f7c7674942a7dce8eeb238e15d93', 1, 0, 0, 1156516698, 1156516698, 0),
('41ad59c9b6cdafca50e42fe6bc68af4f', 'Thema 1', '834499e2b8a2cd71637890e5de31cba3', 2, 3, 2, 1194628738, 1194629392, 0),
('151c33059a90b6138d280862f5d4b3c2', 'Thema 2', '834499e2b8a2cd71637890e5de31cba3', 3, 3, 2, 1194628768, 1194628768, 0),
('a5061826bf8db7487a774f92ce2a4d23', 'Thema 3', '834499e2b8a2cd71637890e5de31cba3', 4, 3, 2, 1194628789, 1194628789, 0),
('ee5764d68c795815c9dd8b2448313fb6', 'DozentInnen', '834499e2b8a2cd71637890e5de31cba3', 1, 0, 0, 1194628816, 1194628816, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `statusgruppe_user`
--

DROP TABLE IF EXISTS `statusgruppe_user`;
CREATE TABLE `statusgruppe_user` (
  `statusgruppe_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `visible` tinyint(4) NOT NULL DEFAULT '1',
  `inherit` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`statusgruppe_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `statusgruppe_user`
--

INSERT INTO `statusgruppe_user` (`statusgruppe_id`, `user_id`, `position`, `visible`, `inherit`) VALUES
('efb56e092f33cb78a8766676042dc1c5', '7e81ec247c151c02ffd479511e24cc03', 1, 1, 1),
('5d40b1fc0434e6589d7341a3ee742baf', '205f3efb7997a0fc9755da2b535038da', 1, 1, 1),
('ee5764d68c795815c9dd8b2448313fb6', '205f3efb7997a0fc9755da2b535038da', 1, 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_abstract`
--

DROP TABLE IF EXISTS `stm_abstract`;
CREATE TABLE `stm_abstract` (
  `stm_abstr_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `id_number` varchar(10) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'alphanummerische Identifikationsnummer für das Modul',
  `duration` varchar(155) COLLATE latin1_general_ci DEFAULT NULL,
  `credits` tinyint(3) unsigned DEFAULT NULL COMMENT 'Anzahl der Leistungspunkte/Kreditpunkte',
  `workload` smallint(6) unsigned DEFAULT NULL COMMENT 'Studentischer Arbeitsaufwand in Stunden',
  `turnus` tinyint(1) DEFAULT NULL COMMENT '(optional) Angebotsturnus - Modulbeginn',
  `mkdate` int(20) DEFAULT NULL COMMENT 'Erstellungdatum',
  `chdate` int(20) DEFAULT NULL COMMENT 'Datum der letzten Aenderung',
  `homeinst` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`stm_abstr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='abstrakte Module';

--
-- Daten für Tabelle `stm_abstract`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_abstract_assign`
--

DROP TABLE IF EXISTS `stm_abstract_assign`;
CREATE TABLE `stm_abstract_assign` (
  `stm_abstr_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `stm_type_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines Modultyps',
  `abschl` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines Studienabschlusses',
  `stg` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines Studienprogramms/-fachs',
  `pversion` varchar(8) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'Version der Prüfungsordnung',
  `earliest` tinyint(4) DEFAULT NULL COMMENT 'frührester Zeitpunkt (Semester)',
  `latest` tinyint(4) DEFAULT NULL COMMENT 'spätester Zpkt.',
  `recommed` tinyint(4) DEFAULT NULL COMMENT 'empfohlener Zpkt.',
  PRIMARY KEY (`stm_abstr_id`,`abschl`,`stg`,`pversion`),
  KEY `studycourse` (`abschl`,`stg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Zuordnung abstrakte Module <-> Studienprogramme';

--
-- Daten für Tabelle `stm_abstract_assign`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_abstract_elements`
--

DROP TABLE IF EXISTS `stm_abstract_elements`;
CREATE TABLE `stm_abstract_elements` (
  `element_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines abstrakten Modulbestandzeiles',
  `stm_abstr_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines abstrakten Studienmodules',
  `element_type_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'um welche Art von Element handelt es sich',
  `custom_name` varchar(50) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'selbstgewählter Name',
  `sws` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Semesterwochenstunden für den Bestandteil',
  `workload` int(4) NOT NULL DEFAULT '0',
  `semester` tinyint(1) DEFAULT NULL COMMENT 'Sommer od. Winter (Sommer = 1; Winter = 2)',
  `elementgroup` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Kombinationsvariante',
  `position` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Reihenfolge ',
  PRIMARY KEY (`element_id`),
  UNIQUE KEY `elem_integr` (`stm_abstr_id`,`elementgroup`,`position`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Bestandteile eines Abstrakten Moduls (Elemente)';

--
-- Daten für Tabelle `stm_abstract_elements`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_abstract_text`
--

DROP TABLE IF EXISTS `stm_abstract_text`;
CREATE TABLE `stm_abstract_text` (
  `stm_abstr_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID des abstrakten Studienmodules',
  `lang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID der verwendeten Sprache',
  `title` varchar(155) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'Allgemeiner Modultitel (Name des Moduls)',
  `subtitle` varchar(155) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'optionaler Untertitel',
  `topics` text COLLATE latin1_general_ci NOT NULL COMMENT 'Inhalte (behandelte Themen etc.)',
  `aims` text COLLATE latin1_general_ci NOT NULL COMMENT 'Lernziele',
  `hints` text COLLATE latin1_general_ci,
  PRIMARY KEY (`stm_abstr_id`,`lang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='(mehrsprachige) Texte der abstrakten Module';

--
-- Daten für Tabelle `stm_abstract_text`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_abstract_types`
--

DROP TABLE IF EXISTS `stm_abstract_types`;
CREATE TABLE `stm_abstract_types` (
  `stm_type_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines Modultyps',
  `lang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID der verwendeten Sprache',
  `abbrev` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'Abkuerzung',
  `name` varchar(25) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'vollstaendige Bezeichnung',
  PRIMARY KEY (`stm_type_id`,`lang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Typen abstrakter Module';

--
-- Daten für Tabelle `stm_abstract_types`
--

INSERT INTO `stm_abstract_types` (`stm_type_id`, `lang_id`, `abbrev`, `name`) VALUES
('60640019ff7fad25e4d1e547df00cd3f', '09c438e63455e3e1b3deabe65fdbc087', 'WP', 'Wahpflichtmodul'),
('ce7bbf737a61097a9d309174f13e3525', '09c438e63455e3e1b3deabe65fdbc087', 'P', 'Pflichtmodul');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_element_types`
--

DROP TABLE IF EXISTS `stm_element_types`;
CREATE TABLE `stm_element_types` (
  `element_type_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID des Modulbestandteils',
  `lang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID der verwendeten Sprache',
  `abbrev` varchar(5) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'Kurzname',
  `name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'Name',
  PRIMARY KEY (`element_type_id`,`lang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Typen von möglichen Bestandteilen eines abstrakten Moduls';

--
-- Daten für Tabelle `stm_element_types`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_instances`
--

DROP TABLE IF EXISTS `stm_instances`;
CREATE TABLE `stm_instances` (
  `stm_instance_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines konkreten Studienmodules',
  `stm_abstr_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines abstrakten Studienmodules',
  `semester_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID des ersten Semesters in dem die Instanz stattfindet',
  `lang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID der Sprache in der das Modul angeboten wird',
  `homeinst` varchar(32) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'ID des anbietenden Institutes',
  `creator` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `responsible` varchar(32) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'ID des Modulverantwortlichen Dozenten',
  `complete` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Erfassung komplett (0=FALSE)',
  PRIMARY KEY (`stm_instance_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Instanzen der abstrakten Module';

--
-- Daten für Tabelle `stm_instances`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_instances_elements`
--

DROP TABLE IF EXISTS `stm_instances_elements`;
CREATE TABLE `stm_instances_elements` (
  `stm_instance_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines konkreten Studienmodules',
  `element_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID des abstrakten Modulbestandteils',
  `sem_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID der konkreten Veranstaltung',
  PRIMARY KEY (`stm_instance_id`,`element_id`,`sem_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `stm_instances_elements`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stm_instances_text`
--

DROP TABLE IF EXISTS `stm_instances_text`;
CREATE TABLE `stm_instances_text` (
  `stm_instance_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID eines konkreten Studienmodules',
  `lang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'ID der verwendeten Sprache',
  `title` varchar(155) COLLATE latin1_general_ci NOT NULL DEFAULT '' COMMENT 'Allgemeiner Modultitel',
  `subtitle` varchar(155) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'optionaler Untertitel',
  `topics` text COLLATE latin1_general_ci NOT NULL COMMENT 'Inhalte',
  `hints` text COLLATE latin1_general_ci,
  PRIMARY KEY (`stm_instance_id`,`lang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='(mehrsprachige) Texte der instanziierten abstrakten Module';

--
-- Daten für Tabelle `stm_instances_text`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `studiengaenge`
--

DROP TABLE IF EXISTS `studiengaenge`;
CREATE TABLE `studiengaenge` (
  `studiengang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `beschreibung` text COLLATE latin1_general_ci,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`studiengang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `studiengaenge`
--

INSERT INTO `studiengaenge` (`studiengang_id`, `name`, `beschreibung`, `mkdate`, `chdate`) VALUES
('f981c9b42ca72788a09da4a45794a737', 'Informatik', '', 1311416397, 1311416397),
('6b9ac09535885ca55e29dd011e377c0a', 'Geschichte', '', 1311416418, 1311416418);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `teilnehmer_view`
--

DROP TABLE IF EXISTS `teilnehmer_view`;
CREATE TABLE `teilnehmer_view` (
  `datafield_id` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seminar_id` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `active` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`datafield_id`,`seminar_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `teilnehmer_view`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `termine`
--

DROP TABLE IF EXISTS `termine`;
CREATE TABLE `termine` (
  `termin_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `autor_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `content` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci,
  `date` int(20) NOT NULL DEFAULT '0',
  `end_time` int(20) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `date_typ` tinyint(4) NOT NULL DEFAULT '0',
  `topic_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `raum` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `metadate_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`termin_id`),
  KEY `metadate_id` (`metadate_id`,`date`),
  KEY `range_id` (`range_id`,`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `termine`
--

INSERT INTO `termine` (`termin_id`, `range_id`, `autor_id`, `content`, `description`, `date`, `end_time`, `mkdate`, `chdate`, `date_typ`, `topic_id`, `raum`, `metadate_id`) VALUES
('cc04c7bd4b0259b8968402d8ce85b4cc', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1322035200, 1322042400, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('103a7c9a1a9433494f979dcd1c654742', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1323244800, 1323252000, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('914976ace65274dabe4a3812167fe37e', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1324454400, 1324461600, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('26125eb9fa17efa3947f4c0b1a7a8600', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1325664000, 1325671200, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('157f8605ad389c7b59d8437bcd7a5a54', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1326873600, 1326880800, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('67f1c5cc5a38779c1f09ab60699452d7', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1329120000, 1329134400, 1258026662, 1326810622, 3, NULL, '', NULL),
('2c9a2628f2ba40c3fef4542c871da912', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1328083200, 1328090400, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('e41ef4b756e5d12c2fc41148fa234a10', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1319443200, 1319450400, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('a9997a4cb099f2af24d7f511dc50141b', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1320051600, 1320058800, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('eeeb9bf048703cedeb3b939608bd4404', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1320656400, 1320663600, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('df52bb52be086a5e53131fa4cb4ce283', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1321261200, 1321268400, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('739c57d3acd8fb6aa04b58518b070260', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1321866000, 1321873200, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('fdb2712dedb8a2aa1b06ede975688352', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1322470800, 1322478000, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('edc6d7bf127f8b18f70208f39194c3e9', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1323075600, 1323082800, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('56ff28275c6527a8132f9dabee3350a9', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1323680400, 1323687600, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('ffe9e79ed927ca1a2133386c43ec7d3d', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1324285200, 1324292400, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('1944327eb9b4a904b9e9792685bbe995', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1326099600, 1326106800, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('5c7581d917d87ed05ee971ad3c5051bd', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1326704400, 1326711600, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('d79c261e0e25ec52931b69c213439cfd', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1327309200, 1327316400, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('0d5b5638eb568c5cd7c89ca90352c400', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1327914000, 1327921200, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('0e686bda235739042215c437f8324a3d', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1328518800, 1328526000, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('5dc85e7b934206c2e7bae0d139ec1a4e', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1319612400, 1319619600, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('7ac48037d6103c29e29abea65c9e6c85', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1320825600, 1320832800, 1311416105, 1311416105, 1, NULL, '', 'c6f297af47815b47d027a4403f9f67d0'),
('cdb0b2f7c3977a78c780b03d3f189bc9', '834499e2b8a2cd71637890e5de31cba3', '76ed43ef286fb55cf9e41beadb484a9f', '', NULL, 1318838400, 1318845600, 1311416105, 1311416105, 1, NULL, '', '6e8564a271f9abd46a8f8e69acc7b89a'),
('4973bed3b30481633cc72ac8d1dbe106', 'd8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'CampusConnect', NULL, 1336550400, 1336559400, 1348473293, 1353331222, 1, NULL, '', NULL),
('5a9822b38256ae11d1992c138ffe712e', 'd8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'CampusConnect', NULL, 1337760000, 1337769000, 1348473293, 1353331222, 1, NULL, '', NULL),
('452a9e173be3058ca1000b8b0b5b1fe9', 'd8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'CampusConnect', NULL, 1338969600, 1338978600, 1348473293, 1353331222, 1, NULL, '', NULL),
('65603a5a0a84eb9d224a69f01db49a19', 'd8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'CampusConnect', NULL, 1340179200, 1340188200, 1348473293, 1353331222, 1, NULL, '', NULL),
('27eb9c4b54fc701a53596e971c7840f2', 'd8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'CampusConnect', NULL, 1341388800, 1341397800, 1348473293, 1353331222, 1, NULL, '', NULL),
('a8fc9c5fc5eab952045be3b62361cde7', 'd8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'CampusConnect', NULL, 1335340800, 1335349800, 1348473293, 1353331222, 1, NULL, '', NULL),
('2117ea70ef2a00f98bde80da41bf6982', 'd8cf16f630efea34ac9a20153f9577a7', '76ed43ef286fb55cf9e41beadb484a9f', 'CampusConnect', NULL, 1342598400, 1342607400, 1348473293, 1353331222, 1, NULL, '', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `termin_related_persons`
--

DROP TABLE IF EXISTS `termin_related_persons`;
CREATE TABLE `termin_related_persons` (
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`range_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `termin_related_persons`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `themen`
--

DROP TABLE IF EXISTS `themen`;
CREATE TABLE `themen` (
  `issue_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seminar_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `author_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  `priority` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mkdate` int(10) unsigned NOT NULL DEFAULT '0',
  `chdate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`issue_id`),
  KEY `seminar_id` (`seminar_id`,`priority`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `themen`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `themen_termine`
--

DROP TABLE IF EXISTS `themen_termine`;
CREATE TABLE `themen_termine` (
  `issue_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `termin_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`issue_id`,`termin_id`),
  KEY `termin_id` (`termin_id`,`issue_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `themen_termine`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userdomains`
--

DROP TABLE IF EXISTS `userdomains`;
CREATE TABLE `userdomains` (
  `userdomain_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`userdomain_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `userdomains`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_config`
--

DROP TABLE IF EXISTS `user_config`;
CREATE TABLE `user_config` (
  `userconfig_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parent_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `value` text COLLATE latin1_general_ci NOT NULL,
  `mkdate` int(11) NOT NULL DEFAULT '0',
  `chdate` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`userconfig_id`),
  KEY `user_id` (`user_id`,`field`,`value`(5))
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `user_config`
--

INSERT INTO `user_config` (`userconfig_id`, `parent_id`, `user_id`, `field`, `value`, `mkdate`, `chdate`, `comment`) VALUES
('3fa22f5fde0adbbcbaafd6459550dab9', NULL, '76ed43ef286fb55cf9e41beadb484a9f', 'LINKS_ADMIN', 'VeranstaltungsNummer', 1342422010, 1342422010, ''),
('b16358df139300642c824c4517f15f5f', NULL, '76ed43ef286fb55cf9e41beadb484a9f', 'LINKS_ADMIN_SHOW_ROOMS', 'off', 1342422010, 1342422010, '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_data`
--

DROP TABLE IF EXISTS `user_data`;
CREATE TABLE `user_data` (
  `sid` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `val` mediumtext COLLATE latin1_general_ci NOT NULL,
  `changed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sid`),
  KEY `changed` (`changed`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `user_data`
--

INSERT INTO `user_data` (`sid`, `val`, `changed`) VALUES
('76ed43ef286fb55cf9e41beadb484a9f', 'a:9:{s:12:"CurrentLogin";i:1355410134;s:9:"LastLogin";i:1355393312;s:5:"forum";a:10:{s:9:"themeview";s:4:"tree";s:10:"presetview";s:4:"tree";s:10:"sortthemes";s:3:"asc";s:4:"view";s:4:"tree";s:6:"search";s:0:"";s:4:"sort";s:3:"age";s:9:"indikator";s:3:"age";s:6:"anchor";N;s:6:"update";N;s:5:"zitat";N;}s:21:"my_messaging_settings";a:16:{s:16:"show_only_buddys";b:0;s:28:"delete_messages_after_logout";b:0;s:26:"start_messenger_at_startup";b:0;s:14:"default_setted";i:1340616269;s:10:"last_login";b:0;s:10:"timefilter";s:3:"30d";s:7:"opennew";i:1;s:17:"logout_markreaded";b:0;s:7:"openall";s:1:"2";s:12:"addsignature";b:0;s:8:"save_snd";i:1;s:7:"sms_sig";b:0;s:9:"send_view";b:0;s:14:"last_box_visit";i:1352299790;s:6:"folder";a:2:{s:2:"in";a:1:{i:0;s:5:"dummy";}s:3:"out";a:1:{i:0;s:5:"dummy";}}s:15:"confirm_reading";i:3;}s:20:"my_schedule_settings";a:4:{s:14:"glb_start_time";i:8;s:12:"glb_end_time";i:19;s:8:"glb_days";a:7:{s:2:"mo";s:4:"TRUE";s:2:"di";s:4:"TRUE";s:2:"mi";s:4:"TRUE";s:2:"do";s:4:"TRUE";s:2:"fr";s:4:"TRUE";s:2:"sa";s:0:"";s:2:"so";s:0:"";}s:14:"default_setted";i:1340616269;}s:16:"my_personal_sems";N;s:18:"my_studip_settings";N;s:18:"homepage_cache_own";i:1351155872;s:26:"calendar_user_control_data";a:12:{s:4:"view";s:8:"showweek";s:5:"start";i:9;s:3:"end";i:20;s:8:"step_day";i:900;s:9:"step_week";i:3600;s:9:"type_week";s:4:"LONG";s:8:"holidays";b:1;s:8:"sem_data";b:1;s:9:"link_edit";b:1;s:13:"bind_seminare";s:0:"";s:16:"ts_bind_seminare";i:0;s:6:"delete";i:0;}}', '2012-12-13 15:59:43'),
('7e81ec247c151c02ffd479511e24cc03', 'a:11:{s:12:"CurrentLogin";i:1353682130;s:9:"LastLogin";i:1352977804;s:5:"forum";N;s:21:"my_messaging_settings";a:16:{s:16:"show_only_buddys";b:0;s:28:"delete_messages_after_logout";b:0;s:26:"start_messenger_at_startup";b:0;s:14:"default_setted";i:1348143571;s:10:"last_login";b:0;s:10:"timefilter";s:3:"30d";s:7:"opennew";i:1;s:17:"logout_markreaded";b:0;s:7:"openall";b:0;s:12:"addsignature";b:0;s:8:"save_snd";i:1;s:7:"sms_sig";b:0;s:9:"send_view";b:0;s:14:"last_box_visit";i:1;s:6:"folder";a:2:{s:2:"in";a:1:{i:0;s:5:"dummy";}s:3:"out";a:1:{i:0;s:5:"dummy";}}s:15:"confirm_reading";i:3;}s:20:"my_schedule_settings";a:4:{s:14:"glb_start_time";i:8;s:12:"glb_end_time";i:19;s:8:"glb_days";a:7:{s:2:"mo";s:4:"TRUE";s:2:"di";s:4:"TRUE";s:2:"mi";s:4:"TRUE";s:2:"do";s:4:"TRUE";s:2:"fr";s:4:"TRUE";s:2:"sa";s:0:"";s:2:"so";s:0:"";}s:14:"default_setted";i:1348143571;}s:16:"my_personal_sems";N;s:18:"my_studip_settings";N;s:18:"homepage_cache_own";N;s:26:"calendar_user_control_data";a:12:{s:4:"view";s:8:"showweek";s:5:"start";i:9;s:3:"end";i:20;s:8:"step_day";i:900;s:9:"step_week";i:3600;s:9:"type_week";s:4:"LONG";s:8:"holidays";b:1;s:8:"sem_data";b:1;s:9:"link_edit";b:1;s:13:"bind_seminare";s:0:"";s:16:"ts_bind_seminare";i:0;s:6:"delete";i:0;}s:12:"_my_sem_open";a:3:{s:11:"not_grouped";b:1;i:2;b:1;i:1;b:1;}s:19:"_my_sem_group_field";s:10:"sem_number";}', '2012-11-23 15:48:58'),
('e7a0a84b161f3e8c09b4a0a2e8a58147', 'a:11:{s:12:"CurrentLogin";i:1352891146;s:9:"LastLogin";i:1351678958;s:5:"forum";N;s:21:"my_messaging_settings";a:16:{s:16:"show_only_buddys";b:0;s:28:"delete_messages_after_logout";b:0;s:26:"start_messenger_at_startup";b:0;s:14:"default_setted";i:1348477899;s:10:"last_login";b:0;s:10:"timefilter";s:3:"30d";s:7:"opennew";i:1;s:17:"logout_markreaded";b:0;s:7:"openall";s:1:"2";s:12:"addsignature";b:0;s:8:"save_snd";i:1;s:7:"sms_sig";b:0;s:9:"send_view";b:0;s:14:"last_box_visit";i:1352896191;s:6:"folder";a:3:{s:2:"in";a:1:{i:0;s:5:"dummy";}s:3:"out";a:1:{i:0;s:5:"dummy";}s:6:"active";a:1:{s:2:"in";s:3:"all";}}s:15:"confirm_reading";i:3;}s:20:"my_schedule_settings";a:4:{s:14:"glb_start_time";i:8;s:12:"glb_end_time";i:19;s:8:"glb_days";a:7:{s:2:"mo";s:4:"TRUE";s:2:"di";s:4:"TRUE";s:2:"mi";s:4:"TRUE";s:2:"do";s:4:"TRUE";s:2:"fr";s:4:"TRUE";s:2:"sa";s:0:"";s:2:"so";s:0:"";}s:14:"default_setted";i:1348477899;}s:16:"my_personal_sems";N;s:18:"my_studip_settings";N;s:18:"homepage_cache_own";N;s:26:"calendar_user_control_data";a:12:{s:4:"view";s:8:"showweek";s:5:"start";i:9;s:3:"end";i:20;s:8:"step_day";i:900;s:9:"step_week";i:3600;s:9:"type_week";s:4:"LONG";s:8:"holidays";b:1;s:8:"sem_data";b:1;s:9:"link_edit";b:1;s:13:"bind_seminare";s:0:"";s:16:"ts_bind_seminare";i:0;s:6:"delete";i:0;}s:12:"_my_sem_open";a:5:{s:11:"not_grouped";b:1;i:2;b:1;i:1;b:1;i:-1;b:1;i:3;b:1;}s:19:"_my_sem_group_field";s:10:"sem_number";}', '2012-11-14 16:19:19'),
('205f3efb7997a0fc9755da2b535038da', 'a:11:{s:12:"CurrentLogin";i:1352995696;s:9:"LastLogin";N;s:5:"forum";a:11:{s:9:"themeview";s:4:"tree";s:10:"presetview";s:4:"tree";s:10:"sortthemes";s:3:"asc";s:4:"view";s:4:"tree";s:6:"search";s:0:"";s:4:"sort";s:3:"age";s:9:"indikator";s:3:"age";s:6:"anchor";N;s:6:"update";N;s:5:"zitat";N;s:8:"openlist";s:2:";;";}s:21:"my_messaging_settings";a:16:{s:16:"show_only_buddys";b:0;s:28:"delete_messages_after_logout";b:0;s:26:"start_messenger_at_startup";b:0;s:14:"default_setted";i:1352995696;s:10:"last_login";b:0;s:10:"timefilter";s:3:"30d";s:7:"opennew";i:1;s:17:"logout_markreaded";b:0;s:7:"openall";b:0;s:12:"addsignature";b:0;s:8:"save_snd";i:1;s:7:"sms_sig";b:0;s:9:"send_view";b:0;s:14:"last_box_visit";i:1;s:6:"folder";a:2:{s:2:"in";a:1:{i:0;s:5:"dummy";}s:3:"out";a:1:{i:0;s:5:"dummy";}}s:15:"confirm_reading";i:3;}s:20:"my_schedule_settings";a:4:{s:14:"glb_start_time";i:8;s:12:"glb_end_time";i:19;s:8:"glb_days";a:7:{s:2:"mo";s:4:"TRUE";s:2:"di";s:4:"TRUE";s:2:"mi";s:4:"TRUE";s:2:"do";s:4:"TRUE";s:2:"fr";s:4:"TRUE";s:2:"sa";s:0:"";s:2:"so";s:0:"";}s:14:"default_setted";i:1352995696;}s:16:"my_personal_sems";N;s:18:"my_studip_settings";N;s:18:"homepage_cache_own";N;s:26:"calendar_user_control_data";a:12:{s:4:"view";s:8:"showweek";s:5:"start";i:9;s:3:"end";i:20;s:8:"step_day";i:900;s:9:"step_week";i:3600;s:9:"type_week";s:4:"LONG";s:8:"holidays";b:1;s:8:"sem_data";b:1;s:9:"link_edit";b:1;s:13:"bind_seminare";s:0:"";s:16:"ts_bind_seminare";i:0;s:6:"delete";i:0;}s:12:"_my_sem_open";a:4:{s:11:"not_grouped";b:1;i:3;b:1;i:1;b:1;i:2;b:1;}s:19:"_my_sem_group_field";s:10:"sem_number";}', '2012-11-15 17:08:34');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_info`
--

DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `hobby` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lebenslauf` text COLLATE latin1_general_ci,
  `publi` text COLLATE latin1_general_ci NOT NULL,
  `schwerp` text COLLATE latin1_general_ci NOT NULL,
  `Home` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `privatnr` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `privatcell` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `privadr` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `score` int(11) unsigned NOT NULL DEFAULT '0',
  `geschlecht` tinyint(4) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `title_front` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `title_rear` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `preferred_language` varchar(6) COLLATE latin1_general_ci DEFAULT NULL,
  `smsforward_copy` tinyint(1) NOT NULL DEFAULT '1',
  `smsforward_rec` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `guestbook` tinyint(4) NOT NULL DEFAULT '0',
  `email_forward` tinyint(4) NOT NULL DEFAULT '0',
  `smiley_favorite` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `motto` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lock_rule` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`),
  KEY `score` (`score`,`guestbook`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `user_info`
--

INSERT INTO `user_info` (`user_id`, `hobby`, `lebenslauf`, `publi`, `schwerp`, `Home`, `privatnr`, `privatcell`, `privadr`, `score`, `geschlecht`, `mkdate`, `chdate`, `title_front`, `title_rear`, `preferred_language`, `smsforward_copy`, `smsforward_rec`, `guestbook`, `email_forward`, `smiley_favorite`, `motto`, `lock_rule`) VALUES
('76ed43ef286fb55cf9e41beadb484a9f', '', NULL, '', '', '', '', '', '', 0, 0, 0, 1340617219, '', '', NULL, 1, '', 0, 0, '', '', ''),
('e7a0a84b161f3e8c09b4a0a2e8a58147', '', NULL, '', '', '', '', '', '', 0, 0, 0, 1351678947, '', '', NULL, 1, '', 0, 0, '', '', ''),
('205f3efb7997a0fc9755da2b535038da', '', NULL, '', '', '', '', '', '', 0, 0, 0, 0, '', '', NULL, 1, '', 0, 0, '', '', ''),
('6235c46eb9e962866ebdceece739ace5', '', NULL, '', '', '', '', '', '', 0, 0, 0, 0, '', '', NULL, 1, '', 0, 0, '', '', ''),
('7e81ec247c151c02ffd479511e24cc03', '', NULL, '', '', '', '', '', '', 0, 0, 0, 0, '', '', NULL, 1, '', 0, 0, '', '', ''),
('f859df66bb9a3f8ecd46a9895d4e47d2', '', NULL, '', '', '', '', '', '', 0, 0, 1348056714, 1348056714, '', '', NULL, 1, '', 0, 0, '', '', ''),
('cca72d353f2f35f1e3fc10b88d6aa390', '', NULL, '', '', '', '', '', '', 0, 1, 1354272745, 1354272745, 'Dipl.-Math.', '', NULL, 1, '', 0, 0, '', '', ''),
('ac1981c0e8d159d8121508c488fad1cb', '', NULL, '', '', '', '', '', '', 0, 0, 1354272775, 1354272775, '', '', NULL, 1, '', 0, 0, '', '', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_inst`
--

DROP TABLE IF EXISTS `user_inst`;
CREATE TABLE `user_inst` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `Institut_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `inst_perms` enum('user','autor','tutor','dozent','admin') COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `sprechzeiten` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `raum` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Telefon` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Fax` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `externdefault` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`Institut_id`,`user_id`),
  KEY `inst_perms` (`inst_perms`,`Institut_id`),
  KEY `user_id` (`user_id`,`inst_perms`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `user_inst`
--

INSERT INTO `user_inst` (`user_id`, `Institut_id`, `inst_perms`, `sprechzeiten`, `raum`, `Telefon`, `Fax`, `externdefault`, `priority`, `visible`) VALUES
('205f3efb7997a0fc9755da2b535038da', '2560f7c7674942a7dce8eeb238e15d93', 'dozent', '', '', '', '', 0, 0, 1),
('6235c46eb9e962866ebdceece739ace5', '2560f7c7674942a7dce8eeb238e15d93', 'admin', '', '', '', '', 0, 0, 1),
('7e81ec247c151c02ffd479511e24cc03', '2560f7c7674942a7dce8eeb238e15d93', 'tutor', '', '', '', '', 0, 0, 1),
('e7a0a84b161f3e8c09b4a0a2e8a58147', '2560f7c7674942a7dce8eeb238e15d93', 'user', '', '', '', '', 1, 0, 1),
('cca72d353f2f35f1e3fc10b88d6aa390', '7a4f19a0a2c321ab2b8f7b798881af7c', 'dozent', '', '', '', '', 0, 0, 1),
('ac1981c0e8d159d8121508c488fad1cb', '7a4f19a0a2c321ab2b8f7b798881af7c', 'dozent', '', '', '', '', 0, 0, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_studiengang`
--

DROP TABLE IF EXISTS `user_studiengang`;
CREATE TABLE `user_studiengang` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `studiengang_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `semester` tinyint(2) DEFAULT '0',
  `abschluss_id` char(32) COLLATE latin1_general_ci DEFAULT '0',
  PRIMARY KEY (`user_id`,`studiengang_id`),
  KEY `studiengang_id` (`studiengang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `user_studiengang`
--

INSERT INTO `user_studiengang` (`user_id`, `studiengang_id`, `semester`, `abschluss_id`) VALUES
('e7a0a84b161f3e8c09b4a0a2e8a58147', '6b9ac09535885ca55e29dd011e377c0a', 2, '228234544820cdf75db55b42d1ea3ecc'),
('7e81ec247c151c02ffd479511e24cc03', 'f981c9b42ca72788a09da4a45794a737', 1, '228234544820cdf75db55b42d1ea3ecc');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_token`
--

DROP TABLE IF EXISTS `user_token`;
CREATE TABLE `user_token` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `token` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`token`,`expiration`),
  KEY `index_expiration` (`expiration`),
  KEY `index_token` (`token`),
  KEY `index_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `user_token`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_userdomains`
--

DROP TABLE IF EXISTS `user_userdomains`;
CREATE TABLE `user_userdomains` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `userdomain_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`,`userdomain_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `user_userdomains`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_visibility`
--

DROP TABLE IF EXISTS `user_visibility`;
CREATE TABLE `user_visibility` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `online` tinyint(1) NOT NULL DEFAULT '1',
  `chat` tinyint(1) NOT NULL DEFAULT '1',
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `email` tinyint(1) NOT NULL DEFAULT '1',
  `homepage` text COLLATE latin1_general_ci NOT NULL,
  `default_homepage_visibility` int(11) NOT NULL DEFAULT '0',
  `mkdate` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `user_visibility`
--

INSERT INTO `user_visibility` (`user_id`, `online`, `chat`, `search`, `email`, `homepage`, `default_homepage_visibility`, `mkdate`) VALUES
('studip', 1, 1, 1, 1, '', 0, 1340615947);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `vote`
--

DROP TABLE IF EXISTS `vote`;
CREATE TABLE `vote` (
  `vote_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `author_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` enum('vote','test') COLLATE latin1_general_ci NOT NULL DEFAULT 'vote',
  `title` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `question` text COLLATE latin1_general_ci NOT NULL,
  `state` enum('new','active','stopvis','stopinvis') COLLATE latin1_general_ci NOT NULL DEFAULT 'new',
  `startdate` int(20) DEFAULT NULL,
  `stopdate` int(20) DEFAULT NULL,
  `timespan` int(20) DEFAULT NULL,
  `mkdate` int(20) NOT NULL DEFAULT '0',
  `chdate` int(20) NOT NULL DEFAULT '0',
  `resultvisibility` enum('ever','delivery','end','never') COLLATE latin1_general_ci NOT NULL DEFAULT 'ever',
  `multiplechoice` tinyint(1) NOT NULL DEFAULT '0',
  `anonymous` tinyint(1) NOT NULL DEFAULT '1',
  `changeable` tinyint(1) NOT NULL DEFAULT '0',
  `co_visibility` tinyint(1) DEFAULT NULL,
  `namesvisibility` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vote_id`),
  KEY `range_id` (`range_id`),
  KEY `state` (`state`),
  KEY `startdate` (`startdate`),
  KEY `stopdate` (`stopdate`),
  KEY `resultvisibility` (`resultvisibility`),
  KEY `chdate` (`chdate`),
  KEY `author_id` (`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `vote`
--

INSERT INTO `vote` (`vote_id`, `author_id`, `range_id`, `type`, `title`, `question`, `state`, `startdate`, `stopdate`, `timespan`, `mkdate`, `chdate`, `resultvisibility`, `multiplechoice`, `anonymous`, `changeable`, `co_visibility`, `namesvisibility`) VALUES
('b5329b23b7f865c62028e226715e1914', '76ed43ef286fb55cf9e41beadb484a9f', 'studip', 'vote', 'Nutzen Sie bereits Stud.IP?', 'Haben Sie Stud.IP bereits im Einsatz oder planen Sie, es einzusetzen?', 'active', 1293120882, NULL, NULL, 1142525062, 1293120883, 'delivery', 1, 0, 1, NULL, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `voteanswers`
--

DROP TABLE IF EXISTS `voteanswers`;
CREATE TABLE `voteanswers` (
  `answer_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `vote_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `answer` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `counter` int(11) NOT NULL DEFAULT '0',
  `correct` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`answer_id`),
  KEY `vote_id` (`vote_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `voteanswers`
--

INSERT INTO `voteanswers` (`answer_id`, `vote_id`, `answer`, `position`, `counter`, `correct`) VALUES
('2ea4169a90dbcc56be1610f75d86d460', 'b5329b23b7f865c62028e226715e1914', 'Ich plane, es demnächst einzusetzen', 18, 0, 0),
('ddcf45e577e20133fcc5bf65aef2a075', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.11', 17, 0, 0),
('71b97633448009af49c43b5a56de4c7f', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.10', 16, 0, 0),
('ef983352938c5714f23bc47257dd2489', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.9', 15, 0, 0),
('5fb01b6623c848c3bf33cce70675b91a', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.8', 14, 0, 0),
('03bce9c940fc76f5eb90ab7b151cf34d', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.7', 13, 0, 0),
('816a463bef33edcdf1ed82e94166f1ad', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.6', 12, 0, 0),
('dddf684fbcac58f7ffd0804b7095c71b', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.5', 11, 0, 0),
('b1083fbf35c8782ad35c1a0c9364f2c2', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.4', 10, 0, 0),
('f31fab58d15388245396dc59de346e90', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.3', 9, 0, 0),
('6f51e5d957aa6e7a3e8494e0e56c43aa', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.2', 8, 0, 0),
('8502e4b4600a12b2d5d43aefe2930be4', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.1.5', 7, 0, 0),
('8112e4b4600a12b2d5d43aecf2930be4', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.1.0', 6, 0, 0),
('8342e4b4600a12b2d5d43aecf2930be4', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 1.0', 5, 0, 0),
('dc1b49bf35e9cfbfcece807b21cec0ef', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 0.9.5', 4, 0, 0),
('ddfd889094a6cea75703728ee7b48806', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 0.9.0', 3, 0, 0),
('58281eda805a0fe5741c74a2c612cb05', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 0.8.15', 2, 0, 0),
('c8ade4c7f3bbe027f6c19016dd3e001c', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 0.8.0', 1, 0, 0),
('112f7c8f52b0a2a6eff9cddf93b419c7', 'b5329b23b7f865c62028e226715e1914', 'Ich nutze die Version 0.7.5', 0, 0, 0),
('3c065ec2b3037c39991cc5d99eca185c', 'b5329b23b7f865c62028e226715e1914', 'Ich schaue mich nur mal um', 19, 0, 0),
('56991b7ad13aa8f5315e9bc412c6a199', 'b5329b23b7f865c62028e226715e1914', 'Ich bin nicht interessiert', 20, 0, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `voteanswers_user`
--

DROP TABLE IF EXISTS `voteanswers_user`;
CREATE TABLE `voteanswers_user` (
  `answer_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `votedate` int(20) DEFAULT NULL,
  PRIMARY KEY (`answer_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `voteanswers_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `vote_user`
--

DROP TABLE IF EXISTS `vote_user`;
CREATE TABLE `vote_user` (
  `vote_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `votedate` int(20) DEFAULT NULL,
  PRIMARY KEY (`vote_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci PACK_KEYS=1;

--
-- Daten für Tabelle `vote_user`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webservice_access_rules`
--

DROP TABLE IF EXISTS `webservice_access_rules`;
CREATE TABLE `webservice_access_rules` (
  `api_key` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `method` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ip_range` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` enum('allow','deny') COLLATE latin1_general_ci NOT NULL DEFAULT 'allow',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `webservice_access_rules`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wiki`
--

DROP TABLE IF EXISTS `wiki`;
CREATE TABLE `wiki` (
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_id` varchar(32) COLLATE latin1_general_ci DEFAULT NULL,
  `keyword` varchar(128) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `body` text COLLATE latin1_general_ci,
  `chdate` int(11) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`range_id`,`keyword`,`version`),
  KEY `user_id` (`user_id`),
  KEY `chdate` (`chdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `wiki`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wiki_links`
--

DROP TABLE IF EXISTS `wiki_links`;
CREATE TABLE `wiki_links` (
  `range_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `from_keyword` char(128) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `to_keyword` char(128) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`range_id`,`to_keyword`,`from_keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `wiki_links`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wiki_locks`
--

DROP TABLE IF EXISTS `wiki_locks`;
CREATE TABLE `wiki_locks` (
  `user_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `range_id` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `keyword` varchar(128) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `chdate` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`range_id`,`user_id`,`keyword`),
  KEY `user_id` (`user_id`),
  KEY `chdate` (`chdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Daten für Tabelle `wiki_locks`
--


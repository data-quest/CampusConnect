<html>
<pre>
<?php
passthru(dirname(__file__)."/../upload_all.sh");
?>
</pre>
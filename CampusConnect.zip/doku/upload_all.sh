#!/bin/sh

./campusconnect_scripts_lsfproxy.sh -r -k 24 -u 1 create
./campusconnect_scripts_lsfproxy.sh -c -k 24 -u 2 create
./campusconnect_scripts_lsfproxy.sh -m -k 24 -u 3 create
./campusconnect_scripts_lsfproxy.sh -t -k 24 -u 4 create
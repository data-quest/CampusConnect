<?php

/*
 * Copyright (C) 2011 - Rasmus Fuhse <fuhse@data-quest.de>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 */

require_once dirname(__file__)."/../lib/EcsClient.php";

class EcsClientTestCase extends UnitTestCase {


    function setUp()
    {
        CampusConnectLog::get()->setLogLevel(10000);
    }


    function tearDown()
    {
    }


    function test_something()
    {
        
    }

}



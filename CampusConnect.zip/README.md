CampusConnect plugin for Stud.IP
================================

CampusConnect is a project to connect various elearning-service-platforms with each other. You can find further information about the project here:

* http://freeit.de/de/campusconnect/index.html
* http://freeit.de/de/ecsa/ecs.html

## Installation of this plugin in Stud.IP

Here is a comprehensive tutorial in german with all necessary steps and a small cheat-sheet you can use as a checklist for your installation:

* [Tutorial for this plugin (german)](https://github.com/data-quest/CampusConnect/wiki/tutorial_de)
* [Cheat-sheet for installing (german)](https://github.com/data-quest/CampusConnect/wiki/cheatsheet_de)

